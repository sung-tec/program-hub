# PC Insight Monitor

PC Insight Monitor는 Windows 10/11 환경에서 동작하는 로컬 전용 Python 데스크톱 시스템 모니터링 앱입니다.  
PySide6 기반 UI에서 시스템 사양, 실시간 자원 사용량, 프로세스 집계, 과부하 분석, 히스토리 조회, PDF/TXT/XLSX 내보내기를 제공합니다.

## 주요 기능

- 시스템 사양 정밀 분석
- CPU / RAM / 디스크 / 네트워크 실시간 모니터링
- 가능 시 GPU 사용량 / GPU 온도 / GPU 메모리 수집
- 프로세스별 CPU / 메모리 / 디스크 사용량 집계
- 연속 임계 초과 기반 과부하 이벤트 탐지
- 세션 저장 및 히스토리 조회
- PDF / TXT / Excel(xlsx) 리포트 저장
- 센서 미지원 환경 graceful fallback

## 지원 환경

- Windows 10 / 11 64bit
- Python 3.11 이상 권장 (Python 3.14 환경에서는 최신 PySide6/PyInstaller 조합 사용)
- 오프라인 로컬 앱
- 단일 사용자 환경

## 설치 방법

```bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

권장 환경은 Windows PowerShell 또는 cmd이며, 가상환경 사용을 권장합니다.

예시:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## 실행 방법

```bat
python main.py
```

또는

```bat
run.bat
```

## 기본 사용 흐름

1. 앱을 실행합니다.
2. `시스템 사양` 탭에서 현재 시스템 정보를 확인합니다.
3. `대시보드` 탭에서 `시작` 버튼을 눌러 세션을 시작합니다.
4. 실시간 수치와 프로세스 사용량, 그래프를 확인합니다.
5. 필요 시 `일시정지`, `재개`, `중지`를 사용합니다.
6. 세션이 종료되면 `분석 리포트`와 `기록 / 히스토리`에서 결과를 확인합니다.
7. `기록 / 히스토리` 탭에서 세션을 선택한 뒤 `PDF`, `TXT`, `XLSX` 형식으로 내보냅니다.

## 내보내기 방법

1. `기록 / 히스토리` 탭에서 세션을 선택합니다.
2. 우측 상단 내보내기 형식을 선택합니다.
3. `선택 세션 내보내기` 버튼을 누릅니다.
4. 저장 폴더를 선택하면 리포트가 생성됩니다.

생성 가능한 형식:

- PDF
- TXT
- XLSX

## 히스토리 조회 방법

- `기록 / 히스토리` 탭에서 과거 세션 목록을 확인할 수 있습니다.
- 상태 필터와 날짜 범위를 사용해 원하는 세션만 볼 수 있습니다.
- `선택 세션 상세 보기`를 누르면 분석 결과와 그래프를 다시 확인할 수 있습니다.
- `선택 세션 다시 분석`을 누르면 DB에 저장된 샘플 기준으로 분석 결과를 재계산합니다.

## 설정 변경 방법

`설정` 탭에서 다음 값을 변경할 수 있습니다.

- 샘플링 간격
- 기본 저장 경로
- 자동 저장 여부
- 자동 시작 여부
- 로그 보관 일수
- 과부하 임계값
- 다크모드 여부
- 기본 내보내기 형식
- 센서 수집 옵션

`적용`을 누르면 `settings.json`에 저장됩니다.  
실행 중 세션에는 일부 설정이 즉시 반영되지 않고 다음 세션부터 반영될 수 있습니다.

## 기본 저장 경로

앱은 기본적으로 다음 경로를 자동 생성합니다.

```text
%LOCALAPPDATA%\PCInsightMonitor\
├─ config\settings.json
├─ data\monitor.db
├─ logs\app.log
├─ exports\
└─ temp\charts\
```

첫 실행 시 폴더가 없으면 자동 생성됩니다.

## 센서 미지원 시 동작 방식

모든 PC에서 CPU/GPU 온도, BIOS, 메인보드, GPU 사용률이 동일하게 수집되지는 않습니다.  
이 앱은 센서 또는 드라이버가 지원되지 않는 경우에도 종료되지 않으며 다음처럼 처리합니다.

- 지원되지 않는 값: `지원 안 함`
- 일시적으로 값을 못 읽은 경우: `값 없음`
- 수집 중 예외 발생: `수집 실패`

기본 기능인 CPU / RAM / 디스크 / 네트워크 / 프로세스 / DB 저장 / 리포트 내보내기는 센서 미지원 환경에서도 계속 동작하도록 설계했습니다.

## PyInstaller 빌드 방법

Windows에서 실행파일을 만들려면 아래 순서로 진행합니다.

```bat
build_pyinstaller.bat
```

또는 수동으로:

```bat
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean pc_insight_monitor.spec
```

빌드가 완료되면 일반적으로 다음 위치에 생성됩니다.

```text
dist\PCInsightMonitor\PCInsightMonitor.exe
```

## 배포 시 권장 방식

PySide6, matplotlib, pyqtgraph, reportlab 등을 포함하므로 **one-folder 배포**가 안정적입니다.  
`pc_insight_monitor.spec`는 one-folder 기준으로 작성되어 있습니다.

## 문제 해결 가이드

### 1) 실행 시 PySide6 관련 오류가 발생함
Python 3.14 환경이라면 구버전 PySide6 제약이 들어간 오래된 requirements 파일을 쓰면 설치가 실패할 수 있습니다. 이 ZIP에는 수정된 의존성 범위가 반영되어 있습니다.

아래 명령으로 의존성을 다시 설치합니다.

```bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### 2) GPU 정보가 보이지 않음
다음 원인이 있을 수 있습니다.

- NVIDIA GPU가 아님
- pynvml 접근 불가
- 드라이버 또는 NVML 미지원
- 관리자 권한 또는 시스템 정책 문제

이 경우 앱은 계속 동작하며 GPU 값은 `지원 안 함` 또는 `값 없음`으로 표시됩니다.

### 3) CPU/GPU 온도가 보이지 않음
앱은 아래 순서로 온도를 수집합니다.

- LibreHardwareMonitor / OpenHardwareMonitor WMI namespace
- LibreHardwareMonitor Remote Web Server (`http://127.0.0.1:8085/data.json` 또는 `http://127.0.0.1:8085/data.json
또는
http://localhost:8085/data.json`)
- Windows ACPI WMI
- WinTmp fallback(선택 설치 시에만 사용)
- psutil 센서 API

특히 CPU 온도는 Windows에서 기본 API만으로 바로 제공되지 않는 경우가 많습니다.
기본 requirements.txt에서는 Python 3.14 설치 오류를 피하기 위해 WinTmp를 필수 의존성에서 제외했습니다.
CPU 온도 그래프가 계속 비어 있으면 아래 순서로 확인해 주세요.

1. LibreHardwareMonitor를 설치하거나 실행합니다.
2. LibreHardwareMonitor에서 `Options → Remote Web Server → Run`을 켭니다.
3. 가능하면 LibreHardwareMonitor를 관리자 권한으로 실행합니다.
4. 그 다음 PC Insight Monitor를 다시 실행합니다.

```bat
python -m pip install -r requirements.txt
python main.py
```

브라우저에서 아래 주소가 열리면 HTTP fallback이 동작할 수 있습니다.

```text
http://localhost:8085/data.json
```

그래도 비어 있으면 아래 가능성이 큽니다.

- 관리자 권한이 아님
- LibreHardwareMonitor WMI/HTTP 센서가 비어 있음
- 메인보드/노트북 제조사 센서 제한
- 현재 장치에서 CPU 온도 노출을 막고 있음

이 경우 온도 값 없이 나머지 기능은 그대로 동작합니다.

### 4) PDF에서 한글이 깨짐
Windows에서는 일반적으로 `malgun.ttf`를 사용해 정상 출력됩니다.  
비표준 환경에서는 폰트 fallback이 적용되며, 이 경우 한글 차트 텍스트 일부가 완전히 표시되지 않을 수 있습니다.

### 5) 실행파일 빌드 후 바로 종료됨
다음 항목을 확인합니다.

- `dist` 폴더를 통째로 이동했는지
- 보안 프로그램이 파일을 격리하지 않았는지
- `logs\app.log`에 오류가 남았는지

### 6) 프로세스 일부가 비어 보임
Windows 보안 정책 또는 권한 문제로 일부 시스템 프로세스는 접근이 제한될 수 있습니다.  
이 경우 해당 프로세스만 건너뛰고 전체 앱은 계속 동작합니다.

## 알려진 제한사항

- 프로세스별 GPU 사용량은 일반 Windows 환경에서 일관되게 수집하기 어렵기 때문에 기본적으로 `None` 처리됩니다.
- CPU/GPU 온도는 하드웨어/드라이버/WMI 환경에 따라 수집되지 않을 수 있습니다.
- NVIDIA가 아닌 GPU는 동적 사용률 수집이 제한될 수 있습니다.
- 본 프로젝트는 Windows 대상 앱이며, 비-Windows 환경에서는 일부 기능이 제한됩니다.


## LibreHardwareMonitor 자동 준비 기능

이 빌드에는 CPU 온도 수집이 계속 비는 환경을 위해 **LibreHardwareMonitor 자동 준비 기능**이 포함되어 있습니다.

동작 순서:
1. CPU 온도 수집이 실패하면 앱이 먼저 로컬에 번들된 LibreHardwareMonitor가 있는지 확인합니다.
2. 있으면 `%LOCALAPPDATA%\PCInsightMonitor\third_party\LibreHardwareMonitor\`로 복사 후 자동 실행합니다.
3. 번들 파일이 없으면 공식 GitHub 릴리스 페이지에서 ZIP 링크를 찾아 자동 다운로드 후 압축 해제하고 실행합니다.
4. 실행 후 WMI/HTTP 센서 경로를 다시 확인해 CPU 온도를 재시도합니다.

주의:
- 최초 자동 다운로드는 인터넷 연결이 필요합니다.
- 일부 시스템은 관리자 권한에서만 CPU 온도가 노출됩니다.
- 오프라인 배포가 필요하면 `vendor\LibreHardwareMonitor\` 폴더에 공식 릴리스 압축을 풀어 넣은 뒤 EXE를 다시 빌드하세요.
- 자동 다운로드/실행 로그는 `%LOCALAPPDATA%\PCInsightMonitor\logs\app.log`에서 확인할 수 있습니다.
