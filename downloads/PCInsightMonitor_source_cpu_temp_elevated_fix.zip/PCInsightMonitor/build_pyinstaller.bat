@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_CMD="
if exist ".venv\Scripts\python.exe" set "PYTHON_CMD=.venv\Scripts\python.exe"
if not defined PYTHON_CMD (
    py --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py"
)
if not defined PYTHON_CMD set "PYTHON_CMD=python"

echo [1/3] Upgrading pip tools...
%PYTHON_CMD% -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto error

echo [2/3] Installing requirements...
%PYTHON_CMD% -m pip install -r requirements.txt
if errorlevel 1 goto error

echo [3/3] Building one-file executable with PyInstaller...
%PYTHON_CMD% -m PyInstaller --noconfirm --clean pc_insight_monitor.spec
if errorlevel 1 goto error

if exist "dist\PCInsightMonitor.exe" (
    echo.
    echo Build completed.
    echo Output file: dist\PCInsightMonitor.exe
) else (
    echo.
    echo Build finished but the exe file was not found in dist.
    echo Open the dist folder and check antivirus quarantine history.
)
pause
exit /b 0

:error
echo.
echo Build failed.
pause
exit /b 1
