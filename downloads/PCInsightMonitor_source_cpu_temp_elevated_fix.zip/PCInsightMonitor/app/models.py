from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Optional

from app.constants import (
    DEFAULT_HISTORY_LIMIT,
    DEFAULT_LOG_RETENTION_DAYS,
    DEFAULT_SAMPLE_INTERVAL_SEC,
    DEFAULT_TOP_PROCESS_COUNT,
    EXPORT_FORMAT_PDF,
)


@dataclass(slots=True)
class ThresholdSettings:
    cpu_usage_percent: float = 85.0
    gpu_usage_percent: float = 90.0
    ram_percent: float = 90.0
    cpu_temp_c: float = 80.0
    gpu_temp_c: float = 80.0
    duration_sec: int = 30
    merge_gap_sec: int = 5

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ThresholdSettings":
        if not data:
            return cls()
        return cls(
            cpu_usage_percent=float(data.get("cpu_usage_percent", 85.0)),
            gpu_usage_percent=float(data.get("gpu_usage_percent", 90.0)),
            ram_percent=float(data.get("ram_percent", 90.0)),
            cpu_temp_c=float(data.get("cpu_temp_c", 80.0)),
            gpu_temp_c=float(data.get("gpu_temp_c", 80.0)),
            duration_sec=int(data.get("duration_sec", 30)),
            merge_gap_sec=int(data.get("merge_gap_sec", 5)),
        )


@dataclass(slots=True)
class SensorOptions:
    enable_cpu_temperature: bool = True
    enable_gpu_metrics: bool = True
    enable_gpu_temperature: bool = True
    enable_hardware_probe: bool = True
    enable_battery_probe: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "SensorOptions":
        if not data:
            return cls()
        return cls(
            enable_cpu_temperature=bool(data.get("enable_cpu_temperature", True)),
            enable_gpu_metrics=bool(data.get("enable_gpu_metrics", True)),
            enable_gpu_temperature=bool(data.get("enable_gpu_temperature", True)),
            enable_hardware_probe=bool(data.get("enable_hardware_probe", True)),
            enable_battery_probe=bool(data.get("enable_battery_probe", True)),
        )


@dataclass(slots=True)
class AppSettings:
    sample_interval_sec: int = DEFAULT_SAMPLE_INTERVAL_SEC
    auto_save: bool = True
    auto_start: bool = False
    log_retention_days: int = DEFAULT_LOG_RETENTION_DAYS
    dark_mode: bool = False
    default_export_format: str = EXPORT_FORMAT_PDF
    export_base_dir: str = ""
    top_process_count: int = DEFAULT_TOP_PROCESS_COUNT
    history_limit: int = DEFAULT_HISTORY_LIMIT
    overload_thresholds: ThresholdSettings = field(default_factory=ThresholdSettings)
    sensor_options: SensorOptions = field(default_factory=SensorOptions)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["overload_thresholds"] = self.overload_thresholds.to_dict()
        payload["sensor_options"] = self.sensor_options.to_dict()
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "AppSettings":
        if not data:
            return cls()
        return cls(
            sample_interval_sec=int(data.get("sample_interval_sec", DEFAULT_SAMPLE_INTERVAL_SEC)),
            auto_save=bool(data.get("auto_save", True)),
            auto_start=bool(data.get("auto_start", False)),
            log_retention_days=int(data.get("log_retention_days", DEFAULT_LOG_RETENTION_DAYS)),
            dark_mode=bool(data.get("dark_mode", False)),
            default_export_format=str(data.get("default_export_format", EXPORT_FORMAT_PDF)).lower(),
            export_base_dir=str(data.get("export_base_dir", "")),
            top_process_count=int(data.get("top_process_count", DEFAULT_TOP_PROCESS_COUNT)),
            history_limit=int(data.get("history_limit", DEFAULT_HISTORY_LIMIT)),
            overload_thresholds=ThresholdSettings.from_dict(data.get("overload_thresholds")),
            sensor_options=SensorOptions.from_dict(data.get("sensor_options")),
        )


@dataclass(slots=True)
class SystemInfoItem:
    category: str
    key: str
    value: str

    def db_key(self) -> str:
        return f"{self.category}::{self.key}"

    @classmethod
    def from_db(cls, db_key: str, value: str) -> "SystemInfoItem":
        if "::" in db_key:
            category, key = db_key.split("::", 1)
        else:
            category, key = "기타", db_key
        return cls(category=category, key=key, value=value)


@dataclass(slots=True)
class MetricSample:
    collected_at: str
    cpu_percent: Optional[float] = None
    cpu_clock_mhz: Optional[float] = None
    cpu_temp_c: Optional[float] = None
    gpu_percent: Optional[float] = None
    gpu_mem_used_mb: Optional[float] = None
    gpu_temp_c: Optional[float] = None
    ram_used_mb: Optional[float] = None
    ram_percent: Optional[float] = None
    disk_read_bps: Optional[float] = None
    disk_write_bps: Optional[float] = None
    net_sent_bps: Optional[float] = None
    net_recv_bps: Optional[float] = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ProcessSample:
    collected_at: str
    pid: int
    process_name: str
    cpu_percent: Optional[float] = None
    memory_mb: Optional[float] = None
    disk_read_bytes: Optional[int] = None
    disk_write_bytes: Optional[int] = None
    gpu_percent: Optional[float] = None
    status: str = "실행 중"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ProcessSummary:
    session_id: Optional[int]
    pid: int
    process_name: str
    first_seen_at: str
    last_seen_at: str
    runtime_sec: float
    cpu_avg: Optional[float] = None
    cpu_max: Optional[float] = None
    memory_avg_mb: Optional[float] = None
    memory_max_mb: Optional[float] = None
    disk_read_total_bytes: int = 0
    disk_write_total_bytes: int = 0
    gpu_avg: Optional[float] = None
    gpu_max: Optional[float] = None
    last_status: str = "실행 중"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ProcessDisplayRow:
    pid: int
    process_name: str
    start_time: Optional[str]
    runtime_sec: Optional[float]
    current_cpu_percent: Optional[float]
    avg_cpu_percent: Optional[float]
    max_cpu_percent: Optional[float]
    current_memory_mb: Optional[float]
    avg_memory_mb: Optional[float]
    max_memory_mb: Optional[float]
    disk_read_total_bytes: int
    disk_write_total_bytes: int
    gpu_current_percent: Optional[float]
    status: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class OverloadEvent:
    session_id: Optional[int]
    event_type: str
    started_at: str
    ended_at: Optional[str]
    duration_sec: Optional[float]
    threshold_value: float
    peak_value: Optional[float]
    suspected_processes_json: str
    description: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class LiveAlert:
    event_type: str
    label: str
    started_at: str
    current_value: Optional[float]
    threshold_value: float
    duration_sec: float
    suspected_processes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class SessionRecord:
    id: int
    session_name: str
    started_at: str
    ended_at: Optional[str]
    status: str
    sample_interval_sec: int
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class MonitorStatusSnapshot:
    session_id: Optional[int]
    session_name: str
    state: str
    last_sample_at: Optional[str] = None
    last_saved_at: Optional[str] = None
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class MetricStats:
    metric_key: str
    display_name: str
    average: Optional[float]
    minimum: Optional[float]
    maximum: Optional[float]
    p95: Optional[float]
    unit: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class PeakPoint:
    label: str
    timestamp: Optional[str]
    value: Optional[float]
    unit: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class AnalysisResult:
    session_id: int
    session_duration_sec: float
    sample_count: int
    stats: list[MetricStats] = field(default_factory=list)
    peak_points: list[PeakPoint] = field(default_factory=list)
    overload_events: list[OverloadEvent] = field(default_factory=list)
    total_overload_count: int = 0
    longest_event: Optional[OverloadEvent] = None
    peak_time_window: str = "값 없음"
    bottleneck_summary: str = "값 없음"
    narrative_summary: str = "값 없음"
    recommendations: list[str] = field(default_factory=list)
    top_processes: list[ProcessSummary] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["stats"] = [item.to_dict() for item in self.stats]
        payload["peak_points"] = [item.to_dict() for item in self.peak_points]
        payload["overload_events"] = [item.to_dict() for item in self.overload_events]
        payload["longest_event"] = self.longest_event.to_dict() if self.longest_event else None
        payload["top_processes"] = [item.to_dict() for item in self.top_processes]
        return payload


@dataclass(slots=True)
class SessionBundle:
    session: SessionRecord
    system_info: list[SystemInfoItem] = field(default_factory=list)
    metric_samples: list[MetricSample] = field(default_factory=list)
    process_samples: list[ProcessSample] = field(default_factory=list)
    process_summaries: list[ProcessSummary] = field(default_factory=list)
    overload_events: list[OverloadEvent] = field(default_factory=list)
    analysis: Optional[AnalysisResult] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "session": self.session.to_dict(),
            "system_info": [{"category": item.category, "key": item.key, "value": item.value} for item in self.system_info],
            "metric_samples": [item.to_dict() for item in self.metric_samples],
            "process_samples": [item.to_dict() for item in self.process_samples],
            "process_summaries": [item.to_dict() for item in self.process_summaries],
            "overload_events": [item.to_dict() for item in self.overload_events],
            "analysis": self.analysis.to_dict() if self.analysis else None,
        }
