from __future__ import annotations

import json
from pathlib import Path

from app.constants import APP_NAME, EVENT_TYPE_LABELS
from app.models import SessionBundle
from app.utils import (
    format_bytes,
    format_bytes_per_sec,
    format_duration,
    format_gb_from_mb,
    format_percent,
    format_temperature,
    grouped_system_info,
    now_local,
    sanitize_filename,
    to_display_datetime,
)


def _line(title: str) -> str:
    return f"\n{'=' * 12} {title} {'=' * 12}\n"


def export_bundle_to_txt(bundle: SessionBundle, output_dir: str | Path) -> Path:
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    file_name = f"PCInsightMonitor_Report_{bundle.session.id}_{now_local().strftime('%Y%m%d_%H%M%S')}.txt"
    target_path = output_root / sanitize_filename(file_name)

    lines: list[str] = []
    lines.append(f"{APP_NAME} 보고서")
    lines.append(f"생성 시각: {to_display_datetime(now_local().isoformat())}")

    lines.append(_line("세션 개요"))
    lines.extend(
        [
            f"세션 ID: {bundle.session.id}",
            f"세션명: {bundle.session.session_name}",
            f"시작 시각: {to_display_datetime(bundle.session.started_at)}",
            f"종료 시각: {to_display_datetime(bundle.session.ended_at)}",
            f"상태: {bundle.session.status}",
            f"샘플 간격: {bundle.session.sample_interval_sec}초",
            f"샘플 수: {len(bundle.metric_samples)}",
        ]
    )
    if bundle.analysis:
        lines.append(f"세션 길이: {format_duration(bundle.analysis.session_duration_sec)}")
        lines.append(f"과부하 횟수: {bundle.analysis.total_overload_count}")

    lines.append(_line("시스템 사양"))
    for category, items in grouped_system_info(bundle.system_info).items():
        lines.append(f"[{category}]")
        for item in items:
            lines.append(f"- {item.key}: {item.value}")
        lines.append("")

    if bundle.analysis:
        lines.append(_line("통계 요약"))
        for stat in bundle.analysis.stats:
            if stat.metric_key in {"cpu_percent", "gpu_percent", "ram_percent"}:
                formatter = format_percent
            elif stat.metric_key in {"cpu_temp_c", "gpu_temp_c"}:
                formatter = format_temperature
            elif stat.metric_key in {"ram_used_mb", "gpu_mem_used_mb"}:
                formatter = format_gb_from_mb
            elif stat.metric_key.endswith("_bps"):
                formatter = format_bytes_per_sec
            elif stat.metric_key == "cpu_clock_mhz":
                formatter = lambda value: f"{value:.0f} MHz" if value is not None else "값 없음"
            else:
                formatter = lambda value: "값 없음" if value is None else f"{value:.2f}"

            lines.append(
                f"- {stat.display_name}: 평균 {formatter(stat.average)} / 최소 {formatter(stat.minimum)} / "
                f"최대 {formatter(stat.maximum)} / p95 {formatter(stat.p95)}"
            )

        lines.append(_line("과부하 이벤트"))
        if bundle.analysis.overload_events:
            for event in bundle.analysis.overload_events:
                try:
                    processes = json.loads(event.suspected_processes_json)
                except Exception:
                    processes = []
                process_text = ", ".join(item.get("process_name", "") for item in processes if isinstance(item, dict)) or "원인 후보 없음"
                lines.extend(
                    [
                        f"* 이벤트: {EVENT_TYPE_LABELS.get(event.event_type, event.event_type)}",
                        f"  시작: {to_display_datetime(event.started_at)}",
                        f"  종료: {to_display_datetime(event.ended_at)}",
                        f"  지속 시간: {format_duration(event.duration_sec)}",
                        f"  최고값: {event.peak_value:.1f}" if event.peak_value is not None else "  최고값: 값 없음",
                        f"  주요 후보: {process_text}",
                        f"  설명: {event.description}",
                        "",
                    ]
                )
        else:
            lines.append("과부하 이벤트가 없습니다.")

        lines.append(_line("상위 프로세스"))
        for proc in bundle.analysis.top_processes[:10]:
            lines.append(
                f"- {proc.process_name} (PID {proc.pid}) / 평균 CPU {format_percent(proc.cpu_avg)} / "
                f"평균 메모리 {format_gb_from_mb(proc.memory_avg_mb)} / "
                f"디스크 읽기 {format_bytes(proc.disk_read_total_bytes)} / 디스크 쓰기 {format_bytes(proc.disk_write_total_bytes)}"
            )

        lines.append(_line("자연어 분석 요약"))
        lines.append(bundle.analysis.narrative_summary)
        lines.append("")
        lines.append("권장 조치")
        for recommendation in bundle.analysis.recommendations:
            lines.append(f"- {recommendation}")

    target_path.write_text("\n".join(lines), encoding="utf-8")
    return target_path
