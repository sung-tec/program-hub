from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.constants import APP_NAME, EVENT_TYPE_LABELS
from app.logger import get_logger
from app.models import SessionBundle
from app.paths import get_malgun_font_candidates
from app.utils import (
    format_bytes,
    format_bytes_per_sec,
    format_duration,
    format_gb_from_mb,
    format_mb,
    format_percent,
    format_temperature,
    grouped_system_info,
    now_local,
    parse_iso,
    sanitize_filename,
    to_display_datetime,
)

LOGGER = get_logger(__name__)


def _register_font() -> str:
    for candidate in get_malgun_font_candidates():
        try:
            pdfmetrics.registerFont(TTFont("MalgunGothic", str(candidate)))
            return "MalgunGothic"
        except Exception:
            continue
    LOGGER.warning("malgun.ttf를 찾지 못해 PDF 한글 폰트 fallback을 사용합니다.")
    return "Helvetica"


def _configure_matplotlib_font() -> None:
    for candidate in get_malgun_font_candidates():
        try:
            font_manager.fontManager.addfont(str(candidate))
            font_name = font_manager.FontProperties(fname=str(candidate)).get_name()
            plt.rcParams["font.family"] = font_name
            plt.rcParams["axes.unicode_minus"] = False
            return
        except Exception:
            continue


def _build_styles(font_name: str):
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="KoreanHeading",
            parent=styles["Heading1"],
            fontName=font_name,
            fontSize=18,
            leading=24,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="KoreanSubHeading",
            parent=styles["Heading2"],
            fontName=font_name,
            fontSize=13,
            leading=18,
            spaceBefore=8,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="KoreanBody",
            parent=styles["BodyText"],
            fontName=font_name,
            fontSize=9.5,
            leading=14,
        )
    )
    return styles


def _table(data: list[list[str]], font_name: str, col_widths=None) -> Table:
    table = Table(data, colWidths=col_widths, repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (-1, -1), font_name),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef7")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#1f2933")),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#bcccdc")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fbff")]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return table


def _elapsed_minutes(samples) -> list[float]:
    if not samples:
        return []
    first_dt = parse_iso(samples[0].collected_at)
    if first_dt is None:
        return list(range(len(samples)))
    values = []
    for sample in samples:
        dt = parse_iso(sample.collected_at)
        if dt is None:
            values.append(float(len(values)))
        else:
            values.append((dt - first_dt).total_seconds() / 60.0)
    return values


def _shade_overloads(ax, samples, overload_events) -> None:
    if not samples:
        return
    first_dt = parse_iso(samples[0].collected_at)
    if first_dt is None:
        return
    for event in overload_events:
        start_dt = parse_iso(event.started_at)
        end_dt = parse_iso(event.ended_at)
        if start_dt is None or end_dt is None:
            continue
        start_x = (start_dt - first_dt).total_seconds() / 60.0
        end_x = (end_dt - first_dt).total_seconds() / 60.0
        if end_x >= 0:
            ax.axvspan(max(start_x, 0.0), max(end_x, 0.0), alpha=0.15)


def _save_chart(
    samples,
    overload_events,
    chart_path: Path,
    title: str,
    y_label: str,
    series: list[tuple[str, str]],
) -> Path | None:
    if not samples:
        return None
    xs = _elapsed_minutes(samples)
    fig, ax = plt.subplots(figsize=(8.2, 3.1))
    has_any = False
    for metric_key, label in series:
        ys = [getattr(sample, metric_key) for sample in samples]
        valid_xs = [x for x, y in zip(xs, ys) if y is not None]
        valid_ys = [y for y in ys if y is not None]
        if valid_xs and valid_ys:
            ax.plot(valid_xs, valid_ys, label=label, linewidth=1.8)
            has_any = True
    _shade_overloads(ax, samples, overload_events)
    ax.set_title(title)
    ax.set_xlabel("경과 시간(분)")
    ax.set_ylabel(y_label)
    ax.grid(alpha=0.3)
    if len(series) > 1:
        ax.legend()
    if not has_any:
        ax.text(0.5, 0.5, "데이터 없음", ha="center", va="center", transform=ax.transAxes)
    fig.tight_layout()
    fig.savefig(chart_path, dpi=160)
    plt.close(fig)
    return chart_path


def _save_top_process_chart(process_summaries, chart_path: Path) -> Path | None:
    if not process_summaries:
        return None
    top_items = list(process_summaries[:10])
    names = [item.process_name[:12] for item in top_items]
    cpu_values = [item.cpu_avg or 0.0 for item in top_items]

    fig, ax = plt.subplots(figsize=(8.2, 3.4))
    ax.bar(names, cpu_values)
    ax.set_title("상위 프로세스 평균 CPU 사용률")
    ax.set_ylabel("CPU %")
    ax.grid(axis="y", alpha=0.3)
    plt.xticks(rotation=30, ha="right")
    fig.tight_layout()
    fig.savefig(chart_path, dpi=160)
    plt.close(fig)
    return chart_path


def export_bundle_to_pdf(bundle: SessionBundle, output_dir: str | Path, charts_dir: str | Path) -> Path:
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    charts_root = Path(charts_dir)
    charts_root.mkdir(parents=True, exist_ok=True)

    file_name = f"PCInsightMonitor_Report_{bundle.session.id}_{now_local().strftime('%Y%m%d_%H%M%S')}.pdf"
    target_path = output_root / sanitize_filename(file_name)

    font_name = _register_font()
    _configure_matplotlib_font()
    styles = _build_styles(font_name)

    doc = SimpleDocTemplate(
        str(target_path),
        pagesize=A4,
        rightMargin=14 * mm,
        leftMargin=14 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
    )
    story = []

    story.append(Paragraph(f"{APP_NAME} 보고서", styles["KoreanHeading"]))
    story.append(Paragraph(f"생성 일시: {to_display_datetime(now_local().isoformat())}", styles["KoreanBody"]))
    story.append(Spacer(1, 6))

    session_rows = [
        ["항목", "값"],
        ["세션 ID", str(bundle.session.id)],
        ["세션명", bundle.session.session_name],
        ["시작 시각", to_display_datetime(bundle.session.started_at)],
        ["종료 시각", to_display_datetime(bundle.session.ended_at)],
        ["상태", bundle.session.status],
        ["샘플 간격", f"{bundle.session.sample_interval_sec}초"],
        ["샘플 수", str(len(bundle.metric_samples))],
        ["과부하 이벤트 수", str(len(bundle.overload_events))],
        ["세션 길이", format_duration(bundle.analysis.session_duration_sec) if bundle.analysis else "값 없음"],
    ]
    story.append(Paragraph("세션 요약", styles["KoreanSubHeading"]))
    story.append(_table(session_rows, font_name, col_widths=[45 * mm, 130 * mm]))
    story.append(Spacer(1, 6))

    story.append(Paragraph("시스템 사양 요약", styles["KoreanSubHeading"]))
    grouped = grouped_system_info(bundle.system_info)
    for category, items in grouped.items():
        story.append(Paragraph(category, styles["KoreanBody"]))
        rows = [["항목", "값"]] + [[item.key, item.value] for item in items]
        story.append(_table(rows, font_name, col_widths=[55 * mm, 120 * mm]))
        story.append(Spacer(1, 4))

    if bundle.analysis:
        story.append(PageBreak())
        story.append(Paragraph("통계 요약", styles["KoreanSubHeading"]))
        stat_rows = [["지표", "평균", "최소", "최대", "p95"]]
        for stat in bundle.analysis.stats:
            if stat.metric_key in {"cpu_percent", "gpu_percent", "ram_percent"}:
                formatter = format_percent
            elif stat.metric_key in {"cpu_temp_c", "gpu_temp_c"}:
                formatter = format_temperature
            elif stat.metric_key in {"ram_used_mb", "gpu_mem_used_mb"}:
                formatter = format_gb_from_mb
            elif stat.metric_key.endswith("_bps"):
                formatter = format_bytes_per_sec
            elif stat.metric_key == "cpu_clock_mhz":
                formatter = lambda value: f"{value:.0f} MHz" if value is not None else "값 없음"
            else:
                formatter = lambda value: "값 없음" if value is None else f"{value:.2f}"

            stat_rows.append(
                [
                    stat.display_name,
                    formatter(stat.average),
                    formatter(stat.minimum),
                    formatter(stat.maximum),
                    formatter(stat.p95),
                ]
            )
        story.append(_table(stat_rows, font_name, col_widths=[42 * mm, 35 * mm, 35 * mm, 35 * mm, 35 * mm]))
        story.append(Spacer(1, 6))

        story.append(Paragraph("과부하 이벤트", styles["KoreanSubHeading"]))
        event_rows = [["이벤트", "시작", "종료", "지속", "최고값", "원인 후보"]]
        for event in bundle.analysis.overload_events:
            processes = []
            try:
                processes = json.loads(event.suspected_processes_json)
            except Exception:
                processes = []
            process_text = ", ".join(item.get("process_name", "") for item in processes if isinstance(item, dict)) or "원인 후보 없음"
            event_rows.append(
                [
                    EVENT_TYPE_LABELS.get(event.event_type, event.event_type),
                    to_display_datetime(event.started_at),
                    to_display_datetime(event.ended_at),
                    format_duration(event.duration_sec),
                    f"{event.peak_value:.1f}" if event.peak_value is not None else "값 없음",
                    process_text,
                ]
            )
        story.append(_table(event_rows, font_name, col_widths=[26 * mm, 34 * mm, 34 * mm, 24 * mm, 22 * mm, 55 * mm]))
        story.append(Spacer(1, 6))

        story.append(Paragraph("주요 프로세스", styles["KoreanSubHeading"]))
        process_rows = [["프로세스명", "PID", "평균 CPU", "최대 CPU", "평균 메모리", "디스크 읽기", "디스크 쓰기"]]
        for item in bundle.analysis.top_processes[:10]:
            process_rows.append(
                [
                    item.process_name,
                    str(item.pid),
                    format_percent(item.cpu_avg),
                    format_percent(item.cpu_max),
                    format_gb_from_mb(item.memory_avg_mb),
                    format_bytes(item.disk_read_total_bytes),
                    format_bytes(item.disk_write_total_bytes),
                ]
            )
        story.append(_table(process_rows, font_name, col_widths=[45 * mm, 16 * mm, 23 * mm, 23 * mm, 25 * mm, 26 * mm, 26 * mm]))
        story.append(Spacer(1, 8))

    chart_specs = [
        ("cpu_ram", "CPU / RAM 추이", "% / GB", [("cpu_percent", "CPU 사용률"), ("ram_percent", "RAM 사용률")]),
        ("temperatures", "CPU / GPU 온도 추이", "°C", [("cpu_temp_c", "CPU 온도"), ("gpu_temp_c", "GPU 온도")]),
        ("gpu", "GPU 사용률 추이", "%", [("gpu_percent", "GPU 사용률")]),
        ("disk_net", "디스크 / 네트워크 추이", "B/s", [("disk_read_bps", "디스크 읽기"), ("net_recv_bps", "네트워크 수신")]),
    ]
    for chart_key, title, y_label, series in chart_specs:
        chart_path = charts_root / f"{bundle.session.id}_{chart_key}.png"
        image_path = _save_chart(bundle.metric_samples, bundle.overload_events, chart_path, title, y_label, series)
        if image_path is not None:
            story.append(Paragraph(title, styles["KoreanSubHeading"]))
            story.append(Image(str(image_path), width=175 * mm, height=66 * mm))
            story.append(Spacer(1, 5))

    top_chart_path = charts_root / f"{bundle.session.id}_top_processes.png"
    top_image = _save_top_process_chart(bundle.process_summaries, top_chart_path)
    if top_image is not None:
        story.append(Paragraph("상위 프로세스 그래프", styles["KoreanSubHeading"]))
        story.append(Image(str(top_image), width=175 * mm, height=70 * mm))
        story.append(Spacer(1, 6))

    if bundle.analysis:
        story.append(Paragraph("자연어 분석 요약", styles["KoreanSubHeading"]))
        story.append(Paragraph(bundle.analysis.narrative_summary.replace("\n", "<br/>"), styles["KoreanBody"]))
        story.append(Spacer(1, 5))
        story.append(Paragraph("권장 조치", styles["KoreanSubHeading"]))
        for recommendation in bundle.analysis.recommendations:
            story.append(Paragraph(f"• {recommendation}", styles["KoreanBody"]))

    doc.build(story)
    return target_path
