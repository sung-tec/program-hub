from __future__ import annotations

import json
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.constants import APP_NAME, EVENT_TYPE_LABELS
from app.models import SessionBundle
from app.utils import now_local, sanitize_filename, to_display_datetime


_HEADER_FILL = PatternFill(fill_type="solid", fgColor="DDEBF7")


def _style_sheet(ws) -> None:
    if ws.max_row <= 0:
        return
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = _HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = "A2"
    for column_cells in ws.columns:
        max_length = 0
        col_letter = get_column_letter(column_cells[0].column)
        for cell in column_cells:
            value = "" if cell.value is None else str(cell.value)
            max_length = max(max_length, len(value))
        ws.column_dimensions[col_letter].width = min(max(max_length + 2, 10), 40)


def _append_rows(ws, headers: list[str], rows: list[list[object]]) -> None:
    ws.append(headers)
    for row in rows:
        ws.append(row)
    _style_sheet(ws)


def export_bundle_to_excel(bundle: SessionBundle, output_dir: str | Path) -> Path:
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    file_name = f"PCInsightMonitor_Report_{bundle.session.id}_{now_local().strftime('%Y%m%d_%H%M%S')}.xlsx"
    target_path = output_root / sanitize_filename(file_name)

    wb = Workbook()
    default_sheet = wb.active
    wb.remove(default_sheet)

    ws_info = wb.create_sheet("system_info")
    _append_rows(
        ws_info,
        ["category", "key", "value"],
        [[item.category, item.key, item.value] for item in bundle.system_info],
    )

    ws_summary = wb.create_sheet("session_summary")
    summary_rows = [
        ["report_title", APP_NAME],
        ["generated_at", to_display_datetime(now_local().isoformat())],
        ["session_id", bundle.session.id],
        ["session_name", bundle.session.session_name],
        ["started_at", to_display_datetime(bundle.session.started_at)],
        ["ended_at", to_display_datetime(bundle.session.ended_at)],
        ["status", bundle.session.status],
        ["sample_interval_sec", bundle.session.sample_interval_sec],
        ["notes", bundle.session.notes],
    ]
    if bundle.analysis:
        summary_rows.extend(
            [
                ["session_duration_sec", bundle.analysis.session_duration_sec],
                ["sample_count", bundle.analysis.sample_count],
                ["total_overload_count", bundle.analysis.total_overload_count],
                ["peak_time_window", bundle.analysis.peak_time_window],
                ["bottleneck_summary", bundle.analysis.bottleneck_summary],
                ["narrative_summary", bundle.analysis.narrative_summary],
                ["recommendations", " / ".join(bundle.analysis.recommendations)],
            ]
        )
    _append_rows(ws_summary, ["key", "value"], summary_rows)

    ws_metric = wb.create_sheet("metric_samples")
    _append_rows(
        ws_metric,
        [
            "collected_at",
            "cpu_percent",
            "cpu_clock_mhz",
            "cpu_temp_c",
            "gpu_percent",
            "gpu_mem_used_mb",
            "gpu_temp_c",
            "ram_used_mb",
            "ram_percent",
            "disk_read_bps",
            "disk_write_bps",
            "net_sent_bps",
            "net_recv_bps",
        ],
        [
            [
                item.collected_at,
                item.cpu_percent,
                item.cpu_clock_mhz,
                item.cpu_temp_c,
                item.gpu_percent,
                item.gpu_mem_used_mb,
                item.gpu_temp_c,
                item.ram_used_mb,
                item.ram_percent,
                item.disk_read_bps,
                item.disk_write_bps,
                item.net_sent_bps,
                item.net_recv_bps,
            ]
            for item in bundle.metric_samples
        ],
    )

    ws_process_samples = wb.create_sheet("process_samples")
    _append_rows(
        ws_process_samples,
        [
            "collected_at",
            "pid",
            "process_name",
            "cpu_percent",
            "memory_mb",
            "disk_read_bytes",
            "disk_write_bytes",
            "gpu_percent",
            "status",
        ],
        [
            [
                item.collected_at,
                item.pid,
                item.process_name,
                item.cpu_percent,
                item.memory_mb,
                item.disk_read_bytes,
                item.disk_write_bytes,
                item.gpu_percent,
                item.status,
            ]
            for item in bundle.process_samples
        ],
    )

    ws_process_summary = wb.create_sheet("process_summaries")
    _append_rows(
        ws_process_summary,
        [
            "pid",
            "process_name",
            "first_seen_at",
            "last_seen_at",
            "runtime_sec",
            "cpu_avg",
            "cpu_max",
            "memory_avg_mb",
            "memory_max_mb",
            "disk_read_total_bytes",
            "disk_write_total_bytes",
            "gpu_avg",
            "gpu_max",
            "last_status",
        ],
        [
            [
                item.pid,
                item.process_name,
                item.first_seen_at,
                item.last_seen_at,
                item.runtime_sec,
                item.cpu_avg,
                item.cpu_max,
                item.memory_avg_mb,
                item.memory_max_mb,
                item.disk_read_total_bytes,
                item.disk_write_total_bytes,
                item.gpu_avg,
                item.gpu_max,
                item.last_status,
            ]
            for item in bundle.process_summaries
        ],
    )

    ws_events = wb.create_sheet("overload_events")
    _append_rows(
        ws_events,
        [
            "event_type",
            "event_label",
            "started_at",
            "ended_at",
            "duration_sec",
            "threshold_value",
            "peak_value",
            "suspected_processes_json",
            "description",
        ],
        [
            [
                event.event_type,
                EVENT_TYPE_LABELS.get(event.event_type, event.event_type),
                event.started_at,
                event.ended_at,
                event.duration_sec,
                event.threshold_value,
                event.peak_value,
                event.suspected_processes_json,
                event.description,
            ]
            for event in bundle.overload_events
        ],
    )

    wb.save(target_path)
    return target_path
