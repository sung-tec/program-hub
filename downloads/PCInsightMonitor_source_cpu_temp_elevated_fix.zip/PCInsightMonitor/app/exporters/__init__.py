from __future__ import annotations

from pathlib import Path

from app.constants import EXPORT_FORMAT_PDF, EXPORT_FORMAT_TXT, EXPORT_FORMAT_XLSX
from app.models import SessionBundle
from app.paths import AppPaths
from app.exporters.excel_exporter import export_bundle_to_excel
from app.exporters.pdf_exporter import export_bundle_to_pdf
from app.exporters.txt_exporter import export_bundle_to_txt


def export_session_bundle(bundle: SessionBundle, export_format: str, output_dir: str | Path, app_paths: AppPaths) -> Path:
    export_format = export_format.lower()
    if export_format == EXPORT_FORMAT_PDF:
        return export_bundle_to_pdf(bundle, output_dir, app_paths.charts_dir)
    if export_format == EXPORT_FORMAT_TXT:
        return export_bundle_to_txt(bundle, output_dir)
    if export_format == EXPORT_FORMAT_XLSX:
        return export_bundle_to_excel(bundle, output_dir)
    raise ValueError(f"지원하지 않는 내보내기 형식입니다: {export_format}")
