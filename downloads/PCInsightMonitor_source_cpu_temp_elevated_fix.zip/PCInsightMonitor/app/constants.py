from __future__ import annotations

APP_NAME = "PC Insight Monitor"
APP_VERSION = "1.0.0"
ORGANIZATION_NAME = "PC Insight Monitor"
ORGANIZATION_DOMAIN = "pcinsightmonitor.local"

VALUE_UNSUPPORTED = "지원 안 함"
VALUE_UNAVAILABLE = "값 없음"
VALUE_COLLECTION_FAILED = "수집 실패"

SESSION_STATUS_IDLE = "대기 중"
SESSION_STATUS_RUNNING = "모니터링 중"
SESSION_STATUS_PAUSED = "일시정지"
SESSION_STATUS_STOPPED = "종료됨"

EXPORT_FORMAT_PDF = "pdf"
EXPORT_FORMAT_TXT = "txt"
EXPORT_FORMAT_XLSX = "xlsx"
EXPORT_FORMATS = (EXPORT_FORMAT_PDF, EXPORT_FORMAT_TXT, EXPORT_FORMAT_XLSX)

OVERLOAD_CPU_USAGE = "CPU_USAGE_HIGH"
OVERLOAD_CPU_TEMP = "CPU_TEMP_HIGH"
OVERLOAD_GPU_USAGE = "GPU_USAGE_HIGH"
OVERLOAD_GPU_TEMP = "GPU_TEMP_HIGH"
OVERLOAD_RAM = "RAM_HIGH"
OVERLOAD_EVENT_TYPES = (
    OVERLOAD_CPU_USAGE,
    OVERLOAD_CPU_TEMP,
    OVERLOAD_GPU_USAGE,
    OVERLOAD_GPU_TEMP,
    OVERLOAD_RAM,
)

DEFAULT_SAMPLE_INTERVAL_SEC = 2
MIN_SAMPLE_INTERVAL_SEC = 1
MAX_SAMPLE_INTERVAL_SEC = 30
DEFAULT_LOG_RETENTION_DAYS = 30
DEFAULT_TOP_PROCESS_COUNT = 20
DEFAULT_HISTORY_LIMIT = 500
DEFAULT_OVERLOAD_DURATION_SEC = 30
DEFAULT_EVENT_MERGE_GAP_SEC = 5

DEFAULT_THRESHOLDS = {
    "cpu_usage_percent": 85.0,
    "gpu_usage_percent": 90.0,
    "ram_percent": 90.0,
    "cpu_temp_c": 80.0,
    "gpu_temp_c": 80.0,
    "duration_sec": DEFAULT_OVERLOAD_DURATION_SEC,
    "merge_gap_sec": DEFAULT_EVENT_MERGE_GAP_SEC,
}

DEFAULT_SENSOR_OPTIONS = {
    "enable_cpu_temperature": True,
    "enable_gpu_metrics": True,
    "enable_gpu_temperature": True,
    "enable_hardware_probe": True,
    "enable_battery_probe": True,
}

DEFAULT_SETTINGS = {
    "sample_interval_sec": DEFAULT_SAMPLE_INTERVAL_SEC,
    "auto_save": True,
    "auto_start": False,
    "log_retention_days": DEFAULT_LOG_RETENTION_DAYS,
    "dark_mode": False,
    "default_export_format": EXPORT_FORMAT_PDF,
    "export_base_dir": "",
    "top_process_count": DEFAULT_TOP_PROCESS_COUNT,
    "history_limit": DEFAULT_HISTORY_LIMIT,
    "overload_thresholds": DEFAULT_THRESHOLDS,
    "sensor_options": DEFAULT_SENSOR_OPTIONS,
}

SYSTEM_INFO_HEADERS = ("구분", "항목", "값")
PROCESS_TABLE_HEADERS = (
    "프로세스명",
    "PID",
    "시작 시각",
    "실행 시간",
    "현재 CPU(%)",
    "평균 CPU(%)",
    "최대 CPU(%)",
    "현재 메모리(MB)",
    "평균 메모리(MB)",
    "최대 메모리(MB)",
    "디스크 읽기 누적",
    "디스크 쓰기 누적",
    "GPU(%)",
    "상태",
)
SESSION_TABLE_HEADERS = (
    "ID",
    "세션명",
    "시작 시각",
    "종료 시각",
    "상태",
    "샘플 간격(초)",
    "비고",
)

METRIC_DISPLAY_NAMES = {
    "cpu_percent": "CPU 사용률",
    "cpu_clock_mhz": "CPU 클럭",
    "cpu_temp_c": "CPU 온도",
    "gpu_percent": "GPU 사용률",
    "gpu_mem_used_mb": "GPU 메모리 사용량",
    "gpu_temp_c": "GPU 온도",
    "ram_used_mb": "RAM 사용량",
    "ram_percent": "RAM 사용률",
    "disk_read_bps": "디스크 읽기 속도",
    "disk_write_bps": "디스크 쓰기 속도",
    "net_sent_bps": "네트워크 송신 속도",
    "net_recv_bps": "네트워크 수신 속도",
}

METRIC_UNITS = {
    "cpu_percent": "%",
    "cpu_clock_mhz": "MHz",
    "cpu_temp_c": "°C",
    "gpu_percent": "%",
    "gpu_mem_used_mb": "MB",
    "gpu_temp_c": "°C",
    "ram_used_mb": "MB",
    "ram_percent": "%",
    "disk_read_bps": "B/s",
    "disk_write_bps": "B/s",
    "net_sent_bps": "B/s",
    "net_recv_bps": "B/s",
}

EVENT_TYPE_LABELS = {
    OVERLOAD_CPU_USAGE: "CPU 사용률 과부하",
    OVERLOAD_CPU_TEMP: "CPU 온도 과부하",
    OVERLOAD_GPU_USAGE: "GPU 사용률 과부하",
    OVERLOAD_GPU_TEMP: "GPU 온도 과부하",
    OVERLOAD_RAM: "RAM 사용률 과부하",
}

TIME_RANGE_OPTIONS = {
    "최근 5분": 5,
    "최근 15분": 15,
    "최근 30분": 30,
    "전체 세션": None,
}

CARD_OBJECT_NAME = "metricCard"
WARNING_BOX_OBJECT_NAME = "warningBox"
SUMMARY_CARD_OBJECT_NAME = "summaryCard"

CHART_FILE_PREFIX = "pc_insight_chart"
PDF_FONT_CANDIDATE = "malgun.ttf"
