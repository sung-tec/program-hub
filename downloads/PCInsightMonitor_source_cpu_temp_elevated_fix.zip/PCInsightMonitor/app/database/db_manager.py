from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

from app.logger import get_logger
from app.models import (
    MetricSample,
    OverloadEvent,
    ProcessSample,
    ProcessSummary,
    SessionRecord,
    SystemInfoItem,
)
from app.utils import parse_iso

LOGGER = get_logger(__name__)


class DatabaseManager:
    def __init__(self, db_file: str | Path) -> None:
        self.db_file = Path(db_file)
        self.db_file.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.db_file, timeout=30, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("PRAGMA synchronous = NORMAL")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def initialize_database(self) -> None:
        schema_statements = [
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_name TEXT NOT NULL,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                status TEXT NOT NULL,
                sample_interval_sec INTEGER NOT NULL,
                notes TEXT DEFAULT ''
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS system_info_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                collected_at TEXT NOT NULL,
                key TEXT NOT NULL,
                value TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS metric_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                collected_at TEXT NOT NULL,
                cpu_percent REAL,
                cpu_clock_mhz REAL,
                cpu_temp_c REAL,
                gpu_percent REAL,
                gpu_mem_used_mb REAL,
                gpu_temp_c REAL,
                ram_used_mb REAL,
                ram_percent REAL,
                disk_read_bps REAL,
                disk_write_bps REAL,
                net_sent_bps REAL,
                net_recv_bps REAL,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS process_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                collected_at TEXT NOT NULL,
                pid INTEGER NOT NULL,
                process_name TEXT NOT NULL,
                cpu_percent REAL,
                memory_mb REAL,
                disk_read_bytes INTEGER,
                disk_write_bytes INTEGER,
                gpu_percent REAL,
                status TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS process_summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                pid INTEGER NOT NULL,
                process_name TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                runtime_sec REAL NOT NULL,
                cpu_avg REAL,
                cpu_max REAL,
                memory_avg_mb REAL,
                memory_max_mb REAL,
                disk_read_total_bytes INTEGER NOT NULL,
                disk_write_total_bytes INTEGER NOT NULL,
                gpu_avg REAL,
                gpu_max REAL,
                last_status TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS overload_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                duration_sec REAL,
                threshold_value REAL NOT NULL,
                peak_value REAL,
                suspected_processes_json TEXT NOT NULL,
                description TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_metric_samples_session_time ON metric_samples(session_id, collected_at)",
            "CREATE INDEX IF NOT EXISTS idx_process_samples_session_time ON process_samples(session_id, collected_at)",
            "CREATE INDEX IF NOT EXISTS idx_process_summaries_session ON process_summaries(session_id)",
            "CREATE INDEX IF NOT EXISTS idx_overload_events_session ON overload_events(session_id)",
            "CREATE INDEX IF NOT EXISTS idx_system_info_session ON system_info_snapshots(session_id)",
        ]
        with self._lock, self._connect() as conn:
            for statement in schema_statements:
                conn.execute(statement)

    def insert_session(
        self,
        session_name: str,
        started_at: str,
        status: str,
        sample_interval_sec: int,
        notes: str = "",
    ) -> int:
        with self._lock, self._connect() as conn:
            cursor = conn.execute(
                """
                INSERT INTO sessions (session_name, started_at, ended_at, status, sample_interval_sec, notes)
                VALUES (?, ?, NULL, ?, ?, ?)
                """,
                (session_name, started_at, status, sample_interval_sec, notes),
            )
            return int(cursor.lastrowid)

    def update_session(
        self,
        session_id: int,
        *,
        ended_at: str | None = None,
        status: str | None = None,
        notes: str | None = None,
    ) -> None:
        fields: list[str] = []
        values: list[Any] = []
        if ended_at is not None:
            fields.append("ended_at = ?")
            values.append(ended_at)
        if status is not None:
            fields.append("status = ?")
            values.append(status)
        if notes is not None:
            fields.append("notes = ?")
            values.append(notes)
        if not fields:
            return
        values.append(session_id)
        sql = f"UPDATE sessions SET {', '.join(fields)} WHERE id = ?"
        with self._lock, self._connect() as conn:
            conn.execute(sql, values)

    def save_system_info_snapshot(
        self,
        session_id: int,
        collected_at: str,
        items: Sequence[SystemInfoItem],
    ) -> None:
        payload = [
            (session_id, collected_at, item.db_key(), item.value)
            for item in items
        ]
        with self._lock, self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO system_info_snapshots (session_id, collected_at, key, value)
                VALUES (?, ?, ?, ?)
                """,
                payload,
            )

    def insert_metric_sample(self, session_id: int, sample: MetricSample) -> None:
        self.insert_metric_samples(session_id, [sample])

    def insert_metric_samples(self, session_id: int, samples: Sequence[MetricSample]) -> None:
        if not samples:
            return
        payload = [
            (
                session_id,
                sample.collected_at,
                sample.cpu_percent,
                sample.cpu_clock_mhz,
                sample.cpu_temp_c,
                sample.gpu_percent,
                sample.gpu_mem_used_mb,
                sample.gpu_temp_c,
                sample.ram_used_mb,
                sample.ram_percent,
                sample.disk_read_bps,
                sample.disk_write_bps,
                sample.net_sent_bps,
                sample.net_recv_bps,
            )
            for sample in samples
        ]
        with self._lock, self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO metric_samples (
                    session_id, collected_at, cpu_percent, cpu_clock_mhz, cpu_temp_c,
                    gpu_percent, gpu_mem_used_mb, gpu_temp_c, ram_used_mb, ram_percent,
                    disk_read_bps, disk_write_bps, net_sent_bps, net_recv_bps
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                payload,
            )

    def insert_process_samples(self, session_id: int, samples: Sequence[ProcessSample]) -> None:
        if not samples:
            return
        payload = [
            (
                session_id,
                sample.collected_at,
                sample.pid,
                sample.process_name,
                sample.cpu_percent,
                sample.memory_mb,
                sample.disk_read_bytes,
                sample.disk_write_bytes,
                sample.gpu_percent,
                sample.status,
            )
            for sample in samples
        ]
        with self._lock, self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO process_samples (
                    session_id, collected_at, pid, process_name, cpu_percent, memory_mb,
                    disk_read_bytes, disk_write_bytes, gpu_percent, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                payload,
            )

    def replace_process_summaries(self, session_id: int, summaries: Sequence[ProcessSummary]) -> None:
        with self._lock, self._connect() as conn:
            conn.execute("DELETE FROM process_summaries WHERE session_id = ?", (session_id,))
            if summaries:
                conn.executemany(
                    """
                    INSERT INTO process_summaries (
                        session_id, pid, process_name, first_seen_at, last_seen_at, runtime_sec,
                        cpu_avg, cpu_max, memory_avg_mb, memory_max_mb,
                        disk_read_total_bytes, disk_write_total_bytes, gpu_avg, gpu_max, last_status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            session_id,
                            summary.pid,
                            summary.process_name,
                            summary.first_seen_at,
                            summary.last_seen_at,
                            summary.runtime_sec,
                            summary.cpu_avg,
                            summary.cpu_max,
                            summary.memory_avg_mb,
                            summary.memory_max_mb,
                            summary.disk_read_total_bytes,
                            summary.disk_write_total_bytes,
                            summary.gpu_avg,
                            summary.gpu_max,
                            summary.last_status,
                        )
                        for summary in summaries
                    ],
                )

    def replace_overload_events(self, session_id: int, events: Sequence[OverloadEvent]) -> None:
        with self._lock, self._connect() as conn:
            conn.execute("DELETE FROM overload_events WHERE session_id = ?", (session_id,))
            if events:
                conn.executemany(
                    """
                    INSERT INTO overload_events (
                        session_id, event_type, started_at, ended_at, duration_sec,
                        threshold_value, peak_value, suspected_processes_json, description
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            session_id,
                            event.event_type,
                            event.started_at,
                            event.ended_at,
                            event.duration_sec,
                            event.threshold_value,
                            event.peak_value,
                            event.suspected_processes_json,
                            event.description,
                        )
                        for event in events
                    ],
                )

    def get_sessions(self, status: str | None = None, limit: int = 500) -> list[SessionRecord]:
        sql = """
            SELECT id, session_name, started_at, ended_at, status, sample_interval_sec, notes
            FROM sessions
        """
        params: list[Any] = []
        if status:
            sql += " WHERE status = ?"
            params.append(status)
        sql += " ORDER BY started_at DESC LIMIT ?"
        params.append(limit)
        with self._lock, self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [self._row_to_session(row) for row in rows]

    def get_session(self, session_id: int) -> SessionRecord | None:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                """
                SELECT id, session_name, started_at, ended_at, status, sample_interval_sec, notes
                FROM sessions WHERE id = ?
                """,
                (session_id,),
            ).fetchone()
        return self._row_to_session(row) if row else None

    def get_system_info_snapshot(self, session_id: int) -> list[SystemInfoItem]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                """
                SELECT key, value, MAX(collected_at) AS latest_at
                FROM system_info_snapshots
                WHERE session_id = ?
                GROUP BY key, value
                ORDER BY key ASC
                """,
                (session_id,),
            ).fetchall()
        items = [SystemInfoItem.from_db(row["key"], row["value"]) for row in rows]
        items.sort(key=lambda item: (item.category, item.key))
        return items

    def get_metric_samples(self, session_id: int) -> list[MetricSample]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                """
                SELECT collected_at, cpu_percent, cpu_clock_mhz, cpu_temp_c, gpu_percent,
                       gpu_mem_used_mb, gpu_temp_c, ram_used_mb, ram_percent,
                       disk_read_bps, disk_write_bps, net_sent_bps, net_recv_bps
                FROM metric_samples
                WHERE session_id = ?
                ORDER BY collected_at ASC
                """,
                (session_id,),
            ).fetchall()
        return [
            MetricSample(
                collected_at=row["collected_at"],
                cpu_percent=row["cpu_percent"],
                cpu_clock_mhz=row["cpu_clock_mhz"],
                cpu_temp_c=row["cpu_temp_c"],
                gpu_percent=row["gpu_percent"],
                gpu_mem_used_mb=row["gpu_mem_used_mb"],
                gpu_temp_c=row["gpu_temp_c"],
                ram_used_mb=row["ram_used_mb"],
                ram_percent=row["ram_percent"],
                disk_read_bps=row["disk_read_bps"],
                disk_write_bps=row["disk_write_bps"],
                net_sent_bps=row["net_sent_bps"],
                net_recv_bps=row["net_recv_bps"],
            )
            for row in rows
        ]

    def get_process_samples(self, session_id: int) -> list[ProcessSample]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                """
                SELECT collected_at, pid, process_name, cpu_percent, memory_mb,
                       disk_read_bytes, disk_write_bytes, gpu_percent, status
                FROM process_samples
                WHERE session_id = ?
                ORDER BY collected_at ASC, pid ASC
                """,
                (session_id,),
            ).fetchall()
        return [
            ProcessSample(
                collected_at=row["collected_at"],
                pid=row["pid"],
                process_name=row["process_name"],
                cpu_percent=row["cpu_percent"],
                memory_mb=row["memory_mb"],
                disk_read_bytes=row["disk_read_bytes"],
                disk_write_bytes=row["disk_write_bytes"],
                gpu_percent=row["gpu_percent"],
                status=row["status"],
            )
            for row in rows
        ]

    def get_process_summaries(self, session_id: int) -> list[ProcessSummary]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                """
                SELECT session_id, pid, process_name, first_seen_at, last_seen_at, runtime_sec,
                       cpu_avg, cpu_max, memory_avg_mb, memory_max_mb,
                       disk_read_total_bytes, disk_write_total_bytes, gpu_avg, gpu_max, last_status
                FROM process_summaries
                WHERE session_id = ?
                ORDER BY COALESCE(cpu_avg, 0) DESC, COALESCE(memory_avg_mb, 0) DESC, pid ASC
                """,
                (session_id,),
            ).fetchall()
        return [
            ProcessSummary(
                session_id=row["session_id"],
                pid=row["pid"],
                process_name=row["process_name"],
                first_seen_at=row["first_seen_at"],
                last_seen_at=row["last_seen_at"],
                runtime_sec=row["runtime_sec"],
                cpu_avg=row["cpu_avg"],
                cpu_max=row["cpu_max"],
                memory_avg_mb=row["memory_avg_mb"],
                memory_max_mb=row["memory_max_mb"],
                disk_read_total_bytes=row["disk_read_total_bytes"] or 0,
                disk_write_total_bytes=row["disk_write_total_bytes"] or 0,
                gpu_avg=row["gpu_avg"],
                gpu_max=row["gpu_max"],
                last_status=row["last_status"],
            )
            for row in rows
        ]

    def get_overload_events(self, session_id: int) -> list[OverloadEvent]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                """
                SELECT session_id, event_type, started_at, ended_at, duration_sec,
                       threshold_value, peak_value, suspected_processes_json, description
                FROM overload_events
                WHERE session_id = ?
                ORDER BY started_at ASC
                """,
                (session_id,),
            ).fetchall()
        return [
            OverloadEvent(
                session_id=row["session_id"],
                event_type=row["event_type"],
                started_at=row["started_at"],
                ended_at=row["ended_at"],
                duration_sec=row["duration_sec"],
                threshold_value=row["threshold_value"],
                peak_value=row["peak_value"],
                suspected_processes_json=row["suspected_processes_json"],
                description=row["description"],
            )
            for row in rows
        ]

    def _row_to_session(self, row: sqlite3.Row) -> SessionRecord:
        return SessionRecord(
            id=int(row["id"]),
            session_name=str(row["session_name"]),
            started_at=str(row["started_at"]),
            ended_at=row["ended_at"],
            status=str(row["status"]),
            sample_interval_sec=int(row["sample_interval_sec"]),
            notes=str(row["notes"] or ""),
        )
