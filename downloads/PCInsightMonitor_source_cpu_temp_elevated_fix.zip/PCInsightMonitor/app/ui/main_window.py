from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QStatusBar,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.config import ConfigManager
from app.constants import APP_NAME, SESSION_STATUS_IDLE, SESSION_STATUS_PAUSED, SESSION_STATUS_RUNNING, SESSION_STATUS_STOPPED
from app.database.db_manager import DatabaseManager
from app.exporters import export_session_bundle
from app.logger import get_logger, get_recent_logs
from app.models import AppSettings, MonitorStatusSnapshot, SessionBundle
from app.paths import AppPaths
from app.services.analysis_service import AnalysisService
from app.services.history_service import HistoryService
from app.services.monitor_service import MonitorService
from app.services.system_info_service import SystemInfoService
from app.ui.tabs.analysis_tab import AnalysisTab
from app.ui.tabs.dashboard_tab import DashboardTab
from app.ui.tabs.graphs_tab import GraphsTab
from app.ui.tabs.history_tab import HistoryTab
from app.ui.tabs.process_tab import ProcessTab
from app.ui.tabs.settings_tab import SettingsTab
from app.ui.tabs.system_info_tab import SystemInfoTab
from app.utils import build_app_stylesheet, make_session_name, open_file_location, to_display_datetime

LOGGER = get_logger(__name__)


class SystemInfoRefreshWorker(QThread):
    result_ready = Signal(object)
    error_signal = Signal(str)

    def __init__(self, settings: AppSettings) -> None:
        super().__init__()
        self.settings = settings

    def run(self) -> None:
        sensor_service = None
        try:
            service = SystemInfoService(self.settings.sensor_options)
            sensor_service = service.sensor_service
            items = service.gather_system_info()
            self.result_ready.emit(items)
        except Exception as exc:
            self.error_signal.emit(f"시스템 사양 새로고침 실패: {exc}")
        finally:
            if sensor_service is not None:
                sensor_service.cleanup()


class MainWindow(QMainWindow):
    def __init__(self, paths: AppPaths, config_manager: ConfigManager, db_manager: DatabaseManager) -> None:
        super().__init__()
        self.paths = paths
        self.config_manager = config_manager
        self.db_manager = db_manager
        self.settings = self.config_manager.get_settings()

        self.analysis_service = AnalysisService(self.settings.overload_thresholds)
        self.history_service = HistoryService(self.db_manager, self.analysis_service)
        self.monitor_service = MonitorService(self.db_manager)

        self.current_status = MonitorStatusSnapshot(session_id=None, session_name="-", state=SESSION_STATUS_IDLE)
        self.current_bundle: SessionBundle | None = None
        self.loaded_history_bundle: SessionBundle | None = None
        self.system_info_worker: SystemInfoRefreshWorker | None = None

        self.setWindowTitle(APP_NAME)
        self.resize(1680, 980)

        self._build_ui()
        self._connect_signals()
        self._load_initial_data()

    def _build_ui(self) -> None:
        central = QWidget()
        root_layout = QVBoxLayout(central)

        header_frame = QFrame()
        header_layout = QHBoxLayout(header_frame)
        title_label = QLabel(APP_NAME)
        title_label.setStyleSheet("font-size: 20pt; font-weight: 800;")
        self.state_badge = QLabel(SESSION_STATUS_IDLE)
        self.state_badge.setStyleSheet("padding: 6px 12px; border-radius: 12px; background-color: #dbeafe; color: #1d4ed8; font-weight: 700;")
        self.session_label = QLabel("현재 세션: 없음")

        header_layout.addWidget(title_label)
        header_layout.addSpacing(12)
        header_layout.addWidget(self.state_badge)
        header_layout.addStretch(1)
        header_layout.addWidget(self.session_label)

        self.tab_widget = QTabWidget()
        self.tab_widget.setDocumentMode(True)
        self.tab_widget.setMovable(False)
        self.dashboard_tab = DashboardTab()
        self.system_info_tab = SystemInfoTab()
        self.process_tab = ProcessTab()
        self.graphs_tab = GraphsTab()
        self.analysis_tab = AnalysisTab()
        self.history_tab = HistoryTab()
        self.settings_tab = SettingsTab()

        self.tab_widget.addTab(self.dashboard_tab, "대시보드")
        self.tab_widget.addTab(self.system_info_tab, "시스템 사양")
        self.tab_widget.addTab(self.process_tab, "프로세스 모니터")
        self.tab_widget.addTab(self.graphs_tab, "그래프")
        self.tab_widget.addTab(self.analysis_tab, "분석 리포트")
        self.tab_widget.addTab(self.history_tab, "기록 / 히스토리")
        self.tab_widget.addTab(self.settings_tab, "설정")

        root_layout.addWidget(header_frame)
        root_layout.addWidget(self.tab_widget, 1)
        self.setCentralWidget(central)

        status_bar = QStatusBar()
        self.setStatusBar(status_bar)
        self.status_last_sample = QLabel("마지막 샘플: 값 없음")
        self.status_db_path = QLabel(f"DB 경로: {self.paths.db_file}")
        self.status_last_saved = QLabel("마지막 저장: 값 없음")
        self.status_error = QLabel("오류 요약: 없음")

        status_bar.addPermanentWidget(self.status_last_sample)
        status_bar.addPermanentWidget(self.status_db_path, 1)
        status_bar.addPermanentWidget(self.status_last_saved)
        status_bar.addPermanentWidget(self.status_error)

    def _connect_signals(self) -> None:
        self.dashboard_tab.start_requested.connect(self.start_monitoring)
        self.dashboard_tab.pause_requested.connect(self.pause_monitoring)
        self.dashboard_tab.resume_requested.connect(self.resume_monitoring)
        self.dashboard_tab.stop_requested.connect(self.stop_monitoring)

        self.system_info_tab.refresh_requested.connect(self.refresh_system_info)

        self.settings_tab.apply_requested.connect(self.apply_settings)
        self.settings_tab.cancel_requested.connect(self.cancel_settings_changes)
        self.settings_tab.reset_requested.connect(self.reset_settings_to_defaults)

        self.history_tab.refresh_requested.connect(self.refresh_history_list)
        self.history_tab.load_requested.connect(self.load_history_session)
        self.history_tab.reanalyze_requested.connect(self.reanalyze_history_session)
        self.history_tab.export_requested.connect(self.export_history_session)

        self.monitor_service.metric_sample_collected.connect(self.on_metric_sample)
        self.monitor_service.process_rows_updated.connect(self.on_process_rows)
        self.monitor_service.system_info_collected.connect(self.on_monitor_system_info)
        self.monitor_service.alerts_updated.connect(self.on_alerts_updated)
        self.monitor_service.status_updated.connect(self.on_status_updated)
        self.monitor_service.session_finished.connect(self.on_session_finished)
        self.monitor_service.error_signal.connect(self.on_error_message)

    def _load_initial_data(self) -> None:
        self.settings_tab.set_settings(self.settings)
        self.analysis_tab.clear()
        self.history_tab.set_detail_bundle(None)
        self.refresh_system_info()
        self.refresh_history_list()
        self.graphs_tab.set_live_mode("대기 중")
        self.dashboard_tab.clear_metrics()
        self.dashboard_tab.update_alerts([])
        if self.settings.auto_start:
            self.start_monitoring()

    def _set_status_badge(self, state: str) -> None:
        color_map = {
            SESSION_STATUS_IDLE: ("#e5e7eb", "#374151"),
            SESSION_STATUS_RUNNING: ("#dcfce7", "#166534"),
            SESSION_STATUS_PAUSED: ("#fef3c7", "#92400e"),
            SESSION_STATUS_STOPPED: ("#e0e7ff", "#3730a3"),
        }
        bg, fg = color_map.get(state, ("#e5e7eb", "#374151"))
        self.state_badge.setText(state)
        self.state_badge.setStyleSheet(
            f"padding: 6px 12px; border-radius: 12px; background-color: {bg}; color: {fg}; font-weight: 700;"
        )
        self.dashboard_tab.set_session_state(state)

    def _show_status_message(self, message: str, timeout_ms: int = 5000) -> None:
        self.statusBar().showMessage(message, timeout_ms)

    def refresh_system_info(self) -> None:
        if self.system_info_worker is not None and self.system_info_worker.isRunning():
            return
        self.system_info_worker = SystemInfoRefreshWorker(self.settings)
        self.system_info_worker.result_ready.connect(self._on_system_info_ready)
        self.system_info_worker.error_signal.connect(self.on_error_message)
        self.system_info_worker.finished.connect(self._on_system_info_worker_finished)
        self.system_info_worker.start()
        self._show_status_message("시스템 사양을 새로고침하는 중입니다...")

    def _on_system_info_ready(self, items) -> None:
        self.system_info_tab.set_items(items)
        self._show_status_message("시스템 사양을 새로고침했습니다.")

    def _on_system_info_worker_finished(self) -> None:
        self.system_info_worker = None

    def refresh_history_list(self) -> None:
        sessions = self.history_service.get_sessions(limit=self.settings.history_limit)
        self.history_tab.set_sessions(sessions)

    def start_monitoring(self) -> None:
        if self.monitor_service.is_active():
            self._show_status_message("이미 모니터링 세션이 실행 중입니다.")
            return
        self.settings = self.config_manager.get_settings()
        session_name = make_session_name()
        self.current_bundle = None
        self.loaded_history_bundle = None
        self.analysis_tab.clear()
        self.graphs_tab.clear()
        self.graphs_tab.set_live_mode(session_name)
        self.process_tab.set_rows([])
        self.dashboard_tab.clear_metrics()
        self.history_tab.set_detail_bundle(None)
        self.monitor_service.start_monitoring(self.settings, session_name)
        self.tab_widget.setCurrentWidget(self.dashboard_tab)

    def pause_monitoring(self) -> None:
        self.monitor_service.pause_monitoring()

    def resume_monitoring(self) -> None:
        self.monitor_service.resume_monitoring()

    def stop_monitoring(self) -> None:
        self.monitor_service.stop_monitoring()

    def on_metric_sample(self, sample) -> None:
        self.dashboard_tab.update_metric_sample(sample)
        self.graphs_tab.append_live_sample(sample)
        self.status_last_sample.setText(f"마지막 샘플: {to_display_datetime(sample.collected_at)}")

    def on_process_rows(self, rows) -> None:
        self.process_tab.set_rows(rows)
        self.graphs_tab.update_top_process_chart(rows)

    def on_monitor_system_info(self, items) -> None:
        if not self.loaded_history_bundle:
            self.system_info_tab.set_items(items)

    def on_alerts_updated(self, alerts) -> None:
        self.dashboard_tab.update_alerts(alerts)

    def on_status_updated(self, status_snapshot) -> None:
        self.current_status = status_snapshot
        self._set_status_badge(status_snapshot.state)
        if status_snapshot.session_id is not None:
            self.session_label.setText(f"현재 세션: {status_snapshot.session_id} / {status_snapshot.session_name}")
        else:
            self.session_label.setText("현재 세션: 없음")
        if status_snapshot.last_sample_at:
            self.status_last_sample.setText(f"마지막 샘플: {to_display_datetime(status_snapshot.last_sample_at)}")
        if status_snapshot.last_saved_at:
            self.status_last_saved.setText(f"마지막 저장: {to_display_datetime(status_snapshot.last_saved_at)}")
        if status_snapshot.message:
            self._show_status_message(status_snapshot.message)

    def on_session_finished(self, bundle: SessionBundle) -> None:
        self.current_bundle = bundle
        self.history_tab.set_detail_bundle(bundle)
        self.analysis_tab.set_analysis_result(bundle.analysis)
        self.graphs_tab.load_session_bundle(bundle)
        rows = self.history_service.build_process_rows_from_summaries(bundle.process_summaries)
        self.process_tab.set_rows(rows)
        self.system_info_tab.set_items(bundle.system_info)
        self.refresh_history_list()
        self._show_status_message("세션이 종료되었고 분석 결과가 갱신되었습니다.")

    def load_history_session(self, session_id: int) -> None:
        bundle = self.history_service.load_session_bundle(session_id)
        if bundle is None:
            self.on_error_message("선택한 세션을 불러오지 못했습니다.")
            return
        self.loaded_history_bundle = bundle
        self.history_tab.set_detail_bundle(bundle)
        self.analysis_tab.set_analysis_result(bundle.analysis)
        self.graphs_tab.load_session_bundle(bundle)
        rows = self.history_service.build_process_rows_from_summaries(bundle.process_summaries)
        self.process_tab.set_rows(rows)
        self.system_info_tab.set_items(bundle.system_info)
        self.tab_widget.setCurrentWidget(self.history_tab)
        self._show_status_message(f"세션 {session_id} 기록을 불러왔습니다.")

    def reanalyze_history_session(self, session_id: int) -> None:
        bundle = self.history_service.load_session_bundle(session_id)
        if bundle is None:
            self.on_error_message("선택한 세션을 다시 분석하지 못했습니다.")
            return
        self.loaded_history_bundle = bundle
        self.history_tab.set_detail_bundle(bundle)
        self.analysis_tab.set_analysis_result(bundle.analysis)
        self.tab_widget.setCurrentWidget(self.analysis_tab)
        self._show_status_message(f"세션 {session_id} 분석을 다시 계산했습니다.")

    def _resolve_export_bundle(self, session_id: int) -> SessionBundle | None:
        if self.current_bundle and self.current_bundle.session.id == session_id:
            return self.current_bundle
        if self.loaded_history_bundle and self.loaded_history_bundle.session.id == session_id:
            return self.loaded_history_bundle
        return self.history_service.load_session_bundle(session_id)

    def export_history_session(self, session_id: int, export_format: str) -> None:
        bundle = self._resolve_export_bundle(session_id)
        if bundle is None:
            self.on_error_message("내보낼 세션 데이터를 찾지 못했습니다.")
            return

        directory = self.settings.export_base_dir or str(self.paths.exports_dir)
        selected_dir = QFileDialog.getExistingDirectory(self, "내보내기 폴더 선택", directory)
        export_dir = selected_dir or directory

        try:
            target_path = export_session_bundle(bundle, export_format, export_dir, self.paths)
            self._show_status_message(f"내보내기가 완료되었습니다: {target_path}")
            QMessageBox.information(
                self,
                "내보내기 완료",
                f"{export_format.upper()} 파일 저장이 완료되었습니다.\n\n{target_path}",
            )
            open_file_location(target_path)
        except Exception as exc:
            LOGGER.exception("세션 내보내기 실패")
            self.on_error_message(f"내보내기 실패: {exc}")

    def apply_settings(self, payload: dict) -> None:
        try:
            self.settings = self.config_manager.update_from_dict(payload)
            self.analysis_service.update_thresholds(self.settings.overload_thresholds)
            self.settings_tab.set_settings(self.settings)
            QApplication.instance().setStyleSheet(build_app_stylesheet(self.settings))
            self.process_tab.top_n_spin.setValue(min(self.settings.top_process_count, self.process_tab.top_n_spin.maximum()))
            self.refresh_history_list()
            if not self.monitor_service.is_active():
                self.refresh_system_info()
            QMessageBox.information(
                self,
                "설정 저장",
                "설정을 저장했습니다.\n실행 중 세션에는 일부 설정이 다음 세션부터 반영될 수 있습니다.",
            )
        except Exception as exc:
            LOGGER.exception("설정 저장 실패")
            self.on_error_message(f"설정 저장 실패: {exc}")

    def cancel_settings_changes(self) -> None:
        self.settings_tab.set_settings(self.settings)
        self._show_status_message("저장되지 않은 설정 변경을 되돌렸습니다.")

    def reset_settings_to_defaults(self) -> None:
        try:
            self.settings = self.config_manager.reset_to_defaults()
            self.analysis_service.update_thresholds(self.settings.overload_thresholds)
            self.settings_tab.set_settings(self.settings)
            QApplication.instance().setStyleSheet(build_app_stylesheet(self.settings))
            self.refresh_history_list()
            if not self.monitor_service.is_active():
                self.refresh_system_info()
            QMessageBox.information(self, "기본값 복원", "설정을 기본값으로 복원했습니다.")
        except Exception as exc:
            LOGGER.exception("기본 설정 복원 실패")
            self.on_error_message(f"기본 설정 복원 실패: {exc}")

    def on_error_message(self, message: str) -> None:
        self.status_error.setText(f"오류 요약: {message}")
        self._show_status_message(message, timeout_ms=8000)

    def closeEvent(self, event) -> None:  # type: ignore[override]
        try:
            if self.system_info_worker is not None and self.system_info_worker.isRunning():
                self.system_info_worker.wait(5000)
            self.monitor_service.shutdown(15000)
        finally:
            super().closeEvent(event)
