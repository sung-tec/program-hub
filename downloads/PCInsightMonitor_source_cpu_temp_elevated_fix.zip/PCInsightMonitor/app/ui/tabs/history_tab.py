from __future__ import annotations

from PySide6.QtCore import QDate, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSplitter,
    QTableView,
    QVBoxLayout,
    QWidget,
    QPlainTextEdit,
)

from app.constants import EXPORT_FORMATS
from app.models import SessionBundle
from app.ui.models.session_table_model import SessionFilterProxyModel, SessionTableModel
from app.utils import format_duration, to_display_datetime


class HistoryTab(QWidget):
    load_requested = Signal(int)
    reanalyze_requested = Signal(int)
    export_requested = Signal(int, str)
    refresh_requested = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.model = SessionTableModel([])
        self.proxy_model = SessionFilterProxyModel()
        self.proxy_model.setSourceModel(self.model)
        self._build_ui()

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout(self)

        self.info_label = QLabel("세션을 한 번 이상 시작하고 중지하면 기록이 여기에 누적됩니다.\n목록이 비어 있으면 먼저 대시보드에서 모니터링을 시작해 주세요.")
        self.info_label.setWordWrap(True)
        root_layout.addWidget(self.info_label)

        filter_layout = QHBoxLayout()
        self.status_combo = QComboBox()
        self.status_combo.addItems(["전체", "대기 중", "모니터링 중", "일시정지", "종료됨"])
        self.status_combo.currentTextChanged.connect(self.proxy_model.set_status_filter)

        self.start_date_edit = QDateEdit()
        self.start_date_edit.setCalendarPopup(True)
        self.start_date_edit.setDate(QDate.currentDate().addMonths(-1))
        self.start_date_edit.dateChanged.connect(self._apply_date_filter)

        self.end_date_edit = QDateEdit()
        self.end_date_edit.setCalendarPopup(True)
        self.end_date_edit.setDate(QDate.currentDate())
        self.end_date_edit.dateChanged.connect(self._apply_date_filter)

        self.refresh_button = QPushButton("목록 새로고침")
        self.refresh_button.clicked.connect(self.refresh_requested.emit)

        filter_layout.addWidget(QLabel("상태"))
        filter_layout.addWidget(self.status_combo)
        filter_layout.addWidget(QLabel("시작일"))
        filter_layout.addWidget(self.start_date_edit)
        filter_layout.addWidget(QLabel("종료일"))
        filter_layout.addWidget(self.end_date_edit)
        filter_layout.addStretch(1)
        filter_layout.addWidget(self.refresh_button)

        root_layout.addLayout(filter_layout)

        splitter = QSplitter()
        self.table_view = QTableView()
        self.table_view.setModel(self.proxy_model)
        self.table_view.setAlternatingRowColors(True)
        self.table_view.setSelectionBehavior(QTableView.SelectRows)
        self.table_view.setSelectionMode(QTableView.SingleSelection)
        self.table_view.setSortingEnabled(True)
        self.table_view.horizontalHeader().setStretchLastSection(True)
        self.table_view.verticalHeader().setVisible(False)

        detail_widget = QWidget()
        detail_layout = QVBoxLayout(detail_widget)
        self.detail_text = QPlainTextEdit()
        self.detail_text.setReadOnly(True)

        button_layout = QHBoxLayout()
        self.export_format_combo = QComboBox()
        self.export_format_combo.addItems([fmt.upper() for fmt in EXPORT_FORMATS])
        self.load_button = QPushButton("선택 세션 상세 보기")
        self.reanalyze_button = QPushButton("선택 세션 다시 분석")
        self.export_button = QPushButton("선택 세션 내보내기")

        self.load_button.clicked.connect(self._emit_load)
        self.reanalyze_button.clicked.connect(self._emit_reanalyze)
        self.export_button.clicked.connect(self._emit_export)

        button_layout.addWidget(self.export_format_combo)
        button_layout.addWidget(self.load_button)
        button_layout.addWidget(self.reanalyze_button)
        button_layout.addWidget(self.export_button)

        detail_layout.addLayout(button_layout)
        detail_layout.addWidget(self.detail_text)

        splitter.addWidget(self.table_view)
        splitter.addWidget(detail_widget)
        splitter.setSizes([700, 500])

        root_layout.addWidget(splitter)
        self._apply_date_filter()

    def _apply_date_filter(self) -> None:
        self.proxy_model.set_date_range(self.start_date_edit.date(), self.end_date_edit.date())

    def set_sessions(self, sessions) -> None:
        rows = list(sessions)
        self.model.set_rows(rows)
        self.table_view.resizeColumnsToContents()
        if rows:
            self.info_label.setText("저장된 세션 목록입니다. 원하는 세션을 선택해 상세 보기 / 재분석 / 내보내기를 실행할 수 있습니다.")
        else:
            self.info_label.setText("세션을 한 번 이상 시작하고 중지하면 기록이 여기에 누적됩니다.\n목록이 비어 있으면 먼저 대시보드에서 모니터링을 시작해 주세요.")

    def _selected_session_id(self) -> int | None:
        selection_model = self.table_view.selectionModel()
        if selection_model is None or not selection_model.selectedRows():
            return None
        proxy_index = selection_model.selectedRows()[0]
        source_index = self.proxy_model.mapToSource(proxy_index)
        row = self.model.row_at(source_index.row())
        return row.id if row is not None else None

    def _emit_load(self) -> None:
        session_id = self._selected_session_id()
        if session_id is not None:
            self.load_requested.emit(session_id)

    def _emit_reanalyze(self) -> None:
        session_id = self._selected_session_id()
        if session_id is not None:
            self.reanalyze_requested.emit(session_id)

    def _emit_export(self) -> None:
        session_id = self._selected_session_id()
        if session_id is not None:
            self.export_requested.emit(session_id, self.export_format_combo.currentText().lower())

    def set_detail_bundle(self, bundle: SessionBundle | None) -> None:
        if bundle is None:
            self.detail_text.setPlainText("선택된 세션 정보가 없습니다.")
            return

        analysis = bundle.analysis
        lines = [
            f"세션 ID: {bundle.session.id}",
            f"세션명: {bundle.session.session_name}",
            f"시작 시각: {to_display_datetime(bundle.session.started_at)}",
            f"종료 시각: {to_display_datetime(bundle.session.ended_at)}",
            f"상태: {bundle.session.status}",
            f"샘플 간격: {bundle.session.sample_interval_sec}초",
            f"샘플 수: {len(bundle.metric_samples)}",
            f"과부하 이벤트 수: {len(bundle.overload_events)}",
            f"세션 길이: {format_duration(analysis.session_duration_sec) if analysis else '값 없음'}",
            f"요약: {analysis.narrative_summary if analysis else '값 없음'}",
        ]
        self.detail_text.setPlainText("\n".join(lines))
