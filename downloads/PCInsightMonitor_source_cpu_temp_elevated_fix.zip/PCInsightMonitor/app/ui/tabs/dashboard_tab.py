from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.constants import CARD_OBJECT_NAME, SESSION_STATUS_PAUSED, SESSION_STATUS_RUNNING, WARNING_BOX_OBJECT_NAME
from app.models import LiveAlert, MetricSample
from app.utils import format_bytes_per_sec, format_gb_from_mb, format_percent, format_temperature, to_display_datetime


class DashboardTab(QWidget):
    start_requested = Signal()
    pause_requested = Signal()
    resume_requested = Signal()
    stop_requested = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._state = "대기 중"
        self.metric_labels: dict[str, tuple[QLabel, QLabel]] = {}
        self._build_ui()

    def _build_card(self, title: str) -> tuple[QFrame, QLabel, QLabel]:
        frame = QFrame()
        frame.setObjectName(CARD_OBJECT_NAME)
        layout = QVBoxLayout(frame)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-weight: 600; font-size: 11pt;")
        value_label = QLabel("값 없음")
        value_font = QFont()
        value_font.setPointSize(18)
        value_font.setBold(True)
        value_label.setFont(value_font)
        sub_label = QLabel("최근 값 없음")
        sub_label.setWordWrap(True)
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(sub_label)
        layout.addStretch(1)
        return frame, value_label, sub_label

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout(self)
        control_layout = QHBoxLayout()

        self.start_button = QPushButton("시작")
        self.pause_button = QPushButton("일시정지")
        self.resume_button = QPushButton("재개")
        self.stop_button = QPushButton("중지")

        self.start_button.clicked.connect(self.start_requested.emit)
        self.pause_button.clicked.connect(self.pause_requested.emit)
        self.resume_button.clicked.connect(self.resume_requested.emit)
        self.stop_button.clicked.connect(self.stop_requested.emit)

        control_layout.addWidget(self.start_button)
        control_layout.addWidget(self.pause_button)
        control_layout.addWidget(self.resume_button)
        control_layout.addWidget(self.stop_button)
        control_layout.addStretch(1)

        self.state_label = QLabel("현재 상태: 대기 중")
        self.last_sample_label = QLabel("마지막 수집: 값 없음")
        control_layout.addWidget(self.state_label)
        control_layout.addSpacing(20)
        control_layout.addWidget(self.last_sample_label)

        root_layout.addLayout(control_layout)

        grid = QGridLayout()
        cards = [
            ("cpu_percent", "CPU 사용률"),
            ("cpu_temp_c", "CPU 온도"),
            ("gpu_percent", "GPU 사용률"),
            ("gpu_temp_c", "GPU 온도"),
            ("ram_percent", "RAM 사용률"),
            ("disk_io", "디스크 I/O"),
            ("net_io", "네트워크 속도"),
        ]
        for index, (key, title) in enumerate(cards):
            frame, value_label, sub_label = self._build_card(title)
            self.metric_labels[key] = (value_label, sub_label)
            grid.addWidget(frame, index // 3, index % 3)

        root_layout.addLayout(grid)

        warning_frame = QFrame()
        warning_frame.setObjectName(WARNING_BOX_OBJECT_NAME)
        warning_layout = QVBoxLayout(warning_frame)
        warning_title = QLabel("최근 과부하 경고")
        warning_title.setStyleSheet("font-weight: 700; font-size: 11pt;")
        self.alert_box = QPlainTextEdit()
        self.alert_box.setReadOnly(True)
        self.alert_box.setMaximumBlockCount(200)
        warning_layout.addWidget(warning_title)
        warning_layout.addWidget(self.alert_box)
        root_layout.addWidget(warning_frame, 1)

        self.set_session_state("대기 중")

    def set_session_state(self, state: str) -> None:
        self._state = state
        self.state_label.setText(f"현재 상태: {state}")
        running = state == SESSION_STATUS_RUNNING
        paused = state == SESSION_STATUS_PAUSED
        self.start_button.setEnabled(not running and not paused)
        self.pause_button.setEnabled(running)
        self.resume_button.setEnabled(paused)
        self.stop_button.setEnabled(running or paused)

    def update_metric_sample(self, sample: MetricSample) -> None:
        cpu_value, cpu_sub = self.metric_labels["cpu_percent"]
        cpu_value.setText(format_percent(sample.cpu_percent))
        cpu_sub.setText(f"클럭: {sample.cpu_clock_mhz:.0f} MHz" if sample.cpu_clock_mhz is not None else "클럭: 값 없음")

        cpu_temp_value, cpu_temp_sub = self.metric_labels["cpu_temp_c"]
        cpu_temp_value.setText(format_temperature(sample.cpu_temp_c))
        cpu_temp_sub.setText("CPU 발열 상태" if sample.cpu_temp_c is not None else "외부 센서 필요 가능")

        gpu_value, gpu_sub = self.metric_labels["gpu_percent"]
        gpu_value.setText(format_percent(sample.gpu_percent))
        gpu_sub.setText(f"메모리: {sample.gpu_mem_used_mb:.1f} MB" if sample.gpu_mem_used_mb is not None else "메모리: 값 없음")

        gpu_temp_value, gpu_temp_sub = self.metric_labels["gpu_temp_c"]
        gpu_temp_value.setText(format_temperature(sample.gpu_temp_c))
        gpu_temp_sub.setText("GPU 발열 상태")

        ram_value, ram_sub = self.metric_labels["ram_percent"]
        ram_value.setText(format_percent(sample.ram_percent))
        ram_sub.setText(f"사용량: {format_gb_from_mb(sample.ram_used_mb)}")

        disk_value, disk_sub = self.metric_labels["disk_io"]
        disk_value.setText(
            f"R {format_bytes_per_sec(sample.disk_read_bps)} / W {format_bytes_per_sec(sample.disk_write_bps)}"
        )
        disk_sub.setText("샘플 간 delta 기반 계산")

        net_value, net_sub = self.metric_labels["net_io"]
        net_value.setText(
            f"↑ {format_bytes_per_sec(sample.net_sent_bps)} / ↓ {format_bytes_per_sec(sample.net_recv_bps)}"
        )
        net_sub.setText("샘플 간 delta 기반 계산")

        self.last_sample_label.setText(f"마지막 수집: {to_display_datetime(sample.collected_at)}")

    def update_alerts(self, alerts: list[LiveAlert]) -> None:
        if not alerts:
            self.alert_box.setPlainText("현재 활성 과부하 경고가 없습니다.")
            return
        lines = []
        for alert in alerts:
            processes = ", ".join(alert.suspected_processes) if alert.suspected_processes else "원인 후보 없음"
            lines.append(
                f"[{alert.label}] 시작: {to_display_datetime(alert.started_at)} / 지속: {int(alert.duration_sec)}초 / "
                f"현재값: {alert.current_value if alert.current_value is not None else '값 없음'} / "
                f"주요 후보: {processes}"
            )
        self.alert_box.setPlainText("\n".join(lines))

    def clear_metrics(self) -> None:
        for value_label, sub_label in self.metric_labels.values():
            value_label.setText("값 없음")
            sub_label.setText("최근 값 없음")
        self.alert_box.setPlainText("현재 활성 과부하 경고가 없습니다.")
        self.last_sample_label.setText("마지막 수집: 값 없음")
