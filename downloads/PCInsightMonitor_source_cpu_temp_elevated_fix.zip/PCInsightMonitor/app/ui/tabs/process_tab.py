from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QSpinBox,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from app.models import ProcessDisplayRow
from app.ui.models.process_table_model import ProcessFilterProxyModel, ProcessTableModel


class ProcessTab(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._base_rows: list[ProcessDisplayRow] = []
        self.model = ProcessTableModel([])
        self.proxy_model = ProcessFilterProxyModel()
        self.proxy_model.setSourceModel(self.model)
        self._build_ui()

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout(self)
        filter_layout = QHBoxLayout()

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("프로세스명 또는 PID 검색")
        self.search_edit.textChanged.connect(self.proxy_model.set_search_text)

        self.top_n_spin = QSpinBox()
        self.top_n_spin.setRange(1, 500)
        self.top_n_spin.setValue(50)
        self.top_n_spin.valueChanged.connect(self._rebuild_view)

        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["CPU 기준", "메모리 기준", "디스크 기준"])
        self.sort_combo.currentIndexChanged.connect(self._rebuild_view)

        self.running_only_check = QCheckBox("실행 중만 보기")
        self.running_only_check.toggled.connect(self.proxy_model.set_running_only)

        self.count_label = QLabel("표시 행 수: 0")

        filter_layout.addWidget(QLabel("검색"))
        filter_layout.addWidget(self.search_edit, 2)
        filter_layout.addWidget(QLabel("Top N"))
        filter_layout.addWidget(self.top_n_spin)
        filter_layout.addWidget(QLabel("정렬 기준"))
        filter_layout.addWidget(self.sort_combo)
        filter_layout.addWidget(self.running_only_check)
        filter_layout.addStretch(1)
        filter_layout.addWidget(self.count_label)

        self.empty_label = QLabel("모니터링을 시작하면 프로세스 집계가 여기에 표시됩니다.\n히스토리 세션을 불러오면 과거 프로세스 요약도 확인할 수 있습니다.")
        self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setWordWrap(True)

        self.table_view = QTableView()
        self.table_view.setModel(self.proxy_model)
        self.table_view.setSortingEnabled(True)
        self.table_view.setAlternatingRowColors(True)
        self.table_view.setSelectionBehavior(QTableView.SelectRows)
        self.table_view.setSelectionMode(QTableView.SingleSelection)
        self.table_view.horizontalHeader().setStretchLastSection(True)
        self.table_view.verticalHeader().setVisible(False)
        self.table_view.sortByColumn(4, Qt.DescendingOrder)

        root_layout.addLayout(filter_layout)
        root_layout.addWidget(self.empty_label)
        root_layout.addWidget(self.table_view)
        self._update_empty_state()

    def set_rows(self, rows: list[ProcessDisplayRow]) -> None:
        self._base_rows = list(rows)
        self._rebuild_view()

    def _rebuild_view(self) -> None:
        rows = list(self._base_rows)
        if self.sort_combo.currentText() == "메모리 기준":
            rows.sort(
                key=lambda row: (
                    -(row.current_memory_mb or 0.0),
                    -(row.current_cpu_percent or 0.0),
                    row.process_name.lower(),
                )
            )
        elif self.sort_combo.currentText() == "디스크 기준":
            rows.sort(
                key=lambda row: (
                    -(row.disk_read_total_bytes + row.disk_write_total_bytes),
                    -(row.current_cpu_percent or 0.0),
                    row.process_name.lower(),
                )
            )
        else:
            rows.sort(
                key=lambda row: (
                    -(row.current_cpu_percent or 0.0),
                    -(row.current_memory_mb or 0.0),
                    row.process_name.lower(),
                )
            )

        rows = rows[: self.top_n_spin.value()]
        self.model.set_rows(rows)
        self.table_view.resizeColumnsToContents()
        self.count_label.setText(f"표시 행 수: {len(rows)}")
        self._update_empty_state()

    def _update_empty_state(self) -> None:
        has_rows = self.model.rowCount() > 0
        self.empty_label.setVisible(not has_rows)
        self.table_view.setVisible(has_rows)
