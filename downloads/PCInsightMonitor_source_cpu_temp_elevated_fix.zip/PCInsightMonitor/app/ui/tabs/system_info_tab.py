from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from app.models import SystemInfoItem
from app.ui.models.keyvalue_table_model import KeyValueTableModel


class SystemInfoTab(QWidget):
    refresh_requested = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.model = KeyValueTableModel([])
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        top_layout = QHBoxLayout()
        self.count_label = QLabel("항목 수: 0")
        self.refresh_button = QPushButton("사양 새로고침")
        self.copy_selected_button = QPushButton("선택 복사")
        self.copy_all_button = QPushButton("전체 복사")

        self.refresh_button.clicked.connect(self.refresh_requested.emit)
        self.copy_selected_button.clicked.connect(self.copy_selected)
        self.copy_all_button.clicked.connect(self.copy_all)

        top_layout.addWidget(self.count_label)
        top_layout.addStretch(1)
        top_layout.addWidget(self.refresh_button)
        top_layout.addWidget(self.copy_selected_button)
        top_layout.addWidget(self.copy_all_button)

        self.empty_label = QLabel("초기 시스템 사양을 불러오는 중입니다. 표시되지 않으면 '사양 새로고침'을 눌러 주세요.")
        self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setWordWrap(True)

        self.table_view = QTableView()
        self.table_view.setModel(self.model)
        self.table_view.setSortingEnabled(True)
        self.table_view.setAlternatingRowColors(True)
        self.table_view.setSelectionBehavior(QTableView.SelectRows)
        self.table_view.setSelectionMode(QTableView.ExtendedSelection)
        self.table_view.horizontalHeader().setStretchLastSection(True)
        self.table_view.verticalHeader().setVisible(False)
        self.table_view.sortByColumn(0, Qt.AscendingOrder)

        layout.addLayout(top_layout)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.table_view)
        self._update_empty_state()

    def set_items(self, items: list[SystemInfoItem]) -> None:
        self.model.set_items(items)
        self.count_label.setText(f"항목 수: {len(items)}")
        self.table_view.resizeColumnsToContents()
        self._update_empty_state()

    def _update_empty_state(self) -> None:
        has_items = self.model.rowCount() > 0
        self.empty_label.setVisible(not has_items)
        self.table_view.setVisible(has_items)

    def copy_selected(self) -> None:
        selection_model = self.table_view.selectionModel()
        if selection_model is None:
            return
        rows = sorted(index.row() for index in selection_model.selectedRows())
        if not rows:
            self.copy_all()
            return
        lines = []
        for row in rows:
            item = self.model.items()[row]
            lines.append(f"{item.category}\t{item.key}\t{item.value}")
        QGuiApplication.clipboard().setText("\n".join(lines))

    def copy_all(self) -> None:
        items = self.model.items()
        lines = [f"{item.category}\t{item.key}\t{item.value}" for item in items]
        QGuiApplication.clipboard().setText("\n".join(lines))
