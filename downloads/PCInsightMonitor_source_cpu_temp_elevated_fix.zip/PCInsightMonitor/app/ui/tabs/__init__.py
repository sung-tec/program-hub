from app.ui.tabs.analysis_tab import AnalysisTab
from app.ui.tabs.dashboard_tab import DashboardTab
from app.ui.tabs.graphs_tab import GraphsTab
from app.ui.tabs.history_tab import HistoryTab
from app.ui.tabs.process_tab import ProcessTab
from app.ui.tabs.settings_tab import SettingsTab
from app.ui.tabs.system_info_tab import SystemInfoTab

__all__ = [
    "AnalysisTab",
    "DashboardTab",
    "GraphsTab",
    "HistoryTab",
    "ProcessTab",
    "SettingsTab",
    "SystemInfoTab",
]
