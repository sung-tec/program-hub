from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.constants import EXPORT_FORMAT_PDF, EXPORT_FORMAT_TXT, EXPORT_FORMAT_XLSX
from app.models import AppSettings


class SettingsTab(QWidget):
    apply_requested = Signal(dict)
    cancel_requested = Signal()
    reset_requested = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._build_ui()

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout(self)

        general_group = QGroupBox("기본 설정")
        general_form = QFormLayout(general_group)

        self.sample_interval_spin = QSpinBox()
        self.sample_interval_spin.setRange(1, 30)

        self.export_dir_edit = QLineEdit()
        self.export_dir_button = QPushButton("찾아보기")
        self.export_dir_button.clicked.connect(self._browse_export_dir)
        export_dir_layout = QHBoxLayout()
        export_dir_layout.addWidget(self.export_dir_edit, 1)
        export_dir_layout.addWidget(self.export_dir_button)

        self.auto_save_check = QCheckBox("자동 저장 사용")
        self.auto_start_check = QCheckBox("앱 시작 시 자동 모니터링")
        self.log_retention_spin = QSpinBox()
        self.log_retention_spin.setRange(1, 3650)
        self.dark_mode_check = QCheckBox("다크 모드 사용")
        self.top_process_spin = QSpinBox()
        self.top_process_spin.setRange(1, 100)
        self.history_limit_spin = QSpinBox()
        self.history_limit_spin.setRange(50, 5000)
        self.default_export_combo = QComboBox()
        self.default_export_combo.addItems([EXPORT_FORMAT_PDF.upper(), EXPORT_FORMAT_TXT.upper(), EXPORT_FORMAT_XLSX.upper()])

        general_form.addRow("샘플링 간격(초)", self.sample_interval_spin)
        general_form.addRow("기본 저장 경로", export_dir_layout)
        general_form.addRow("자동 저장 여부", self.auto_save_check)
        general_form.addRow("자동 시작 여부", self.auto_start_check)
        general_form.addRow("로그 보관 일수", self.log_retention_spin)
        general_form.addRow("다크모드 여부", self.dark_mode_check)
        general_form.addRow("상위 프로세스 표시 수", self.top_process_spin)
        general_form.addRow("히스토리 최대 표시 수", self.history_limit_spin)
        general_form.addRow("내보내기 기본 형식", self.default_export_combo)

        threshold_group = QGroupBox("과부하 임계값")
        threshold_form = QFormLayout(threshold_group)

        self.cpu_usage_threshold_spin = QDoubleSpinBox()
        self.cpu_usage_threshold_spin.setRange(1.0, 100.0)
        self.cpu_usage_threshold_spin.setDecimals(1)
        self.gpu_usage_threshold_spin = QDoubleSpinBox()
        self.gpu_usage_threshold_spin.setRange(1.0, 100.0)
        self.gpu_usage_threshold_spin.setDecimals(1)
        self.ram_threshold_spin = QDoubleSpinBox()
        self.ram_threshold_spin.setRange(1.0, 100.0)
        self.ram_threshold_spin.setDecimals(1)
        self.cpu_temp_threshold_spin = QDoubleSpinBox()
        self.cpu_temp_threshold_spin.setRange(1.0, 120.0)
        self.cpu_temp_threshold_spin.setDecimals(1)
        self.gpu_temp_threshold_spin = QDoubleSpinBox()
        self.gpu_temp_threshold_spin.setRange(1.0, 120.0)
        self.gpu_temp_threshold_spin.setDecimals(1)
        self.duration_threshold_spin = QSpinBox()
        self.duration_threshold_spin.setRange(5, 3600)
        self.merge_gap_spin = QSpinBox()
        self.merge_gap_spin.setRange(0, 300)

        threshold_form.addRow("CPU 사용률 임계값(%)", self.cpu_usage_threshold_spin)
        threshold_form.addRow("GPU 사용률 임계값(%)", self.gpu_usage_threshold_spin)
        threshold_form.addRow("RAM 사용률 임계값(%)", self.ram_threshold_spin)
        threshold_form.addRow("CPU 온도 임계값(°C)", self.cpu_temp_threshold_spin)
        threshold_form.addRow("GPU 온도 임계값(°C)", self.gpu_temp_threshold_spin)
        threshold_form.addRow("지속 시간 임계값(초)", self.duration_threshold_spin)
        threshold_form.addRow("이벤트 병합 간격(초)", self.merge_gap_spin)

        sensor_group = QGroupBox("센서 수집 옵션")
        sensor_layout = QVBoxLayout(sensor_group)
        self.cpu_temp_check = QCheckBox("CPU 온도 수집")
        self.gpu_metrics_check = QCheckBox("GPU 사용량 수집")
        self.gpu_temp_check = QCheckBox("GPU 온도 수집")
        self.hardware_probe_check = QCheckBox("WMI / 하드웨어 프로브 사용")
        self.battery_probe_check = QCheckBox("배터리 정보 수집")
        sensor_layout.addWidget(self.cpu_temp_check)
        sensor_layout.addWidget(self.gpu_metrics_check)
        sensor_layout.addWidget(self.gpu_temp_check)
        sensor_layout.addWidget(self.hardware_probe_check)
        sensor_layout.addWidget(self.battery_probe_check)
        sensor_layout.addWidget(QLabel("실행 중인 세션에는 일부 설정이 즉시 반영되지 않고 다음 세션부터 적용될 수 있습니다."))

        button_layout = QHBoxLayout()
        self.apply_button = QPushButton("적용")
        self.cancel_button = QPushButton("취소")
        self.reset_button = QPushButton("기본값 복원")
        self.apply_button.clicked.connect(self._emit_apply)
        self.cancel_button.clicked.connect(self.cancel_requested.emit)
        self.reset_button.clicked.connect(self.reset_requested.emit)

        button_layout.addStretch(1)
        button_layout.addWidget(self.apply_button)
        button_layout.addWidget(self.cancel_button)
        button_layout.addWidget(self.reset_button)

        root_layout.addWidget(general_group)
        root_layout.addWidget(threshold_group)
        root_layout.addWidget(sensor_group)
        root_layout.addStretch(1)
        root_layout.addLayout(button_layout)

    def _browse_export_dir(self) -> None:
        directory = QFileDialog.getExistingDirectory(self, "기본 내보내기 폴더 선택", self.export_dir_edit.text().strip())
        if directory:
            self.export_dir_edit.setText(directory)

    def _emit_apply(self) -> None:
        self.apply_requested.emit(self.collect_payload())

    def collect_payload(self) -> dict:
        return {
            "sample_interval_sec": self.sample_interval_spin.value(),
            "export_base_dir": self.export_dir_edit.text().strip(),
            "auto_save": self.auto_save_check.isChecked(),
            "auto_start": self.auto_start_check.isChecked(),
            "log_retention_days": self.log_retention_spin.value(),
            "dark_mode": self.dark_mode_check.isChecked(),
            "top_process_count": self.top_process_spin.value(),
            "history_limit": self.history_limit_spin.value(),
            "default_export_format": self.default_export_combo.currentText().lower(),
            "overload_thresholds": {
                "cpu_usage_percent": self.cpu_usage_threshold_spin.value(),
                "gpu_usage_percent": self.gpu_usage_threshold_spin.value(),
                "ram_percent": self.ram_threshold_spin.value(),
                "cpu_temp_c": self.cpu_temp_threshold_spin.value(),
                "gpu_temp_c": self.gpu_temp_threshold_spin.value(),
                "duration_sec": self.duration_threshold_spin.value(),
                "merge_gap_sec": self.merge_gap_spin.value(),
            },
            "sensor_options": {
                "enable_cpu_temperature": self.cpu_temp_check.isChecked(),
                "enable_gpu_metrics": self.gpu_metrics_check.isChecked(),
                "enable_gpu_temperature": self.gpu_temp_check.isChecked(),
                "enable_hardware_probe": self.hardware_probe_check.isChecked(),
                "enable_battery_probe": self.battery_probe_check.isChecked(),
            },
        }

    def set_settings(self, settings: AppSettings) -> None:
        self.sample_interval_spin.setValue(settings.sample_interval_sec)
        self.export_dir_edit.setText(settings.export_base_dir)
        self.auto_save_check.setChecked(settings.auto_save)
        self.auto_start_check.setChecked(settings.auto_start)
        self.log_retention_spin.setValue(settings.log_retention_days)
        self.dark_mode_check.setChecked(settings.dark_mode)
        self.top_process_spin.setValue(settings.top_process_count)
        self.history_limit_spin.setValue(settings.history_limit)
        self.default_export_combo.setCurrentText(settings.default_export_format.upper())

        thresholds = settings.overload_thresholds
        self.cpu_usage_threshold_spin.setValue(thresholds.cpu_usage_percent)
        self.gpu_usage_threshold_spin.setValue(thresholds.gpu_usage_percent)
        self.ram_threshold_spin.setValue(thresholds.ram_percent)
        self.cpu_temp_threshold_spin.setValue(thresholds.cpu_temp_c)
        self.gpu_temp_threshold_spin.setValue(thresholds.gpu_temp_c)
        self.duration_threshold_spin.setValue(thresholds.duration_sec)
        self.merge_gap_spin.setValue(thresholds.merge_gap_sec)

        sensor = settings.sensor_options
        self.cpu_temp_check.setChecked(sensor.enable_cpu_temperature)
        self.gpu_metrics_check.setChecked(sensor.enable_gpu_metrics)
        self.gpu_temp_check.setChecked(sensor.enable_gpu_temperature)
        self.hardware_probe_check.setChecked(sensor.enable_hardware_probe)
        self.battery_probe_check.setChecked(sensor.enable_battery_probe)
