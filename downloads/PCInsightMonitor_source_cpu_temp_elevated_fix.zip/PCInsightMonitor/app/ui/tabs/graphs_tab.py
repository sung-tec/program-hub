from __future__ import annotations

from typing import Iterable, Sequence

import pyqtgraph as pg
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.constants import TIME_RANGE_OPTIONS
from app.models import MetricSample, OverloadEvent, ProcessDisplayRow, ProcessSummary, SessionBundle
from app.utils import parse_iso


class GraphsTab(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._metric_samples: list[MetricSample] = []
        self._overload_events: list[OverloadEvent] = []
        self._process_rows: list[ProcessDisplayRow] = []
        self._process_summaries: list[ProcessSummary] = []
        self._mode_label_text = "활성 세션 그래프"
        self._plots: dict[str, pg.PlotWidget] = {}
        self._build_ui()

    def _create_plot_group(self, title: str) -> pg.PlotWidget:
        group = QGroupBox(title)
        layout = QVBoxLayout(group)
        plot = pg.PlotWidget()
        plot.showGrid(x=True, y=True, alpha=0.2)
        plot.setBackground("transparent")
        layout.addWidget(plot)
        self.scroll_layout.addWidget(group)
        return plot

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout(self)
        top_layout = QHBoxLayout()
        self.mode_label = QLabel(self._mode_label_text)
        self.info_label = QLabel("그래프는 모니터링 시작 후 샘플이 누적되면 표시됩니다.\n실시간 그래프가 비어 있으면 '시작'을 누른 뒤 2~5초 정도 기다려 주세요.")
        self.info_label.setWordWrap(True)
        self.range_combo = QComboBox()
        self.range_combo.addItems(list(TIME_RANGE_OPTIONS.keys()))
        self.range_combo.currentIndexChanged.connect(self.refresh_graphs)

        top_layout.addWidget(self.mode_label)
        top_layout.addStretch(1)
        top_layout.addWidget(QLabel("표시 기간"))
        top_layout.addWidget(self.range_combo)
        root_layout.addLayout(top_layout)
        root_layout.addWidget(self.info_label)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        container = QWidget()
        self.scroll_layout = QVBoxLayout(container)

        self._plots["cpu_percent"] = self._create_plot_group("CPU 사용률 추이")
        self._plots["cpu_temp_c"] = self._create_plot_group("CPU 온도 추이")
        self._plots["gpu_percent"] = self._create_plot_group("GPU 사용률 추이")
        self._plots["gpu_temp_c"] = self._create_plot_group("GPU 온도 추이")
        self._plots["ram_used_mb"] = self._create_plot_group("RAM 사용량 추이")
        self._plots["disk_io"] = self._create_plot_group("디스크 읽기/쓰기 추이")
        self._plots["net_io"] = self._create_plot_group("네트워크 송수신 추이")
        self._plots["top_process"] = self._create_plot_group("상위 프로세스 자원 사용 막대그래프")
        self.scroll_layout.addStretch(1)

        scroll_area.setWidget(container)
        root_layout.addWidget(scroll_area)

    def set_live_mode(self, session_name: str) -> None:
        self._mode_label_text = f"활성 세션 그래프 - {session_name}"
        self.mode_label.setText(self._mode_label_text)

    def set_history_mode(self, session_name: str) -> None:
        self._mode_label_text = f"기록 조회 그래프 - {session_name}"
        self.mode_label.setText(self._mode_label_text)

    def clear(self) -> None:
        self._metric_samples.clear()
        self._overload_events.clear()
        self._process_rows.clear()
        self._process_summaries.clear()
        self.info_label.setText("그래프는 모니터링 시작 후 샘플이 누적되면 표시됩니다.\n실시간 그래프가 비어 있으면 '시작'을 누른 뒤 2~5초 정도 기다려 주세요.")
        self.refresh_graphs()

    def append_live_sample(self, sample: MetricSample) -> None:
        self._metric_samples.append(sample)
        self.info_label.setText("실시간 그래프가 갱신되고 있습니다.")
        self.refresh_graphs()

    def update_overload_events(self, events: list[OverloadEvent]) -> None:
        self._overload_events = list(events)
        self.refresh_graphs()

    def update_top_process_chart(self, rows: list[ProcessDisplayRow]) -> None:
        self._process_rows = list(rows)
        self.refresh_graphs()

    def load_session_bundle(self, bundle: SessionBundle) -> None:
        self._metric_samples = list(bundle.metric_samples)
        self._overload_events = list(bundle.overload_events)
        self._process_summaries = list(bundle.process_summaries)
        self.info_label.setText("기록된 세션 그래프를 표시 중입니다.")
        self.set_history_mode(bundle.session.session_name)
        self.refresh_graphs()

    def _filtered_samples(self) -> list[MetricSample]:
        if not self._metric_samples:
            return []
        minutes = TIME_RANGE_OPTIONS.get(self.range_combo.currentText())
        if minutes is None:
            return list(self._metric_samples)
        last_dt = parse_iso(self._metric_samples[-1].collected_at)
        if last_dt is None:
            return list(self._metric_samples)
        cutoff = last_dt.timestamp() - (minutes * 60)
        result = []
        for sample in self._metric_samples:
            dt = parse_iso(sample.collected_at)
            if dt is None or dt.timestamp() >= cutoff:
                result.append(sample)
        return result or list(self._metric_samples[-1:])

    def _x_values(self, samples: Sequence[MetricSample]) -> list[float]:
        if not samples:
            return []
        first_dt = parse_iso(samples[0].collected_at)
        if first_dt is None:
            return list(range(len(samples)))
        values = []
        for sample in samples:
            dt = parse_iso(sample.collected_at)
            if dt is None:
                values.append(float(len(values)))
            else:
                values.append((dt - first_dt).total_seconds())
        return values

    def _event_regions(self, samples: Sequence[MetricSample]) -> list[tuple[float, float]]:
        if not samples or not self._overload_events:
            return []
        first_dt = parse_iso(samples[0].collected_at)
        if first_dt is None:
            return []
        regions: list[tuple[float, float]] = []
        for event in self._overload_events:
            start_dt = parse_iso(event.started_at)
            end_dt = parse_iso(event.ended_at)
            if start_dt is None or end_dt is None:
                continue
            start_x = (start_dt - first_dt).total_seconds()
            end_x = (end_dt - first_dt).total_seconds()
            if end_x >= 0:
                regions.append((max(start_x, 0.0), max(end_x, 0.0)))
        return regions

    def _plot_single_metric(self, plot: pg.PlotWidget, title: str, samples: Sequence[MetricSample], metric_key: str) -> None:
        plot.clear()
        plot.setTitle(title)
        if plot.plotItem.legend is None:
            plot.addLegend(offset=(10, 10))
        if not samples:
            plot.setTitle(f"{title} (데이터 없음)")
            return
        xs = self._x_values(samples)
        ys = [getattr(sample, metric_key) for sample in samples]
        valid_points = [(x, y) for x, y in zip(xs, ys) if y is not None]
        if not valid_points:
            plot.setTitle(f"{title} (데이터 없음)")
        else:
            plot.plot(
                [point[0] for point in valid_points],
                [point[1] for point in valid_points],
                pen=pg.mkPen(color=(59, 130, 246), width=2),
                name=title,
            )
        for start, end in self._event_regions(samples):
            region = pg.LinearRegionItem(values=(start, end), movable=False, brush=(255, 99, 132, 40))
            plot.addItem(region)

    def _plot_dual_metric(
        self,
        plot: pg.PlotWidget,
        title: str,
        samples: Sequence[MetricSample],
        left_key: str,
        left_name: str,
        right_key: str,
        right_name: str,
    ) -> None:
        plot.clear()
        plot.setTitle(title)
        if plot.plotItem.legend is None:
            plot.addLegend(offset=(10, 10))
        if not samples:
            plot.setTitle(f"{title} (데이터 없음)")
            return
        xs = self._x_values(samples)
        for metric_key, name, color in (
            (left_key, left_name, (16, 185, 129)),
            (right_key, right_name, (245, 158, 11)),
        ):
            ys = [getattr(sample, metric_key) for sample in samples]
            valid_points = [(x, y) for x, y in zip(xs, ys) if y is not None]
            if valid_points:
                plot.plot(
                    [point[0] for point in valid_points],
                    [point[1] for point in valid_points],
                    pen=pg.mkPen(color=color, width=2),
                    name=name,
                )
        for start, end in self._event_regions(samples):
            region = pg.LinearRegionItem(values=(start, end), movable=False, brush=(255, 99, 132, 40))
            plot.addItem(region)

    def _plot_top_processes(self, plot: pg.PlotWidget) -> None:
        plot.clear()
        plot.setTitle("상위 프로세스 자원 사용")
        rows = self._process_rows[:10]
        if not rows and self._process_summaries:
            rows = [
                ProcessDisplayRow(
                    pid=item.pid,
                    process_name=item.process_name,
                    start_time=item.first_seen_at,
                    runtime_sec=item.runtime_sec,
                    current_cpu_percent=item.cpu_avg,
                    avg_cpu_percent=item.cpu_avg,
                    max_cpu_percent=item.cpu_max,
                    current_memory_mb=item.memory_avg_mb,
                    avg_memory_mb=item.memory_avg_mb,
                    max_memory_mb=item.memory_max_mb,
                    disk_read_total_bytes=item.disk_read_total_bytes,
                    disk_write_total_bytes=item.disk_write_total_bytes,
                    gpu_current_percent=item.gpu_avg,
                    status=item.last_status,
                )
                for item in self._process_summaries[:10]
            ]
        if not rows:
            plot.setTitle("상위 프로세스 자원 사용 (데이터 없음)")
            return

        xs = list(range(len(rows)))
        heights = [row.current_cpu_percent or row.avg_cpu_percent or 0.0 for row in rows]
        names = [row.process_name[:12] for row in rows]
        bar_item = pg.BarGraphItem(x=xs, height=heights, width=0.6, brush=(99, 102, 241, 180))
        plot.addItem(bar_item)
        axis = plot.getAxis("bottom")
        axis.setTicks([list(zip(xs, names))])

    def refresh_graphs(self) -> None:
        samples = self._filtered_samples()
        self._plot_single_metric(self._plots["cpu_percent"], "CPU 사용률 추이", samples, "cpu_percent")
        self._plot_single_metric(self._plots["cpu_temp_c"], "CPU 온도 추이", samples, "cpu_temp_c")
        self._plot_single_metric(self._plots["gpu_percent"], "GPU 사용률 추이", samples, "gpu_percent")
        self._plot_single_metric(self._plots["gpu_temp_c"], "GPU 온도 추이", samples, "gpu_temp_c")
        self._plot_single_metric(self._plots["ram_used_mb"], "RAM 사용량 추이", samples, "ram_used_mb")
        self._plot_dual_metric(self._plots["disk_io"], "디스크 읽기/쓰기 추이", samples, "disk_read_bps", "읽기", "disk_write_bps", "쓰기")
        self._plot_dual_metric(self._plots["net_io"], "네트워크 송수신 추이", samples, "net_sent_bps", "송신", "net_recv_bps", "수신")
        self._plot_top_processes(self._plots["top_process"])
