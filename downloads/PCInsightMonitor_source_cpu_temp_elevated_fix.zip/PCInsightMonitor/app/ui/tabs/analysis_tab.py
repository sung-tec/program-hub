from __future__ import annotations

from PySide6.QtGui import QStandardItem, QStandardItemModel
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QGroupBox,
    QLabel,
    QListWidget,
    QPlainTextEdit,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from app.constants import EVENT_TYPE_LABELS, SUMMARY_CARD_OBJECT_NAME
from app.models import AnalysisResult
from app.utils import (
    format_bytes_per_sec,
    format_duration,
    format_gb_from_mb,
    format_percent,
    format_temperature,
    to_display_datetime,
)


class AnalysisTab(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.stats_model = QStandardItemModel(0, 6, self)
        self.stats_model.setHorizontalHeaderLabels(["지표", "평균", "최소", "최대", "p95", "단위"])

        self.events_model = QStandardItemModel(0, 7, self)
        self.events_model.setHorizontalHeaderLabels(["이벤트", "시작", "종료", "지속 시간", "임계값", "최고값", "주요 원인"])

        self._summary_labels: dict[str, QLabel] = {}
        self._build_ui()

    def _build_card(self, title: str) -> tuple[QFrame, QLabel]:
        frame = QFrame()
        frame.setObjectName(SUMMARY_CARD_OBJECT_NAME)
        layout = QVBoxLayout(frame)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-weight: 600; font-size: 11pt;")
        value_label = QLabel("값 없음")
        value_label.setStyleSheet("font-size: 16pt; font-weight: 700;")
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addStretch(1)
        return frame, value_label

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout(self)

        self.info_label = QLabel("분석 리포트는 세션 종료 후 자동 생성되며, 히스토리에서 이전 세션을 다시 불러와 볼 수 있습니다.")
        self.info_label.setWordWrap(True)
        root_layout.addWidget(self.info_label)

        summary_grid = QGridLayout()
        for index, title in enumerate(
            [
                "세션 길이",
                "샘플 개수",
                "과부하 횟수",
                "가장 오래 지속된 과부하",
                "피크 발생 시간대",
                "주요 병목 추정",
            ]
        ):
            frame, label = self._build_card(title)
            self._summary_labels[title] = label
            summary_grid.addWidget(frame, index // 3, index % 3)

        root_layout.addLayout(summary_grid)

        stats_group = QGroupBox("평균 / 최대 / 최소 / p95")
        stats_layout = QVBoxLayout(stats_group)
        self.stats_table = QTableView()
        self.stats_table.setModel(self.stats_model)
        self.stats_table.horizontalHeader().setStretchLastSection(True)
        self.stats_table.verticalHeader().setVisible(False)
        self.stats_table.setAlternatingRowColors(True)
        stats_layout.addWidget(self.stats_table)
        root_layout.addWidget(stats_group)

        events_group = QGroupBox("과부하 이벤트")
        events_layout = QVBoxLayout(events_group)
        self.events_table = QTableView()
        self.events_table.setModel(self.events_model)
        self.events_table.horizontalHeader().setStretchLastSection(True)
        self.events_table.verticalHeader().setVisible(False)
        self.events_table.setAlternatingRowColors(True)
        events_layout.addWidget(self.events_table)
        root_layout.addWidget(events_group)

        narrative_group = QGroupBox("자연어 분석 요약")
        narrative_layout = QVBoxLayout(narrative_group)
        self.narrative_text = QPlainTextEdit()
        self.narrative_text.setReadOnly(True)
        narrative_layout.addWidget(self.narrative_text)
        root_layout.addWidget(narrative_group)

        recommendation_group = QGroupBox("권장 조치")
        recommendation_layout = QVBoxLayout(recommendation_group)
        self.recommendation_list = QListWidget()
        recommendation_layout.addWidget(self.recommendation_list)
        root_layout.addWidget(recommendation_group)

    def _format_stat_value(self, metric_key: str, value: float | None) -> str:
        if metric_key in {"cpu_percent", "gpu_percent", "ram_percent"}:
            return format_percent(value)
        if metric_key in {"cpu_temp_c", "gpu_temp_c"}:
            return format_temperature(value)
        if metric_key == "ram_used_mb" or metric_key == "gpu_mem_used_mb":
            return format_gb_from_mb(value)
        if metric_key.endswith("_bps"):
            return format_bytes_per_sec(value)
        if metric_key == "cpu_clock_mhz":
            return f"{value:.0f} MHz" if value is not None else "값 없음"
        return "값 없음" if value is None else f"{value:.2f}"

    def clear(self) -> None:
        for label in self._summary_labels.values():
            label.setText("값 없음")
        self.stats_model.removeRows(0, self.stats_model.rowCount())
        self.events_model.removeRows(0, self.events_model.rowCount())
        self.info_label.setText("분석 리포트는 세션 종료 후 자동 생성되며, 히스토리에서 이전 세션을 다시 불러와 볼 수 있습니다.")
        self.narrative_text.setPlainText("아직 분석 결과가 없습니다.")
        self.recommendation_list.clear()

    def set_analysis_result(self, result: AnalysisResult | None) -> None:
        self.clear()
        if result is None:
            return

        self.info_label.setText("현재 표시 중인 세션 분석 결과입니다.")
        self._summary_labels["세션 길이"].setText(format_duration(result.session_duration_sec))
        self._summary_labels["샘플 개수"].setText(str(result.sample_count))
        self._summary_labels["과부하 횟수"].setText(str(result.total_overload_count))
        self._summary_labels["가장 오래 지속된 과부하"].setText(
            format_duration(result.longest_event.duration_sec) if result.longest_event else "값 없음"
        )
        self._summary_labels["피크 발생 시간대"].setText(result.peak_time_window)
        self._summary_labels["주요 병목 추정"].setText(result.bottleneck_summary)

        for stat in result.stats:
            self.stats_model.appendRow(
                [
                    QStandardItem(stat.display_name),
                    QStandardItem(self._format_stat_value(stat.metric_key, stat.average)),
                    QStandardItem(self._format_stat_value(stat.metric_key, stat.minimum)),
                    QStandardItem(self._format_stat_value(stat.metric_key, stat.maximum)),
                    QStandardItem(self._format_stat_value(stat.metric_key, stat.p95)),
                    QStandardItem(stat.unit),
                ]
            )

        for event in result.overload_events:
            suspected_processes = []
            try:
                import json

                suspected_processes = json.loads(event.suspected_processes_json)
            except Exception:
                suspected_processes = []
            suspected_text = ", ".join(item.get("process_name", "") for item in suspected_processes if isinstance(item, dict))
            self.events_model.appendRow(
                [
                    QStandardItem(EVENT_TYPE_LABELS.get(event.event_type, event.event_type)),
                    QStandardItem(to_display_datetime(event.started_at)),
                    QStandardItem(to_display_datetime(event.ended_at)),
                    QStandardItem(format_duration(event.duration_sec)),
                    QStandardItem(f"{event.threshold_value:.1f}"),
                    QStandardItem(f"{event.peak_value:.1f}" if event.peak_value is not None else "값 없음"),
                    QStandardItem(suspected_text or "원인 후보 없음"),
                ]
            )

        self.narrative_text.setPlainText(result.narrative_summary or "")
        self.recommendation_list.addItems(result.recommendations or ["권장 조치 없음"])
        self.stats_table.resizeColumnsToContents()
        self.events_table.resizeColumnsToContents()
