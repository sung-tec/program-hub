from __future__ import annotations

from datetime import date

from PySide6.QtCore import QAbstractTableModel, QDate, QModelIndex, QSortFilterProxyModel, Qt

from app.constants import SESSION_TABLE_HEADERS
from app.models import SessionRecord
from app.utils import to_display_datetime


class SessionTableModel(QAbstractTableModel):
    def __init__(self, rows: list[SessionRecord] | None = None) -> None:
        super().__init__()
        self._rows = rows or []

    def set_rows(self, rows: list[SessionRecord]) -> None:
        self.beginResetModel()
        self._rows = list(rows)
        self.endResetModel()

    def row_at(self, row: int) -> SessionRecord | None:
        if 0 <= row < len(self._rows):
            return self._rows[row]
        return None

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self._rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(SESSION_TABLE_HEADERS)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid():
            return None
        row = self._rows[index.row()]
        display_values = (
            row.id,
            row.session_name,
            to_display_datetime(row.started_at),
            to_display_datetime(row.ended_at),
            row.status,
            row.sample_interval_sec,
            row.notes,
        )
        raw_values = (
            row.id,
            row.session_name.lower(),
            row.started_at or "",
            row.ended_at or "",
            row.status,
            row.sample_interval_sec,
            row.notes.lower(),
        )
        if role == Qt.DisplayRole:
            return display_values[index.column()]
        if role == Qt.UserRole:
            return raw_values[index.column()]
        if role == Qt.TextAlignmentRole and index.column() in {0, 5}:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return SESSION_TABLE_HEADERS[section]
        return str(section + 1)


class SessionFilterProxyModel(QSortFilterProxyModel):
    def __init__(self) -> None:
        super().__init__()
        self._status_filter = "전체"
        self._start_date: QDate | None = None
        self._end_date: QDate | None = None
        self.setDynamicSortFilter(True)
        self.setSortRole(Qt.UserRole)

    def set_status_filter(self, status: str) -> None:
        self._status_filter = status
        self.invalidateFilter()

    def set_date_range(self, start_date: QDate | None, end_date: QDate | None) -> None:
        self._start_date = start_date
        self._end_date = end_date
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        model = self.sourceModel()
        if model is None:
            return True
        session = model.row_at(source_row)
        if session is None:
            return False

        if self._status_filter not in ("", "전체") and session.status != self._status_filter:
            return False

        session_date = QDate.fromString(session.started_at[:10], "yyyy-MM-dd") if session.started_at else None
        if session_date and self._start_date and session_date < self._start_date:
            return False
        if session_date and self._end_date and session_date > self._end_date:
            return False
        return True
