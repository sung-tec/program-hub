from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt

from app.constants import PROCESS_TABLE_HEADERS
from app.models import ProcessDisplayRow
from app.utils import format_bytes, format_duration, format_mb, format_percent, to_display_datetime


class ProcessTableModel(QAbstractTableModel):
    def __init__(self, rows: list[ProcessDisplayRow] | None = None) -> None:
        super().__init__()
        self._rows = rows or []

    def set_rows(self, rows: list[ProcessDisplayRow]) -> None:
        self.beginResetModel()
        self._rows = list(rows)
        self.endResetModel()

    def rows(self) -> list[ProcessDisplayRow]:
        return list(self._rows)

    def row_at(self, row: int) -> ProcessDisplayRow | None:
        if 0 <= row < len(self._rows):
            return self._rows[row]
        return None

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self._rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(PROCESS_TABLE_HEADERS)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid():
            return None
        row = self._rows[index.row()]

        display_values = (
            row.process_name,
            row.pid,
            to_display_datetime(row.start_time),
            format_duration(row.runtime_sec),
            format_percent(row.current_cpu_percent),
            format_percent(row.avg_cpu_percent),
            format_percent(row.max_cpu_percent),
            format_mb(row.current_memory_mb),
            format_mb(row.avg_memory_mb),
            format_mb(row.max_memory_mb),
            format_bytes(row.disk_read_total_bytes),
            format_bytes(row.disk_write_total_bytes),
            format_percent(row.gpu_current_percent),
            row.status,
        )

        raw_values = (
            row.process_name.lower(),
            row.pid,
            row.start_time or "",
            row.runtime_sec or 0.0,
            row.current_cpu_percent or -1.0,
            row.avg_cpu_percent or -1.0,
            row.max_cpu_percent or -1.0,
            row.current_memory_mb or -1.0,
            row.avg_memory_mb or -1.0,
            row.max_memory_mb or -1.0,
            row.disk_read_total_bytes,
            row.disk_write_total_bytes,
            row.gpu_current_percent if row.gpu_current_percent is not None else -1.0,
            row.status,
        )

        if role == Qt.DisplayRole:
            return display_values[index.column()]
        if role == Qt.UserRole:
            return raw_values[index.column()]
        if role == Qt.TextAlignmentRole:
            if index.column() in {1, 4, 5, 6, 7, 8, 9, 10, 11, 12}:
                return int(Qt.AlignRight | Qt.AlignVCenter)
        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return PROCESS_TABLE_HEADERS[section]
        return str(section + 1)


class ProcessFilterProxyModel(QSortFilterProxyModel):
    def __init__(self) -> None:
        super().__init__()
        self._search_text = ""
        self._running_only = False
        self.setDynamicSortFilter(True)
        self.setSortRole(Qt.UserRole)

    def set_search_text(self, text: str) -> None:
        self._search_text = text.strip().lower()
        self.invalidateFilter()

    def set_running_only(self, enabled: bool) -> None:
        self._running_only = enabled
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        model = self.sourceModel()
        if model is None:
            return True
        row = model.row_at(source_row)
        if row is None:
            return False
        if self._running_only and row.status != "실행 중":
            return False
        if self._search_text:
            target = f"{row.process_name} {row.pid}".lower()
            if self._search_text not in target:
                return False
        return True
