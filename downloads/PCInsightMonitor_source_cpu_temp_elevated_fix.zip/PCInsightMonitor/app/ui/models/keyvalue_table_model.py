from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt

from app.constants import SYSTEM_INFO_HEADERS
from app.models import SystemInfoItem


class KeyValueTableModel(QAbstractTableModel):
    def __init__(self, items: list[SystemInfoItem] | None = None) -> None:
        super().__init__()
        self._items = items or []

    def set_items(self, items: list[SystemInfoItem]) -> None:
        self.beginResetModel()
        self._items = list(items)
        self.endResetModel()

    def items(self) -> list[SystemInfoItem]:
        return list(self._items)

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self._items)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return 3

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid():
            return None
        item = self._items[index.row()]
        values = (item.category, item.key, item.value)
        if role == Qt.DisplayRole:
            return values[index.column()]
        if role == Qt.UserRole:
            return values[index.column()]
        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return SYSTEM_INFO_HEADERS[section]
        return str(section + 1)

    def sort(self, column: int, order: Qt.SortOrder = Qt.AscendingOrder) -> None:
        reverse = order == Qt.DescendingOrder
        self.layoutAboutToBeChanged.emit()
        self._items.sort(
            key=lambda item: (
                item.category.lower(),
                item.key.lower(),
                item.value.lower(),
            )[column],
            reverse=reverse,
        )
        self.layoutChanged.emit()
