from __future__ import annotations

from PySide6.QtWidgets import QDialog, QVBoxLayout

from app.models import AppSettings
from app.ui.tabs.settings_tab import SettingsTab


class SettingsDialog(QDialog):
    def __init__(self, settings: AppSettings, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("설정")
        self.resize(760, 720)

        self.settings_tab = SettingsTab()
        self.settings_tab.set_settings(settings)

        layout = QVBoxLayout(self)
        layout.addWidget(self.settings_tab)

        self.settings_tab.apply_requested.connect(self.accept)
        self.settings_tab.cancel_requested.connect(self.reject)
        self.settings_tab.reset_requested.connect(self._reset_form)

    def _reset_form(self) -> None:
        self.settings_tab.set_settings(AppSettings())

    def collect_payload(self) -> dict:
        return self.settings_tab.collect_payload()
