from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

from app.constants import APP_NAME, PDF_FONT_CANDIDATE


@dataclass(frozen=True, slots=True)
class AppPaths:
    root_dir: Path
    config_dir: Path
    data_dir: Path
    logs_dir: Path
    exports_dir: Path
    temp_dir: Path
    charts_dir: Path
    third_party_dir: Path
    lhm_dir: Path
    settings_file: Path
    db_file: Path
    log_file: Path


def _default_root_dir() -> Path:
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / APP_NAME.replace(" ", "")
    if sys.platform.startswith("win"):
        return Path.home() / "AppData" / "Local" / APP_NAME.replace(" ", "")
    return Path.home() / ".local" / "share" / APP_NAME.replace(" ", "")


def build_app_paths(root_override: str | Path | None = None) -> AppPaths:
    root_dir = Path(root_override) if root_override else _default_root_dir()
    config_dir = root_dir / "config"
    data_dir = root_dir / "data"
    logs_dir = root_dir / "logs"
    exports_dir = root_dir / "exports"
    temp_dir = root_dir / "temp"
    charts_dir = temp_dir / "charts"
    third_party_dir = root_dir / "third_party"
    lhm_dir = third_party_dir / "LibreHardwareMonitor"
    return AppPaths(
        root_dir=root_dir,
        config_dir=config_dir,
        data_dir=data_dir,
        logs_dir=logs_dir,
        exports_dir=exports_dir,
        temp_dir=temp_dir,
        charts_dir=charts_dir,
        third_party_dir=third_party_dir,
        lhm_dir=lhm_dir,
        settings_file=config_dir / "settings.json",
        db_file=data_dir / "monitor.db",
        log_file=logs_dir / "app.log",
    )


def ensure_app_directories(paths: AppPaths) -> None:
    for directory in (
        paths.root_dir,
        paths.config_dir,
        paths.data_dir,
        paths.logs_dir,
        paths.exports_dir,
        paths.temp_dir,
        paths.charts_dir,
        paths.third_party_dir,
        paths.lhm_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    paths.log_file.touch(exist_ok=True)


def get_runtime_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def clear_temp_charts(paths: AppPaths) -> None:
    if not paths.charts_dir.exists():
        return
    for item in paths.charts_dir.glob("*.png"):
        try:
            item.unlink()
        except OSError:
            continue


def get_malgun_font_candidates() -> list[Path]:
    candidates: list[Path] = []
    windows_dir = Path(os.environ.get("WINDIR", r"C:\Windows"))
    candidates.append(windows_dir / "Fonts" / PDF_FONT_CANDIDATE)
    candidates.append(get_runtime_base_dir() / PDF_FONT_CANDIDATE)
    candidates.append(get_runtime_base_dir() / "fonts" / PDF_FONT_CANDIDATE)
    return [path for path in candidates if path.exists()]
