from __future__ import annotations

import logging
import threading
from collections import deque
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Deque

_LOG_BUFFER_LOCK = threading.Lock()
_LOG_BUFFER: Deque[dict[str, str]] = deque(maxlen=200)


class UiBufferHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
        except Exception:
            message = record.getMessage()
        payload = {
            "level": record.levelname,
            "message": message,
        }
        with _LOG_BUFFER_LOCK:
            _LOG_BUFFER.append(payload)


def setup_logging(log_file: str | Path, retention_days: int = 30) -> None:
    target_file = Path(log_file)
    target_file.parent.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    for handler in list(root_logger.handlers):
        root_logger.removeHandler(handler)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] [%(threadName)s] %(name)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = TimedRotatingFileHandler(
        filename=str(target_file),
        when="midnight",
        backupCount=max(int(retention_days), 1),
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    buffer_handler = UiBufferHandler()
    buffer_handler.setLevel(logging.INFO)
    buffer_handler.setFormatter(formatter)
    root_logger.addHandler(buffer_handler)

    logging.captureWarnings(True)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def get_recent_logs(limit: int = 20, minimum_level: int | None = None) -> list[dict[str, str]]:
    with _LOG_BUFFER_LOCK:
        items = list(_LOG_BUFFER)

    if minimum_level is None:
        return items[-limit:]

    filtered: list[dict[str, str]] = []
    for item in items:
        try:
            level = getattr(logging, item["level"], logging.INFO)
        except Exception:
            level = logging.INFO
        if level >= minimum_level:
            filtered.append(item)
    return filtered[-limit:]
