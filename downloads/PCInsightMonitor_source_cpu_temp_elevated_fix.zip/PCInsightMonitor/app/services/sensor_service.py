from __future__ import annotations

import ctypes
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

import psutil

from app.logger import get_logger
from app.models import MetricSample, SensorOptions
from app.paths import build_app_paths, get_runtime_base_dir
from app.utils import safe_float

LOGGER = get_logger(__name__)

try:
    import pynvml  # type: ignore
except Exception:
    pynvml = None

try:
    import wmi  # type: ignore
except Exception:
    wmi = None

try:
    import WinTmp  # type: ignore
except Exception:
    WinTmp = None


class SensorService:
    """실시간 센서 및 시스템 상태 수집 서비스."""

    _NUMERIC_PATTERN = re.compile(r"(-?\d+(?:[\.,]\d+)?)")
    _LHM_RELEASE_PAGE = "https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/latest"
    _LHM_ZIP_PATTERN = re.compile(
        r"href=[\"'](?P<href>/LibreHardwareMonitor/LibreHardwareMonitor/releases/download/[^\"']+/[^\"']*LibreHardwareMonitor[^\"']*\.zip)[\"']",
        re.IGNORECASE,
    )

    def __init__(self, sensor_options: SensorOptions | None = None) -> None:
        self.sensor_options = sensor_options or SensorOptions()
        self._nvml_initialized = False
        self._gpu_handle = None
        self._gpu_static_info_cache: dict[str, Any] | None = None
        self._previous_disk: tuple[int, int] | None = None
        self._previous_net: tuple[int, int] | None = None
        self._previous_rate_ts: float | None = None
        self._wmi_clients: dict[str, Any] = {}
        self._lhm_http_candidates = self._build_lhm_http_candidates()
        self._lhm_http_available = False
        self._lhm_http_cache_data: Any | None = None
        self._lhm_http_cache_ts: float = 0.0
        self._paths = build_app_paths()
        self._runtime_base_dir = get_runtime_base_dir()
        self._lhm_install_dir = self._paths.lhm_dir
        self._lhm_zip_file = self._paths.temp_dir / "LibreHardwareMonitor_download.zip"
        self._lhm_notice_file = self._lhm_install_dir / "PCInsightMonitor-LibreHardwareMonitor-NOTICE.txt"
        self._lhm_last_bootstrap_attempt_ts = 0.0
        self._lhm_bootstrap_cooldown_sec = 600.0
        self._initialize_nvml()


    def _build_lhm_http_candidates(self) -> list[str]:
        candidates: list[str] = []
        seen: set[str] = set()

        def add_candidate(host: str) -> None:
            if not host:
                return
            url = f"http://{host}:8085/data.json"
            if url not in seen:
                seen.add(url)
                candidates.append(url)

        add_candidate("127.0.0.1")
        add_candidate("localhost")
        try:
            host_name = socket.gethostname()
            add_candidate(host_name)
            for ip in socket.gethostbyname_ex(host_name)[2]:
                add_candidate(ip)
        except Exception:
            LOGGER.debug("로컬 IP 기반 LibreHardwareMonitor 후보 주소 구성에 실패했습니다.", exc_info=True)
        return candidates

    def _refresh_wmi_client(self, namespace: str) -> None:
        self._wmi_clients.pop(namespace, None)

    def _has_lhm_wmi_namespace(self) -> bool:
        for namespace in (r"root\LibreHardwareMonitor", r"root\OpenHardwareMonitor"):
            self._refresh_wmi_client(namespace)
            client = self._get_wmi(namespace)
            if client is None:
                continue
            try:
                sensors = client.Sensor()
                if sensors is not None:
                    return True
            except Exception:
                continue
        return False

    def _is_user_admin(self) -> bool:
        if platform.system().lower() != "windows":
            return False
        try:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False

    def _kill_running_lhm(self) -> bool:
        pid = self._find_running_lhm_pid()
        if not pid:
            return False
        try:
            process = psutil.Process(pid)
            process.terminate()
            process.wait(timeout=5)
            LOGGER.info("기존 LibreHardwareMonitor 프로세스를 종료했습니다. pid=%s", pid)
            return True
        except Exception:
            LOGGER.info("기존 LibreHardwareMonitor 종료에 실패했습니다. pid=%s", pid, exc_info=True)
            return False

    def _start_lhm_process(self, elevated: bool = False) -> bool:
        exe_path = self._get_lhm_exe_path()
        if not exe_path.exists():
            return False

        try:
            if elevated and platform.system().lower() == "windows":
                command = [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    (
                        "Start-Process -FilePath '{}' -WorkingDirectory '{}' -Verb RunAs -WindowStyle Minimized"
                    ).format(str(exe_path).replace("'", "''"), str(exe_path.parent).replace("'", "''")),
                ]
                completed = subprocess.run(
                    command,
                    cwd=str(exe_path.parent),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    timeout=15,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    check=False,
                )
                if completed.returncode == 0:
                    LOGGER.info("LibreHardwareMonitor를 관리자 권한으로 실행 요청했습니다: %s", exe_path)
                    return True
                LOGGER.info("LibreHardwareMonitor 관리자 권한 실행 요청이 실패했습니다. returncode=%s", completed.returncode)
                return False

            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
            subprocess.Popen(
                [str(exe_path)],
                cwd=str(exe_path.parent),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=creationflags,
                close_fds=True,
            )
            LOGGER.info("LibreHardwareMonitor를 자동 실행했습니다: %s", exe_path)
            return True
        except Exception as exc:
            LOGGER.info("LibreHardwareMonitor 자동 실행 실패: %s", exc)
            return False

    def warmup(self) -> None:
        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            LOGGER.debug("CPU percent 워밍업에 실패했습니다.", exc_info=True)
        self._prime_rate_counters()

    def cleanup(self) -> None:
        if self._nvml_initialized and pynvml is not None:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                LOGGER.debug("NVML 종료 중 예외가 발생했습니다.", exc_info=True)
        self._nvml_initialized = False
        self._gpu_handle = None

    def _initialize_nvml(self) -> None:
        if pynvml is None or not self.sensor_options.enable_gpu_metrics:
            return
        try:
            pynvml.nvmlInit()
            count = pynvml.nvmlDeviceGetCount()
            if count <= 0:
                return
            self._gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            self._nvml_initialized = True
            LOGGER.info("NVML 초기화에 성공했습니다.")
        except Exception as exc:
            LOGGER.info("NVML 초기화에 실패했습니다: %s", exc)
            self._nvml_initialized = False
            self._gpu_handle = None

    def _get_wmi(self, namespace: str = r"root\cimv2") -> Any | None:
        if wmi is None or not self.sensor_options.enable_hardware_probe:
            return None
        if namespace in self._wmi_clients:
            return self._wmi_clients[namespace]
        try:
            client = wmi.WMI(namespace=namespace)
            self._wmi_clients[namespace] = client
            return client
        except Exception:
            self._wmi_clients[namespace] = None
            return None

    def _prime_rate_counters(self) -> None:
        try:
            disk = psutil.disk_io_counters()
            if disk:
                self._previous_disk = (int(disk.read_bytes), int(disk.write_bytes))
        except Exception:
            self._previous_disk = None

        try:
            net = psutil.net_io_counters()
            if net:
                self._previous_net = (int(net.bytes_sent), int(net.bytes_recv))
        except Exception:
            self._previous_net = None

        self._previous_rate_ts = time.monotonic()

    def _get_lhm_exe_path(self) -> Path:
        return self._lhm_install_dir / "LibreHardwareMonitor.exe"

    def _find_running_lhm_pid(self) -> int | None:
        for process in psutil.process_iter(["pid", "name", "exe"]):
            try:
                name = str(process.info.get("name") or "").lower()
                exe_path = str(process.info.get("exe") or "").lower()
            except Exception:
                continue
            if name == "librehardwaremonitor.exe" or exe_path.endswith("librehardwaremonitor.exe"):
                return int(process.info.get("pid") or 0)
        return None

    def _ensure_lhm_notice_file(self) -> None:
        try:
            self._lhm_install_dir.mkdir(parents=True, exist_ok=True)
            self._lhm_notice_file.write_text(
                "LibreHardwareMonitor notice\n"
                "Downloaded from the official GitHub releases page by PC Insight Monitor.\n"
                "Project: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor\n"
                "License: MPL-2.0\n"
                "The downloaded release includes its own LICENSE and THIRD-PARTY-LICENSES files.\n",
                encoding="utf-8",
            )
        except Exception:
            LOGGER.debug("LibreHardwareMonitor 고지 파일 생성에 실패했습니다.", exc_info=True)

    def _copy_bundled_lhm_if_present(self) -> bool:
        candidate_dirs = [
            self._runtime_base_dir / "vendor" / "LibreHardwareMonitor",
            self._runtime_base_dir / "_internal" / "vendor" / "LibreHardwareMonitor",
            self._runtime_base_dir / "LibreHardwareMonitor",
        ]
        for candidate in candidate_dirs:
            exe_file = candidate / "LibreHardwareMonitor.exe"
            if not exe_file.exists():
                continue
            try:
                if self._lhm_install_dir.exists():
                    shutil.rmtree(self._lhm_install_dir, ignore_errors=True)
                shutil.copytree(candidate, self._lhm_install_dir, dirs_exist_ok=True)
                self._ensure_lhm_notice_file()
                LOGGER.info("번들된 LibreHardwareMonitor 파일을 로컬 설치 폴더로 복사했습니다: %s", candidate)
                return True
            except Exception as exc:
                LOGGER.info("번들된 LibreHardwareMonitor 복사 실패: %s", exc)
        return False

    def _discover_lhm_release_zip_url(self) -> str | None:
        try:
            request = urllib.request.Request(self._LHM_RELEASE_PAGE, headers={"User-Agent": "PCInsightMonitor/1.0"})
            with urllib.request.urlopen(request, timeout=8.0) as response:
                html = response.read(2 * 1024 * 1024).decode("utf-8", errors="ignore")
        except Exception as exc:
            LOGGER.info("LibreHardwareMonitor 릴리스 페이지 조회 실패: %s", exc)
            return None

        matches = list(self._LHM_ZIP_PATTERN.finditer(html))
        if not matches:
            LOGGER.info("LibreHardwareMonitor 릴리스 ZIP 링크를 찾지 못했습니다.")
            return None

        href = matches[0].group("href")
        download_url = urllib.parse.urljoin("https://github.com", href)
        LOGGER.info("LibreHardwareMonitor 다운로드 링크를 찾았습니다: %s", download_url)
        return download_url

    def _download_and_extract_lhm(self) -> bool:
        download_url = self._discover_lhm_release_zip_url()
        if not download_url:
            return False

        try:
            self._paths.temp_dir.mkdir(parents=True, exist_ok=True)
            request = urllib.request.Request(download_url, headers={"User-Agent": "PCInsightMonitor/1.0"})
            with urllib.request.urlopen(request, timeout=20.0) as response, self._lhm_zip_file.open("wb") as file:
                shutil.copyfileobj(response, file)
            LOGGER.info("LibreHardwareMonitor ZIP 다운로드를 완료했습니다: %s", self._lhm_zip_file)
        except Exception as exc:
            LOGGER.info("LibreHardwareMonitor ZIP 다운로드 실패: %s", exc)
            return False

        try:
            if self._lhm_install_dir.exists():
                shutil.rmtree(self._lhm_install_dir, ignore_errors=True)
            self._lhm_install_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(self._lhm_zip_file, "r") as archive:
                archive.extractall(self._lhm_install_dir)

            nested_exe = list(self._lhm_install_dir.rglob("LibreHardwareMonitor.exe"))
            if not nested_exe:
                LOGGER.info("LibreHardwareMonitor 압축 해제 후 실행 파일을 찾지 못했습니다.")
                return False

            exe_parent = nested_exe[0].parent
            if exe_parent != self._lhm_install_dir:
                temp_staging = self._lhm_install_dir.parent / "LibreHardwareMonitor_flatten"
                if temp_staging.exists():
                    shutil.rmtree(temp_staging, ignore_errors=True)
                shutil.copytree(exe_parent, temp_staging, dirs_exist_ok=True)
                shutil.rmtree(self._lhm_install_dir, ignore_errors=True)
                temp_staging.replace(self._lhm_install_dir)

            self._ensure_lhm_notice_file()
            LOGGER.info("LibreHardwareMonitor 압축 해제를 완료했습니다: %s", self._lhm_install_dir)
            return True
        except Exception as exc:
            LOGGER.info("LibreHardwareMonitor 압축 해제 실패: %s", exc)
            return False

    def _ensure_lhm_installed(self) -> bool:
        exe_path = self._get_lhm_exe_path()
        if exe_path.exists():
            return True
        if self._copy_bundled_lhm_if_present():
            return self._get_lhm_exe_path().exists()
        return self._download_and_extract_lhm() and self._get_lhm_exe_path().exists()

    def _start_lhm_if_needed(self) -> bool:
        if platform.system().lower() != "windows":
            return False
        if not self._ensure_lhm_installed():
            return False

        running_pid = self._find_running_lhm_pid()
        if running_pid is not None:
            if self._has_lhm_wmi_namespace() or self._get_lhm_http_json() is not None:
                return True
            LOGGER.info("실행 중인 LibreHardwareMonitor는 감지되지만 센서 경로가 보이지 않습니다. 관리자 권한 재시작을 시도합니다.")
            self._kill_running_lhm()

        if self._is_user_admin():
            if self._start_lhm_process(elevated=False):
                return True

        return self._start_lhm_process(elevated=True)

    def _maybe_bootstrap_lhm(self) -> bool:
        if platform.system().lower() != "windows":
            return False
        if not self.sensor_options.enable_cpu_temperature or not self.sensor_options.enable_hardware_probe:
            return False

        now_ts = time.monotonic()
        if (now_ts - self._lhm_last_bootstrap_attempt_ts) < self._lhm_bootstrap_cooldown_sec:
            return False
        self._lhm_last_bootstrap_attempt_ts = now_ts
        LOGGER.info("CPU 온도 수집을 위해 LibreHardwareMonitor 자동 준비를 시도합니다.")
        return self._start_lhm_if_needed()

    def get_gpu_static_info(self) -> dict[str, Any]:
        if self._gpu_static_info_cache is not None:
            return dict(self._gpu_static_info_cache)

        info: dict[str, Any] = {
            "model_name": None,
            "vram_mb": None,
            "driver_version": None,
            "collection_status": "미수집",
        }

        if self._nvml_initialized and self._gpu_handle is not None and pynvml is not None:
            try:
                name = pynvml.nvmlDeviceGetName(self._gpu_handle)
                driver = pynvml.nvmlSystemGetDriverVersion()
                memory_info = pynvml.nvmlDeviceGetMemoryInfo(self._gpu_handle)
                info.update(
                    {
                        "model_name": name.decode("utf-8", errors="ignore") if isinstance(name, bytes) else str(name),
                        "vram_mb": round(memory_info.total / (1024 * 1024), 1),
                        "driver_version": driver.decode("utf-8", errors="ignore") if isinstance(driver, bytes) else str(driver),
                        "collection_status": "NVML",
                    }
                )
                self._gpu_static_info_cache = dict(info)
                return dict(info)
            except Exception as exc:
                LOGGER.info("NVML GPU 정적 정보 수집 실패: %s", exc)

        client = self._get_wmi(r"root\cimv2")
        if client is not None:
            try:
                controllers = client.Win32_VideoController()
                for controller in controllers:
                    name = str(getattr(controller, "Name", "") or "").strip()
                    if not name:
                        continue
                    info.update(
                        {
                            "model_name": name,
                            "vram_mb": round(int(getattr(controller, "AdapterRAM", 0) or 0) / (1024 * 1024), 1) or None,
                            "driver_version": str(getattr(controller, "DriverVersion", "") or "").strip() or None,
                            "collection_status": "WMI",
                        }
                    )
                    self._gpu_static_info_cache = dict(info)
                    return dict(info)
            except Exception as exc:
                LOGGER.info("WMI GPU 정적 정보 수집 실패: %s", exc)

        self._gpu_static_info_cache = dict(info)
        return dict(info)

    def _extract_temperature_from_entries(self, entries: list[Any], keywords: tuple[str, ...]) -> float | None:
        for entry in entries:
            label = " ".join(
                [
                    str(getattr(entry, "label", "") or ""),
                    str(getattr(entry, "name", "") or ""),
                ]
            ).lower()
            if keywords and not any(keyword in label for keyword in keywords):
                continue
            current = safe_float(getattr(entry, "current", None))
            if current is not None:
                return current
        return None

    def _probe_temperatures_via_psutil(self) -> tuple[float | None, float | None]:
        cpu_temp: float | None = None
        gpu_temp: float | None = None
        try:
            sensor_map = psutil.sensors_temperatures(fahrenheit=False)  # type: ignore[attr-defined]
        except Exception:
            sensor_map = {}

        if not sensor_map:
            return None, None

        all_entries: list[Any] = []
        for entries in sensor_map.values():
            all_entries.extend(entries)

        cpu_temp = self._extract_temperature_from_entries(
            all_entries,
            ("cpu", "package", "core", "tdie", "tctl", "ccd", "die"),
        )
        gpu_temp = self._extract_temperature_from_entries(
            all_entries,
            ("gpu", "graphics"),
        )
        return cpu_temp, gpu_temp

    def _extract_numeric_from_text(self, value: Any) -> float | None:
        if value is None:
            return None
        direct = safe_float(value)
        if direct is not None:
            return direct
        text = str(value).strip()
        if not text:
            return None
        match = self._NUMERIC_PATTERN.search(text)
        if not match:
            return None
        numeric = match.group(1).replace(",", ".")
        try:
            return float(numeric)
        except ValueError:
            return None

    def _score_cpu_temperature_scope(self, scope: str) -> int:
        text = scope.lower()
        score = 0
        if "cpu" in text:
            score += 25
        if "package" in text:
            score += 80
        if "tdie" in text or "tctl" in text:
            score += 75
        if "die" in text:
            score += 55
        if "ccd" in text:
            score += 45
        if "core max" in text or "core average" in text:
            score += 40
        if "core" in text:
            score += 20
        if "temperature" in text or "temp" in text:
            score += 10
        if any(token in text for token in ("gpu", "graphics", "motherboard", "mainboard", "pch", "vrm", "chipset")):
            score -= 120
        return score

    def _score_gpu_temperature_scope(self, scope: str) -> int:
        text = scope.lower()
        score = 0
        if "gpu" in text:
            score += 70
        if "graphics" in text:
            score += 35
        if "hot spot" in text or "hotspot" in text:
            score += 20
        if "temperature" in text or "temp" in text:
            score += 10
        if any(token in text for token in ("cpu", "package", "tdie", "tctl", "ccd")):
            score -= 120
        return score

    def _select_best_temperature(self, candidates: list[tuple[int, float, str]]) -> float | None:
        if not candidates:
            return None
        candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
        return round(candidates[0][1], 1)

    def _probe_temperatures_via_hardware_wmi(self) -> tuple[float | None, float | None]:
        cpu_candidates: list[tuple[int, float, str]] = []
        gpu_candidates: list[tuple[int, float, str]] = []

        for namespace in (r"root\LibreHardwareMonitor", r"root\OpenHardwareMonitor"):
            client = self._get_wmi(namespace)
            if client is None:
                continue
            try:
                sensors = client.Sensor()
            except Exception:
                continue

            for sensor in sensors:
                sensor_type = str(getattr(sensor, "SensorType", "") or "").lower()
                if sensor_type != "temperature":
                    continue

                name = str(getattr(sensor, "Name", "") or "").lower()
                identifier = str(getattr(sensor, "Identifier", "") or "").lower()
                parent = str(getattr(sensor, "Parent", "") or "").lower()
                scope = " ".join(part for part in (identifier, parent, name) if part)
                value = safe_float(getattr(sensor, "Value", None))
                if value is None or not (0.0 < value < 130.0):
                    continue

                cpu_score = self._score_cpu_temperature_scope(scope)
                gpu_score = self._score_gpu_temperature_scope(scope)
                if cpu_score > 0:
                    cpu_candidates.append((cpu_score, value, scope))
                if gpu_score > 0:
                    gpu_candidates.append((gpu_score, value, scope))

            if cpu_candidates or gpu_candidates:
                break

        return self._select_best_temperature(cpu_candidates), self._select_best_temperature(gpu_candidates)

    def _probe_cpu_temperature_via_acpi_wmi(self) -> float | None:
        client = self._get_wmi(r"root\WMI")
        if client is None:
            return None
        try:
            sensors = client.MSAcpi_ThermalZoneTemperature()
        except Exception:
            return None
        for sensor in sensors:
            raw_value = safe_float(getattr(sensor, "CurrentTemperature", None))
            if raw_value is None:
                continue
            celsius = (raw_value / 10.0) - 273.15
            if 0.0 < celsius < 130.0:
                return round(celsius, 1)
        return None

    def _probe_cpu_temperature_via_wintmp(self) -> float | None:
        if WinTmp is None or platform.system().lower() != "windows":
            return None
        try:
            value = safe_float(WinTmp.CPU_Temp())
            if value is not None and 0.0 < value < 130.0:
                return value
        except Exception as exc:
            LOGGER.info("WinTmp CPU 온도 수집 실패: %s", exc)
        return None

    def _probe_gpu_temperature_via_wintmp(self) -> float | None:
        if WinTmp is None or platform.system().lower() != "windows":
            return None
        try:
            value = safe_float(WinTmp.GPU_Temp())
            if value is not None and 0.0 < value < 130.0:
                return value
        except Exception as exc:
            LOGGER.info("WinTmp GPU 온도 수집 실패: %s", exc)
        return None

    def _get_lhm_http_json(self) -> Any | None:
        now_ts = time.monotonic()
        if self._lhm_http_cache_data is not None and (now_ts - self._lhm_http_cache_ts) < 1.0:
            return self._lhm_http_cache_data

        for url in self._lhm_http_candidates:
            try:
                request = urllib.request.Request(url, headers={"User-Agent": "PCInsightMonitor/1.0"})
                with urllib.request.urlopen(request, timeout=0.8) as response:
                    payload = response.read(2 * 1024 * 1024)
                data = json.loads(payload.decode("utf-8", errors="ignore"))
                self._lhm_http_cache_data = data
                self._lhm_http_cache_ts = now_ts
                if not self._lhm_http_available:
                    LOGGER.info("LibreHardwareMonitor HTTP 브리지를 감지했습니다: %s", url)
                self._lhm_http_available = True
                return data
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError, ValueError):
                continue
            except Exception:
                continue

        if self._lhm_http_available:
            LOGGER.info("LibreHardwareMonitor HTTP 브리지 연결이 해제되었습니다.")
        self._lhm_http_available = False
        self._lhm_http_cache_data = None
        self._lhm_http_cache_ts = now_ts
        return None

    def _walk_lhm_nodes(self, node: Any, path: list[str], output: list[dict[str, Any]]) -> None:
        if isinstance(node, list):
            for item in node:
                self._walk_lhm_nodes(item, path, output)
            return

        if not isinstance(node, dict):
            return

        text = str(node.get("Text") or node.get("Name") or "").strip()
        current_path = list(path)
        if text:
            current_path.append(text)

        value_raw = node.get("Value")
        if value_raw not in (None, ""):
            output.append(
                {
                    "path": current_path,
                    "scope": " ".join(current_path).lower(),
                    "value_raw": value_raw,
                    "value": self._extract_numeric_from_text(value_raw),
                }
            )

        children = node.get("Children")
        if isinstance(children, list):
            for child in children:
                self._walk_lhm_nodes(child, current_path, output)

    def _probe_temperatures_via_lhm_http(self) -> tuple[float | None, float | None]:
        if not self.sensor_options.enable_hardware_probe:
            return None, None

        payload = self._get_lhm_http_json()
        if payload is None:
            return None, None

        flattened: list[dict[str, Any]] = []
        self._walk_lhm_nodes(payload, [], flattened)

        cpu_candidates: list[tuple[int, float, str]] = []
        gpu_candidates: list[tuple[int, float, str]] = []
        for item in flattened:
            value = item.get("value")
            if value is None or not (0.0 < float(value) < 130.0):
                continue

            scope = str(item.get("scope") or "")
            value_raw_text = str(item.get("value_raw") or "").lower()
            if "°c" not in value_raw_text and "c" not in value_raw_text and not any(
                token in scope for token in ("temp", "temperature", "cpu", "gpu", "package", "tdie", "tctl", "ccd", "die")
            ):
                continue

            cpu_score = self._score_cpu_temperature_scope(scope)
            gpu_score = self._score_gpu_temperature_scope(scope)
            if cpu_score > 0:
                cpu_candidates.append((cpu_score, float(value), scope))
            if gpu_score > 0:
                gpu_candidates.append((gpu_score, float(value), scope))

        return self._select_best_temperature(cpu_candidates), self._select_best_temperature(gpu_candidates)

    def get_cpu_temperature(self) -> float | None:
        if not self.sensor_options.enable_cpu_temperature:
            return None

        cpu_temp, _ = self._probe_temperatures_via_hardware_wmi()
        if cpu_temp is not None:
            return cpu_temp

        cpu_temp, _ = self._probe_temperatures_via_lhm_http()
        if cpu_temp is not None:
            return cpu_temp

        cpu_temp = self._probe_cpu_temperature_via_acpi_wmi()
        if cpu_temp is not None:
            return cpu_temp

        cpu_temp = self._probe_cpu_temperature_via_wintmp()
        if cpu_temp is not None:
            return cpu_temp

        cpu_temp, _ = self._probe_temperatures_via_psutil()
        if cpu_temp is not None:
            return cpu_temp

        if self._maybe_bootstrap_lhm():
            for _ in range(20):
                time.sleep(0.5)
                cpu_temp, _ = self._probe_temperatures_via_hardware_wmi()
                if cpu_temp is not None:
                    return cpu_temp
                cpu_temp, _ = self._probe_temperatures_via_lhm_http()
                if cpu_temp is not None:
                    return cpu_temp

        return None

    def get_gpu_metrics(self) -> dict[str, Any]:
        metrics = {
            "gpu_percent": None,
            "gpu_mem_used_mb": None,
            "gpu_temp_c": None,
        }
        if not self.sensor_options.enable_gpu_metrics:
            return metrics

        if self._nvml_initialized and self._gpu_handle is not None and pynvml is not None:
            try:
                util = pynvml.nvmlDeviceGetUtilizationRates(self._gpu_handle)
                memory = pynvml.nvmlDeviceGetMemoryInfo(self._gpu_handle)
                metrics["gpu_percent"] = safe_float(getattr(util, "gpu", None))
                metrics["gpu_mem_used_mb"] = round(memory.used / (1024 * 1024), 1)
                if self.sensor_options.enable_gpu_temperature:
                    metrics["gpu_temp_c"] = safe_float(
                        pynvml.nvmlDeviceGetTemperature(
                            self._gpu_handle,
                            pynvml.NVML_TEMPERATURE_GPU,
                        )
                    )
                return metrics
            except Exception as exc:
                LOGGER.info("NVML GPU 실시간 수집 실패: %s", exc)

        if self.sensor_options.enable_gpu_temperature:
            _, gpu_temp = self._probe_temperatures_via_hardware_wmi()
            if gpu_temp is None:
                _, gpu_temp = self._probe_temperatures_via_lhm_http()
            if gpu_temp is None:
                gpu_temp = self._probe_gpu_temperature_via_wintmp()
            if gpu_temp is None:
                _, gpu_temp = self._probe_temperatures_via_psutil()
            metrics["gpu_temp_c"] = gpu_temp

        return metrics

    def _compute_rates(self) -> tuple[float | None, float | None, float | None, float | None]:
        now_ts = time.monotonic()
        if self._previous_rate_ts is None:
            self._prime_rate_counters()
            return None, None, None, None

        elapsed = max(now_ts - self._previous_rate_ts, 1e-6)
        disk_read_bps = None
        disk_write_bps = None
        net_sent_bps = None
        net_recv_bps = None

        try:
            disk = psutil.disk_io_counters()
            if disk and self._previous_disk is not None:
                read_delta = max(int(disk.read_bytes) - self._previous_disk[0], 0)
                write_delta = max(int(disk.write_bytes) - self._previous_disk[1], 0)
                disk_read_bps = read_delta / elapsed
                disk_write_bps = write_delta / elapsed
                self._previous_disk = (int(disk.read_bytes), int(disk.write_bytes))
        except Exception:
            disk_read_bps = None
            disk_write_bps = None

        try:
            net = psutil.net_io_counters()
            if net and self._previous_net is not None:
                sent_delta = max(int(net.bytes_sent) - self._previous_net[0], 0)
                recv_delta = max(int(net.bytes_recv) - self._previous_net[1], 0)
                net_sent_bps = sent_delta / elapsed
                net_recv_bps = recv_delta / elapsed
                self._previous_net = (int(net.bytes_sent), int(net.bytes_recv))
        except Exception:
            net_sent_bps = None
            net_recv_bps = None

        self._previous_rate_ts = now_ts
        return disk_read_bps, disk_write_bps, net_sent_bps, net_recv_bps

    def collect_metric_sample(self, collected_at: str | None = None) -> MetricSample:
        timestamp = collected_at or time.strftime("%Y-%m-%dT%H:%M:%S%z")

        try:
            cpu_percent = safe_float(psutil.cpu_percent(interval=None))
        except Exception:
            cpu_percent = None

        try:
            cpu_freq = psutil.cpu_freq()
            cpu_clock_mhz = safe_float(cpu_freq.current if cpu_freq else None)
        except Exception:
            cpu_clock_mhz = None

        cpu_temp = self.get_cpu_temperature()
        gpu_metrics = self.get_gpu_metrics()

        try:
            virtual_memory = psutil.virtual_memory()
            ram_used_mb = round((virtual_memory.used or 0) / (1024 * 1024), 1)
            ram_percent = safe_float(virtual_memory.percent)
        except Exception:
            ram_used_mb = None
            ram_percent = None

        disk_read_bps, disk_write_bps, net_sent_bps, net_recv_bps = self._compute_rates()

        return MetricSample(
            collected_at=timestamp,
            cpu_percent=cpu_percent,
            cpu_clock_mhz=cpu_clock_mhz,
            cpu_temp_c=cpu_temp,
            gpu_percent=safe_float(gpu_metrics.get("gpu_percent")),
            gpu_mem_used_mb=safe_float(gpu_metrics.get("gpu_mem_used_mb")),
            gpu_temp_c=safe_float(gpu_metrics.get("gpu_temp_c")),
            ram_used_mb=ram_used_mb,
            ram_percent=ram_percent,
            disk_read_bps=disk_read_bps,
            disk_write_bps=disk_write_bps,
            net_sent_bps=net_sent_bps,
            net_recv_bps=net_recv_bps,
        )
