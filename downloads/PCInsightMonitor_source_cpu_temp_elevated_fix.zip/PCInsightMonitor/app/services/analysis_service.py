from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, Iterable, Sequence

from app.constants import (
    EVENT_TYPE_LABELS,
    METRIC_DISPLAY_NAMES,
    METRIC_UNITS,
    OVERLOAD_CPU_TEMP,
    OVERLOAD_CPU_USAGE,
    OVERLOAD_GPU_TEMP,
    OVERLOAD_GPU_USAGE,
    OVERLOAD_RAM,
)
from app.models import (
    AnalysisResult,
    LiveAlert,
    MetricSample,
    MetricStats,
    OverloadEvent,
    PeakPoint,
    ProcessDisplayRow,
    ProcessSummary,
    ThresholdSettings,
)
from app.utils import calculate_percentile, format_duration, safe_mean, seconds_between, to_display_datetime


@dataclass(frozen=True)
class _EventConfig:
    event_type: str
    metric_key: str
    threshold_field: str


_EVENT_CONFIGS: tuple[_EventConfig, ...] = (
    _EventConfig(OVERLOAD_CPU_USAGE, "cpu_percent", "cpu_usage_percent"),
    _EventConfig(OVERLOAD_CPU_TEMP, "cpu_temp_c", "cpu_temp_c"),
    _EventConfig(OVERLOAD_GPU_USAGE, "gpu_percent", "gpu_usage_percent"),
    _EventConfig(OVERLOAD_GPU_TEMP, "gpu_temp_c", "gpu_temp_c"),
    _EventConfig(OVERLOAD_RAM, "ram_percent", "ram_percent"),
)


class LiveOverloadTracker:
    def __init__(self, analysis_service: "AnalysisService", sample_interval_sec: int) -> None:
        self.analysis_service = analysis_service
        self.thresholds = analysis_service.thresholds
        self.sample_interval_sec = max(int(sample_interval_sec), 1)
        self.required_count = max(1, math.ceil(self.thresholds.duration_sec / self.sample_interval_sec))
        self._states: dict[str, dict[str, Any]] = {
            config.event_type: {
                "candidate_count": 0,
                "candidate_start_at": None,
                "candidate_peak": None,
                "active": None,
            }
            for config in _EVENT_CONFIGS
        }

    def _reset(self, event_type: str) -> None:
        self._states[event_type] = {
            "candidate_count": 0,
            "candidate_start_at": None,
            "candidate_peak": None,
            "active": None,
        }

    def update(
        self,
        metric_sample: MetricSample,
        process_rows: Sequence[ProcessDisplayRow],
    ) -> tuple[list[LiveAlert], list[OverloadEvent]]:
        alerts: list[LiveAlert] = []
        closed_events: list[OverloadEvent] = []

        for config in _EVENT_CONFIGS:
            state = self._states[config.event_type]
            threshold_value = getattr(self.thresholds, config.threshold_field)
            value = getattr(metric_sample, config.metric_key)

            if value is not None and value >= threshold_value:
                if state["candidate_count"] == 0:
                    state["candidate_start_at"] = metric_sample.collected_at
                    state["candidate_peak"] = value
                state["candidate_count"] += 1
                state["candidate_peak"] = max(state["candidate_peak"], value) if state["candidate_peak"] is not None else value

                if state["active"] is None and state["candidate_count"] >= self.required_count:
                    suspected = self.analysis_service.rank_suspected_processes(process_rows, config.event_type, 3)
                    state["active"] = {
                        "started_at": state["candidate_start_at"] or metric_sample.collected_at,
                        "peak_value": state["candidate_peak"],
                        "suspected": suspected,
                    }
                elif state["active"] is not None:
                    state["active"]["peak_value"] = max(state["active"]["peak_value"], value)
                    suspected = self.analysis_service.rank_suspected_processes(process_rows, config.event_type, 3)
                    if suspected:
                        state["active"]["suspected"] = suspected
            else:
                if state["active"] is not None:
                    suspected = state["active"].get("suspected", [])
                    closed_events.append(
                        self.analysis_service.build_overload_event(
                            session_id=None,
                            event_type=config.event_type,
                            started_at=state["active"]["started_at"],
                            ended_at=metric_sample.collected_at,
                            threshold_value=threshold_value,
                            peak_value=state["active"]["peak_value"],
                            suspected_processes=suspected,
                        )
                    )
                self._reset(config.event_type)

            if state["active"] is not None:
                alerts.append(
                    LiveAlert(
                        event_type=config.event_type,
                        label=EVENT_TYPE_LABELS.get(config.event_type, config.event_type),
                        started_at=state["active"]["started_at"],
                        current_value=value,
                        threshold_value=threshold_value,
                        duration_sec=seconds_between(state["active"]["started_at"], metric_sample.collected_at),
                        suspected_processes=[item["process_name"] for item in state["active"].get("suspected", [])],
                    )
                )

        return alerts, closed_events

    def finalize(self, ended_at: str) -> list[OverloadEvent]:
        closed_events: list[OverloadEvent] = []
        for config in _EVENT_CONFIGS:
            state = self._states[config.event_type]
            if state["active"] is None:
                continue
            threshold_value = getattr(self.thresholds, config.threshold_field)
            suspected = state["active"].get("suspected", [])
            closed_events.append(
                self.analysis_service.build_overload_event(
                    session_id=None,
                    event_type=config.event_type,
                    started_at=state["active"]["started_at"],
                    ended_at=ended_at,
                    threshold_value=threshold_value,
                    peak_value=state["active"]["peak_value"],
                    suspected_processes=suspected,
                )
            )
            self._reset(config.event_type)
        return closed_events


class AnalysisService:
    def __init__(self, thresholds: ThresholdSettings | None = None) -> None:
        self.thresholds = thresholds or ThresholdSettings()

    def update_thresholds(self, thresholds: ThresholdSettings) -> None:
        self.thresholds = thresholds

    def create_live_tracker(self, sample_interval_sec: int) -> LiveOverloadTracker:
        return LiveOverloadTracker(self, sample_interval_sec)

    def rank_suspected_processes(
        self,
        rows: Sequence[ProcessDisplayRow],
        event_type: str,
        limit: int = 3,
    ) -> list[dict[str, Any]]:
        ranked: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            cpu = row.current_cpu_percent or 0.0
            memory = row.current_memory_mb or 0.0
            gpu = row.gpu_current_percent or 0.0
            disk = float(row.disk_read_total_bytes + row.disk_write_total_bytes)
            if row.status == "종료됨":
                continue

            if event_type in (OVERLOAD_CPU_USAGE, OVERLOAD_CPU_TEMP):
                score = cpu * 2.0 + (memory / 256.0) + (disk / (1024 * 1024 * 500))
            elif event_type == OVERLOAD_RAM:
                score = (memory / 64.0) * 2.0 + cpu
            elif event_type in (OVERLOAD_GPU_USAGE, OVERLOAD_GPU_TEMP):
                score = gpu * 3.0 + cpu
            else:
                score = cpu + memory / 256.0

            ranked.append(
                (
                    score,
                    {
                        "pid": row.pid,
                        "process_name": row.process_name,
                        "cpu_percent": round(cpu, 2),
                        "memory_mb": round(memory, 1),
                        "gpu_percent": round(gpu, 2) if row.gpu_current_percent is not None else None,
                        "disk_total_bytes": int(disk),
                    },
                )
            )

        ranked.sort(key=lambda item: (-item[0], item[1]["process_name"].lower()))
        return [item[1] for item in ranked[:limit]]

    def build_event_description(
        self,
        event_type: str,
        duration_sec: float | None,
        threshold_value: float,
        peak_value: float | None,
        suspected_processes: Sequence[dict[str, Any]],
    ) -> str:
        label = EVENT_TYPE_LABELS.get(event_type, event_type)
        process_text = ", ".join(item["process_name"] for item in suspected_processes) if suspected_processes else "특정 원인 프로세스를 식별하지 못함"
        peak_text = f"{peak_value:.1f}" if peak_value is not None else "값 없음"
        return (
            f"{label}이(가) 임계값 {threshold_value:.1f} 이상으로 {format_duration(duration_sec)} 동안 지속되었습니다. "
            f"최고값은 {peak_text}였으며, 주요 원인 후보는 {process_text}입니다."
        )

    def build_overload_event(
        self,
        session_id: int | None,
        event_type: str,
        started_at: str,
        ended_at: str,
        threshold_value: float,
        peak_value: float | None,
        suspected_processes: Sequence[dict[str, Any]],
    ) -> OverloadEvent:
        duration_sec = seconds_between(started_at, ended_at)
        return OverloadEvent(
            session_id=session_id,
            event_type=event_type,
            started_at=started_at,
            ended_at=ended_at,
            duration_sec=duration_sec,
            threshold_value=threshold_value,
            peak_value=peak_value,
            suspected_processes_json=json.dumps(list(suspected_processes), ensure_ascii=False),
            description=self.build_event_description(
                event_type=event_type,
                duration_sec=duration_sec,
                threshold_value=threshold_value,
                peak_value=peak_value,
                suspected_processes=suspected_processes,
            ),
        )

    def merge_adjacent_events(self, events: Sequence[OverloadEvent], gap_sec: int | None = None) -> list[OverloadEvent]:
        if not events:
            return []
        gap = self.thresholds.merge_gap_sec if gap_sec is None else gap_sec
        sorted_events = sorted(events, key=lambda event: (event.event_type, event.started_at))
        merged: list[OverloadEvent] = []

        for event in sorted_events:
            if not merged:
                merged.append(event)
                continue

            previous = merged[-1]
            same_type = previous.event_type == event.event_type
            if same_type and previous.ended_at and event.started_at:
                gap_value = seconds_between(previous.ended_at, event.started_at)
            else:
                gap_value = None

            if same_type and gap_value is not None and gap_value <= gap:
                peak_value = max(
                    previous.peak_value or float("-inf"),
                    event.peak_value or float("-inf"),
                )
                if peak_value == float("-inf"):
                    peak_value = None
                merged_processes = self.parse_suspected_processes(previous.suspected_processes_json)
                merged_processes.extend(self.parse_suspected_processes(event.suspected_processes_json))
                deduped: list[dict[str, Any]] = []
                seen: set[tuple[Any, Any]] = set()
                for item in merged_processes:
                    key = (item.get("pid"), item.get("process_name"))
                    if key in seen:
                        continue
                    seen.add(key)
                    deduped.append(item)
                merged[-1] = self.build_overload_event(
                    session_id=previous.session_id,
                    event_type=previous.event_type,
                    started_at=previous.started_at,
                    ended_at=event.ended_at or previous.ended_at or previous.started_at,
                    threshold_value=previous.threshold_value,
                    peak_value=peak_value,
                    suspected_processes=deduped[:3],
                )
            else:
                merged.append(event)

        return merged

    def parse_suspected_processes(self, payload: str | None) -> list[dict[str, Any]]:
        if not payload:
            return []
        try:
            parsed = json.loads(payload)
            if isinstance(parsed, list):
                return [item for item in parsed if isinstance(item, dict)]
        except Exception:
            return []
        return []

    def _extract_values(self, samples: Sequence[MetricSample], metric_key: str) -> list[float | None]:
        return [getattr(sample, metric_key, None) for sample in samples]

    def _build_stats(self, samples: Sequence[MetricSample]) -> list[MetricStats]:
        stats: list[MetricStats] = []
        for metric_key, display_name in METRIC_DISPLAY_NAMES.items():
            values = self._extract_values(samples, metric_key)
            valid = [value for value in values if value is not None]
            if valid:
                average = safe_mean(valid)
                minimum = min(valid)
                maximum = max(valid)
                p95 = calculate_percentile(valid, 95)
            else:
                average = minimum = maximum = p95 = None
            stats.append(
                MetricStats(
                    metric_key=metric_key,
                    display_name=display_name,
                    average=average,
                    minimum=minimum,
                    maximum=maximum,
                    p95=p95,
                    unit=METRIC_UNITS.get(metric_key, ""),
                )
            )
        return stats

    def _build_peak_point(self, label: str, metric_key: str, samples: Sequence[MetricSample]) -> PeakPoint:
        best_sample = None
        best_value: float | None = None
        for sample in samples:
            value = getattr(sample, metric_key, None)
            if value is None:
                continue
            if best_value is None or value > best_value:
                best_value = value
                best_sample = sample
        return PeakPoint(
            label=label,
            timestamp=best_sample.collected_at if best_sample else None,
            value=best_value,
            unit=METRIC_UNITS.get(metric_key, ""),
        )

    def _determine_peak_time_window(
        self,
        metric_samples: Sequence[MetricSample],
        overload_events: Sequence[OverloadEvent],
    ) -> str:
        longest_event = max(
            overload_events,
            key=lambda event: event.duration_sec or 0.0,
            default=None,
        )
        if longest_event is not None and longest_event.ended_at:
            return f"{to_display_datetime(longest_event.started_at)} ~ {to_display_datetime(longest_event.ended_at)}"

        cpu_peak = self._build_peak_point("CPU 최고 사용률", "cpu_percent", metric_samples)
        if cpu_peak.timestamp:
            return to_display_datetime(cpu_peak.timestamp)
        return "값 없음"

    def _top_processes(self, process_summaries: Sequence[ProcessSummary], limit: int = 10) -> list[ProcessSummary]:
        ranked = sorted(
            process_summaries,
            key=lambda item: (
                -(item.cpu_avg or 0.0),
                -(item.memory_avg_mb or 0.0),
                -(item.disk_read_total_bytes + item.disk_write_total_bytes),
                item.process_name.lower(),
            ),
        )
        return ranked[:limit]

    def _bottleneck_summary(
        self,
        stats: Sequence[MetricStats],
        overload_events: Sequence[OverloadEvent],
        top_processes: Sequence[ProcessSummary],
    ) -> str:
        event_types = {event.event_type for event in overload_events}
        top_name = top_processes[0].process_name if top_processes else "식별 실패"
        if OVERLOAD_CPU_USAGE in event_types or OVERLOAD_CPU_TEMP in event_types:
            return f"CPU 병목 가능성이 높습니다. 주요 후보 프로세스는 {top_name}입니다."
        if OVERLOAD_RAM in event_types:
            return f"메모리 병목 가능성이 높습니다. 주요 후보 프로세스는 {top_name}입니다."
        if OVERLOAD_GPU_USAGE in event_types or OVERLOAD_GPU_TEMP in event_types:
            return f"GPU 부하 가능성이 높습니다. 주요 후보 프로세스는 {top_name}입니다."
        cpu_stat = next((item for item in stats if item.metric_key == "cpu_percent"), None)
        ram_stat = next((item for item in stats if item.metric_key == "ram_percent"), None)
        if cpu_stat and (cpu_stat.average or 0) >= 70:
            return f"평균 CPU 사용률이 높습니다. {top_name}를 우선 점검하세요."
        if ram_stat and (ram_stat.average or 0) >= 80:
            return f"평균 메모리 사용률이 높습니다. {top_name}를 우선 점검하세요."
        return "뚜렷한 장시간 병목은 감지되지 않았습니다."

    def _recommendations(
        self,
        stats: Sequence[MetricStats],
        overload_events: Sequence[OverloadEvent],
    ) -> list[str]:
        recommendations: list[str] = []
        event_types = {event.event_type for event in overload_events}
        if OVERLOAD_CPU_USAGE in event_types:
            recommendations.append("백그라운드 프로그램 정리를 권장합니다.")
        if OVERLOAD_CPU_TEMP in event_types or OVERLOAD_GPU_TEMP in event_types:
            recommendations.append("냉각 상태 점검이 필요합니다.")
        if OVERLOAD_RAM in event_types:
            recommendations.append("메모리 사용량이 높아 메모리 증설 검토가 가능합니다.")
        disk_stat = next((item for item in stats if item.metric_key == "disk_write_bps"), None)
        if disk_stat and (disk_stat.p95 or 0) > 100 * 1024 * 1024:
            recommendations.append("디스크 I/O 집중 구간 확인이 필요합니다.")
        if not recommendations:
            recommendations.append("현재 설정을 유지하면서 추가 모니터링을 권장합니다.")
        return recommendations[:3]

    def _narrative(
        self,
        session_duration_sec: float,
        stats: Sequence[MetricStats],
        peak_points: Sequence[PeakPoint],
        overload_events: Sequence[OverloadEvent],
        top_processes: Sequence[ProcessSummary],
        recommendations: Sequence[str],
    ) -> str:
        cpu_stat = next((item for item in stats if item.metric_key == "cpu_percent"), None)
        ram_stat = next((item for item in stats if item.metric_key == "ram_percent"), None)
        cpu_peak = next((item for item in peak_points if item.label == "가장 높은 CPU 사용률 시점"), None)
        ram_peak = next((item for item in peak_points if item.label == "RAM 최고 사용 시점"), None)
        top_names = ", ".join(proc.process_name for proc in top_processes[:3]) if top_processes else "식별 실패"

        lines = [
            f"세션 총 길이는 {format_duration(session_duration_sec)}입니다.",
            f"평균 CPU 사용률은 {cpu_stat.average:.1f}%입니다." if cpu_stat and cpu_stat.average is not None else "평균 CPU 사용률은 값 없음입니다.",
            f"평균 RAM 사용률은 {ram_stat.average:.1f}%입니다." if ram_stat and ram_stat.average is not None else "평균 RAM 사용률은 값 없음입니다.",
            f"CPU 피크 시점은 {to_display_datetime(cpu_peak.timestamp) if cpu_peak and cpu_peak.timestamp else '값 없음'}입니다.",
            f"RAM 피크 시점은 {to_display_datetime(ram_peak.timestamp) if ram_peak and ram_peak.timestamp else '값 없음'}입니다.",
        ]
        if overload_events:
            longest = max(overload_events, key=lambda item: item.duration_sec or 0.0)
            lines.append(
                f"{to_display_datetime(longest.started_at)}부터 {to_display_datetime(longest.ended_at)}까지 과부하가 가장 길게 지속되었습니다."
            )
        else:
            lines.append("세션 동안 연속 과부하 이벤트는 감지되지 않았습니다.")
        lines.append(f"상위 자원 소비 프로그램은 {top_names}입니다.")
        if recommendations:
            lines.append("권장 조치: " + " / ".join(recommendations))
        return " ".join(lines)

    def analyze_session(
        self,
        session_id: int,
        metric_samples: Sequence[MetricSample],
        process_summaries: Sequence[ProcessSummary],
        overload_events: Sequence[OverloadEvent],
        *,
        started_at: str | None = None,
        ended_at: str | None = None,
    ) -> AnalysisResult:
        sample_count = len(metric_samples)
        if started_at and ended_at:
            session_duration_sec = seconds_between(started_at, ended_at)
        elif metric_samples:
            session_duration_sec = seconds_between(metric_samples[0].collected_at, metric_samples[-1].collected_at)
        else:
            session_duration_sec = 0.0

        stats = self._build_stats(metric_samples)
        peak_points = [
            self._build_peak_point("가장 높은 CPU 사용률 시점", "cpu_percent", metric_samples),
            self._build_peak_point("가장 높은 GPU 사용률 시점", "gpu_percent", metric_samples),
            self._build_peak_point("가장 높은 CPU 온도 시점", "cpu_temp_c", metric_samples),
            self._build_peak_point("가장 높은 GPU 온도 시점", "gpu_temp_c", metric_samples),
            self._build_peak_point("RAM 최고 사용 시점", "ram_percent", metric_samples),
        ]
        merged_events = self.merge_adjacent_events(overload_events)
        top_processes = self._top_processes(process_summaries)
        recommendations = self._recommendations(stats, merged_events)
        bottleneck_summary = self._bottleneck_summary(stats, merged_events, top_processes)
        peak_time_window = self._determine_peak_time_window(metric_samples, merged_events)
        narrative_summary = self._narrative(
            session_duration_sec=session_duration_sec,
            stats=stats,
            peak_points=peak_points,
            overload_events=merged_events,
            top_processes=top_processes,
            recommendations=recommendations,
        )
        longest_event = max(merged_events, key=lambda event: event.duration_sec or 0.0, default=None)

        return AnalysisResult(
            session_id=session_id,
            session_duration_sec=session_duration_sec,
            sample_count=sample_count,
            stats=stats,
            peak_points=peak_points,
            overload_events=merged_events,
            total_overload_count=len(merged_events),
            longest_event=longest_event,
            peak_time_window=peak_time_window,
            bottleneck_summary=bottleneck_summary,
            narrative_summary=narrative_summary,
            recommendations=recommendations,
            top_processes=top_processes,
        )
