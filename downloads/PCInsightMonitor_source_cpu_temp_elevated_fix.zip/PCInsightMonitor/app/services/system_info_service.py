from __future__ import annotations

import getpass
import platform
import socket
from datetime import timedelta
from typing import Any

import psutil

from app.constants import VALUE_COLLECTION_FAILED, VALUE_UNAVAILABLE, VALUE_UNSUPPORTED
from app.logger import get_logger
from app.models import SensorOptions, SystemInfoItem
from app.services.sensor_service import SensorService
from app.utils import format_bytes, format_clock_mhz, format_duration, format_gb_from_mb, format_mb, format_optional

LOGGER = get_logger(__name__)

try:
    import wmi  # type: ignore
except Exception:
    wmi = None


class SystemInfoService:
    """Windows 시스템 사양 및 하드웨어 정보를 수집한다."""

    def __init__(
        self,
        sensor_options: SensorOptions | None = None,
        sensor_service: SensorService | None = None,
    ) -> None:
        self.sensor_options = sensor_options or SensorOptions()
        self.sensor_service = sensor_service or SensorService(self.sensor_options)
        self._wmi_client = None

    def _get_wmi(self) -> Any | None:
        if not self.sensor_options.enable_hardware_probe or wmi is None:
            return None
        if self._wmi_client is None:
            try:
                self._wmi_client = wmi.WMI(namespace="root\\cimv2")
            except Exception:
                self._wmi_client = None
        return self._wmi_client

    def _append(self, items: list[SystemInfoItem], category: str, key: str, value: Any, none_text: str = VALUE_UNAVAILABLE) -> None:
        items.append(SystemInfoItem(category=category, key=key, value=format_optional(value, none_text=none_text)))

    def _parse_wmi_date(self, raw_value: Any) -> str:
        text = str(raw_value or "").strip()
        if len(text) >= 8 and text[:8].isdigit():
            return f"{text[:4]}-{text[4:6]}-{text[6:8]}"
        return VALUE_UNAVAILABLE

    def _collect_basic_info(self, items: list[SystemInfoItem]) -> None:
        self._append(items, "기본 정보", "컴퓨터 이름", platform.node(), VALUE_COLLECTION_FAILED)
        try:
            username = getpass.getuser()
        except Exception:
            username = VALUE_COLLECTION_FAILED
        self._append(items, "기본 정보", "사용자 이름", username, VALUE_COLLECTION_FAILED)
        self._append(items, "기본 정보", "운영체제 이름", platform.system())
        self._append(items, "기본 정보", "운영체제 버전", platform.version())
        self._append(items, "기본 정보", "OS 릴리스", platform.release())
        self._append(items, "기본 정보", "아키텍처", platform.machine() or platform.architecture()[0])
        self._append(items, "기본 정보", "Python 버전", platform.python_version())

    def _collect_cpu_info(self, items: list[SystemInfoItem]) -> None:
        cpu_name = platform.processor() or None
        cpu_vendor = None
        wmi_client = self._get_wmi()
        if wmi_client is not None:
            try:
                processors = wmi_client.Win32_Processor()
                if processors:
                    processor = processors[0]
                    cpu_name = str(getattr(processor, "Name", "") or "").strip() or cpu_name
                    cpu_vendor = str(getattr(processor, "Manufacturer", "") or "").strip() or None
            except Exception as exc:
                LOGGER.info("WMI CPU 정보 수집 실패: %s", exc)

        self._append(items, "CPU", "CPU 모델명", cpu_name)
        self._append(items, "CPU", "CPU 제조사", cpu_vendor, VALUE_UNSUPPORTED)
        self._append(items, "CPU", "물리 코어 수", psutil.cpu_count(logical=False))
        self._append(items, "CPU", "논리 코어 수", psutil.cpu_count(logical=True))
        try:
            cpu_freq = psutil.cpu_freq()
        except Exception:
            cpu_freq = None
        self._append(items, "CPU", "기본 클럭", format_clock_mhz(getattr(cpu_freq, "min", None)), VALUE_UNSUPPORTED)
        self._append(items, "CPU", "최대 클럭", format_clock_mhz(getattr(cpu_freq, "max", None)), VALUE_UNSUPPORTED)
        self._append(items, "CPU", "현재 클럭", format_clock_mhz(getattr(cpu_freq, "current", None)), VALUE_UNSUPPORTED)

    def _collect_memory_info(self, items: list[SystemInfoItem]) -> None:
        try:
            memory = psutil.virtual_memory()
            total_mb = round(memory.total / (1024 * 1024), 1)
            used_mb = round(memory.used / (1024 * 1024), 1)
            available_mb = round(memory.available / (1024 * 1024), 1)
        except Exception:
            total_mb = used_mb = available_mb = None
        self._append(items, "RAM", "RAM 총용량", format_gb_from_mb(total_mb))
        self._append(items, "RAM", "RAM 사용량", format_gb_from_mb(used_mb))
        self._append(items, "RAM", "RAM 가용 용량", format_gb_from_mb(available_mb))

        slot_info = []
        wmi_client = self._get_wmi()
        if wmi_client is not None:
            try:
                modules = wmi_client.Win32_PhysicalMemory()
                for index, module in enumerate(modules, start=1):
                    cap_bytes = int(getattr(module, "Capacity", 0) or 0)
                    speed = getattr(module, "Speed", None)
                    manufacturer = str(getattr(module, "Manufacturer", "") or "").strip()
                    slot_info.append(
                        f"{index}번 슬롯: {format_bytes(cap_bytes)} / {manufacturer or VALUE_UNAVAILABLE} / {speed or VALUE_UNAVAILABLE} MHz"
                    )
            except Exception as exc:
                LOGGER.info("WMI RAM 슬롯 정보 수집 실패: %s", exc)

        self._append(
            items,
            "RAM",
            "RAM 슬롯 정보",
            " | ".join(slot_info) if slot_info else VALUE_UNSUPPORTED,
            VALUE_UNSUPPORTED,
        )

    def _collect_gpu_info(self, items: list[SystemInfoItem]) -> None:
        gpu_info = self.sensor_service.get_gpu_static_info()
        self._append(items, "GPU", "GPU 모델명", gpu_info.get("model_name"), VALUE_UNSUPPORTED)
        vram = gpu_info.get("vram_mb")
        self._append(items, "GPU", "GPU 메모리(VRAM)", format_mb(vram) if vram is not None else VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
        self._append(items, "GPU", "GPU 드라이버 정보", gpu_info.get("driver_version"), VALUE_UNSUPPORTED)
        self._append(items, "GPU", "GPU 정보 수집 방식", gpu_info.get("collection_status"), VALUE_UNSUPPORTED)

    def _collect_disk_info(self, items: list[SystemInfoItem]) -> None:
        wmi_client = self._get_wmi()
        if wmi_client is not None:
            try:
                for index, disk in enumerate(wmi_client.Win32_DiskDrive(), start=1):
                    category = f"물리 디스크 - {index}"
                    self._append(items, category, "디스크 모델명", getattr(disk, "Model", None))
                    self._append(items, category, "인터페이스", getattr(disk, "InterfaceType", None), VALUE_UNSUPPORTED)
                    self._append(items, category, "총용량", format_bytes(int(getattr(disk, "Size", 0) or 0)))
            except Exception as exc:
                LOGGER.info("WMI 물리 디스크 정보 수집 실패: %s", exc)

        try:
            partitions = psutil.disk_partitions(all=False)
        except Exception:
            partitions = []
        for partition in partitions:
            category = f"논리 디스크 - {partition.device}"
            self._append(items, category, "파일시스템", partition.fstype or VALUE_UNAVAILABLE)
            self._append(items, category, "마운트 경로", partition.mountpoint or VALUE_UNAVAILABLE)
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                self._append(items, category, "총용량", format_bytes(usage.total))
                self._append(items, category, "사용량", format_bytes(usage.used))
                self._append(items, category, "남은 용량", format_bytes(usage.free))
            except PermissionError:
                self._append(items, category, "총용량", VALUE_COLLECTION_FAILED)
                self._append(items, category, "사용량", VALUE_COLLECTION_FAILED)
                self._append(items, category, "남은 용량", VALUE_COLLECTION_FAILED)
            except Exception:
                self._append(items, category, "총용량", VALUE_UNAVAILABLE)
                self._append(items, category, "사용량", VALUE_UNAVAILABLE)
                self._append(items, category, "남은 용량", VALUE_UNAVAILABLE)

    def _collect_board_bios_info(self, items: list[SystemInfoItem]) -> None:
        wmi_client = self._get_wmi()
        if wmi_client is None:
            self._append(items, "메인보드", "메인보드 제조사", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            self._append(items, "메인보드", "메인보드 모델명", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            self._append(items, "BIOS", "BIOS 제조사", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            self._append(items, "BIOS", "BIOS 버전", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            self._append(items, "BIOS", "BIOS 날짜", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            return

        try:
            boards = wmi_client.Win32_BaseBoard()
            if boards:
                board = boards[0]
                self._append(items, "메인보드", "메인보드 제조사", getattr(board, "Manufacturer", None), VALUE_UNSUPPORTED)
                self._append(items, "메인보드", "메인보드 모델명", getattr(board, "Product", None), VALUE_UNSUPPORTED)
            else:
                self._append(items, "메인보드", "메인보드 제조사", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
                self._append(items, "메인보드", "메인보드 모델명", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
        except Exception as exc:
            LOGGER.info("WMI 메인보드 정보 수집 실패: %s", exc)
            self._append(items, "메인보드", "메인보드 제조사", VALUE_COLLECTION_FAILED, VALUE_COLLECTION_FAILED)
            self._append(items, "메인보드", "메인보드 모델명", VALUE_COLLECTION_FAILED, VALUE_COLLECTION_FAILED)

        try:
            bios_list = wmi_client.Win32_BIOS()
            if bios_list:
                bios = bios_list[0]
                self._append(items, "BIOS", "BIOS 제조사", getattr(bios, "Manufacturer", None), VALUE_UNSUPPORTED)
                self._append(items, "BIOS", "BIOS 버전", getattr(bios, "SMBIOSBIOSVersion", None), VALUE_UNSUPPORTED)
                self._append(items, "BIOS", "BIOS 날짜", self._parse_wmi_date(getattr(bios, "ReleaseDate", None)), VALUE_UNSUPPORTED)
            else:
                self._append(items, "BIOS", "BIOS 제조사", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
                self._append(items, "BIOS", "BIOS 버전", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
                self._append(items, "BIOS", "BIOS 날짜", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
        except Exception as exc:
            LOGGER.info("WMI BIOS 정보 수집 실패: %s", exc)
            self._append(items, "BIOS", "BIOS 제조사", VALUE_COLLECTION_FAILED, VALUE_COLLECTION_FAILED)
            self._append(items, "BIOS", "BIOS 버전", VALUE_COLLECTION_FAILED, VALUE_COLLECTION_FAILED)
            self._append(items, "BIOS", "BIOS 날짜", VALUE_COLLECTION_FAILED, VALUE_COLLECTION_FAILED)

    def _collect_network_info(self, items: list[SystemInfoItem]) -> None:
        try:
            addrs_map = psutil.net_if_addrs()
            stats_map = psutil.net_if_stats()
        except Exception:
            addrs_map = {}
            stats_map = {}

        for name, addrs in addrs_map.items():
            category = f"네트워크 - {name}"
            ipv4 = VALUE_UNAVAILABLE
            mac = VALUE_UNAVAILABLE
            for addr in addrs:
                if getattr(addr, "family", None) == socket.AF_INET:
                    ipv4 = addr.address or VALUE_UNAVAILABLE
                elif getattr(psutil, "AF_LINK", object()) == getattr(addr, "family", None):
                    mac = addr.address or VALUE_UNAVAILABLE
            stat = stats_map.get(name)
            self._append(items, category, "IP 주소", ipv4)
            self._append(items, category, "MAC 주소", mac)
            if stat is not None:
                self._append(items, category, "링크 상태", "연결됨" if stat.isup else "연결 안 됨")
                self._append(items, category, "속도", f"{stat.speed} Mbps" if stat.speed and stat.speed > 0 else VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)

    def _collect_battery_info(self, items: list[SystemInfoItem]) -> None:
        if not self.sensor_options.enable_battery_probe:
            self._append(items, "배터리", "배터리 정보", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            return
        try:
            battery = psutil.sensors_battery()
        except Exception:
            battery = None

        if battery is None:
            self._append(items, "배터리", "배터리 정보", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
            return

        self._append(items, "배터리", "충전률", f"{battery.percent:.1f}%")
        self._append(items, "배터리", "전원 연결", "연결됨" if battery.power_plugged else "배터리 사용 중")
        if battery.secsleft is None or battery.secsleft < 0:
            self._append(items, "배터리", "남은 시간", VALUE_UNSUPPORTED, VALUE_UNSUPPORTED)
        else:
            self._append(items, "배터리", "남은 시간", format_duration(battery.secsleft))

    def gather_system_info(self) -> list[SystemInfoItem]:
        items: list[SystemInfoItem] = []
        self._collect_basic_info(items)
        self._collect_cpu_info(items)
        self._collect_memory_info(items)
        self._collect_gpu_info(items)
        self._collect_disk_info(items)
        self._collect_board_bios_info(items)
        self._collect_network_info(items)
        self._collect_battery_info(items)
        items.sort(key=lambda item: (item.category, item.key))
        return items
