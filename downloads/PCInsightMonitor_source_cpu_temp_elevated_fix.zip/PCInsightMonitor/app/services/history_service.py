from __future__ import annotations

from typing import Sequence

from app.database.db_manager import DatabaseManager
from app.models import AnalysisResult, ProcessDisplayRow, SessionBundle, SessionRecord
from app.services.analysis_service import AnalysisService


class HistoryService:
    def __init__(self, db_manager: DatabaseManager, analysis_service: AnalysisService) -> None:
        self.db_manager = db_manager
        self.analysis_service = analysis_service

    def get_sessions(self, limit: int = 500, status: str | None = None) -> list[SessionRecord]:
        return self.db_manager.get_sessions(status=status, limit=limit)

    def load_session_bundle(self, session_id: int) -> SessionBundle | None:
        session = self.db_manager.get_session(session_id)
        if session is None:
            return None
        system_info = self.db_manager.get_system_info_snapshot(session_id)
        metric_samples = self.db_manager.get_metric_samples(session_id)
        process_samples = self.db_manager.get_process_samples(session_id)
        process_summaries = self.db_manager.get_process_summaries(session_id)
        overload_events = self.db_manager.get_overload_events(session_id)
        analysis = self.analysis_service.analyze_session(
            session_id=session.id,
            metric_samples=metric_samples,
            process_summaries=process_summaries,
            overload_events=overload_events,
            started_at=session.started_at,
            ended_at=session.ended_at,
        )
        return SessionBundle(
            session=session,
            system_info=system_info,
            metric_samples=metric_samples,
            process_samples=process_samples,
            process_summaries=process_summaries,
            overload_events=overload_events,
            analysis=analysis,
        )

    def reanalyze_session(self, session_id: int) -> AnalysisResult | None:
        bundle = self.load_session_bundle(session_id)
        if bundle is None:
            return None
        return bundle.analysis

    def build_process_rows_from_summaries(self, process_summaries: Sequence) -> list[ProcessDisplayRow]:
        rows: list[ProcessDisplayRow] = []
        for summary in process_summaries:
            rows.append(
                ProcessDisplayRow(
                    pid=summary.pid,
                    process_name=summary.process_name,
                    start_time=summary.first_seen_at,
                    runtime_sec=summary.runtime_sec,
                    current_cpu_percent=summary.cpu_avg,
                    avg_cpu_percent=summary.cpu_avg,
                    max_cpu_percent=summary.cpu_max,
                    current_memory_mb=summary.memory_avg_mb,
                    avg_memory_mb=summary.memory_avg_mb,
                    max_memory_mb=summary.memory_max_mb,
                    disk_read_total_bytes=summary.disk_read_total_bytes,
                    disk_write_total_bytes=summary.disk_write_total_bytes,
                    gpu_current_percent=summary.gpu_avg,
                    status=summary.last_status,
                )
            )
        rows.sort(
            key=lambda row: (
                -(row.avg_cpu_percent or 0.0),
                -(row.avg_memory_mb or 0.0),
                -(row.disk_read_total_bytes + row.disk_write_total_bytes),
                row.process_name.lower(),
            )
        )
        return rows
