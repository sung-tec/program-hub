from __future__ import annotations

import time
from typing import Optional

from PySide6.QtCore import QObject, QThread, Signal

from app.constants import (
    SESSION_STATUS_IDLE,
    SESSION_STATUS_PAUSED,
    SESSION_STATUS_RUNNING,
    SESSION_STATUS_STOPPED,
)
from app.database.db_manager import DatabaseManager
from app.logger import get_logger
from app.models import (
    AppSettings,
    MonitorStatusSnapshot,
    SessionBundle,
    SessionRecord,
)
from app.services.analysis_service import AnalysisService
from app.services.process_service import ProcessService
from app.services.sensor_service import SensorService
from app.services.system_info_service import SystemInfoService
from app.utils import now_iso

LOGGER = get_logger(__name__)


class MonitorWorker(QThread):
    metric_sample_collected = Signal(object)
    process_rows_updated = Signal(object)
    system_info_collected = Signal(object)
    alerts_updated = Signal(object)
    status_updated = Signal(object)
    session_finished = Signal(object)
    error_signal = Signal(str)

    def __init__(
        self,
        db_manager: DatabaseManager,
        settings: AppSettings,
        session_name: str,
    ) -> None:
        super().__init__()
        self.db_manager = db_manager
        self.settings = settings
        self.session_name = session_name

        self._stop_requested = False
        self._paused = False
        self._state = SESSION_STATUS_IDLE
        self._session_id: int | None = None
        self._started_at: str | None = None
        self._last_sample_at: str | None = None
        self._last_saved_at: str | None = None
        self._system_info = []
        self._metric_samples = []
        self._process_samples = []
        self._overload_events = []

        self.sensor_service = SensorService(settings.sensor_options)
        self.system_info_service = SystemInfoService(settings.sensor_options, self.sensor_service)
        self.process_service = ProcessService()
        self.analysis_service = AnalysisService(settings.overload_thresholds)
        self.live_tracker = self.analysis_service.create_live_tracker(settings.sample_interval_sec)

    def _emit_status(self, message: str = "") -> None:
        self.status_updated.emit(
            MonitorStatusSnapshot(
                session_id=self._session_id,
                session_name=self.session_name,
                state=self._state,
                last_sample_at=self._last_sample_at,
                last_saved_at=self._last_saved_at,
                message=message,
            )
        )

    def pause_monitoring(self) -> None:
        if self._state != SESSION_STATUS_RUNNING:
            return
        self._paused = True
        self._state = SESSION_STATUS_PAUSED
        if self._session_id is not None:
            self.db_manager.update_session(self._session_id, status=SESSION_STATUS_PAUSED)
        self._emit_status("모니터링이 일시정지되었습니다.")

    def resume_monitoring(self) -> None:
        if self._state != SESSION_STATUS_PAUSED:
            return
        self._paused = False
        self._state = SESSION_STATUS_RUNNING
        if self._session_id is not None:
            self.db_manager.update_session(self._session_id, status=SESSION_STATUS_RUNNING)
        self._emit_status("모니터링이 재개되었습니다.")

    def stop_monitoring(self) -> None:
        self._stop_requested = True

    def _sleep_with_checks(self, seconds: int) -> None:
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self._stop_requested:
                break
            time.sleep(0.1)

    def run(self) -> None:
        error_message = ""
        try:
            self._state = SESSION_STATUS_RUNNING
            self._started_at = now_iso()
            self._session_id = self.db_manager.insert_session(
                session_name=self.session_name,
                started_at=self._started_at,
                status=SESSION_STATUS_RUNNING,
                sample_interval_sec=self.settings.sample_interval_sec,
                notes="",
            )
            self._emit_status("세션을 시작했습니다.")

            self.sensor_service.warmup()
            self.process_service.reset()
            self.process_service.warmup_existing_processes()

            info_collected_at = now_iso()
            self._system_info = self.system_info_service.gather_system_info()
            self.db_manager.save_system_info_snapshot(self._session_id, info_collected_at, self._system_info)
            self._last_saved_at = info_collected_at
            self.system_info_collected.emit(self._system_info)

            while not self._stop_requested:
                if self._paused:
                    time.sleep(0.1)
                    continue

                collected_at = now_iso()
                metric_sample = self.sensor_service.collect_metric_sample(collected_at)
                process_samples = self.process_service.collect_process_samples(collected_at)
                process_rows = self.process_service.get_display_rows()

                self._metric_samples.append(metric_sample)
                self._process_samples.extend(process_samples)
                self._last_sample_at = collected_at

                if self.settings.auto_save and self._session_id is not None:
                    self.db_manager.insert_metric_sample(self._session_id, metric_sample)
                    self.db_manager.insert_process_samples(self._session_id, process_samples)
                    self._last_saved_at = collected_at

                alerts, newly_closed = self.live_tracker.update(metric_sample, process_rows)
                if newly_closed:
                    self._overload_events.extend(newly_closed)

                self.metric_sample_collected.emit(metric_sample)
                self.process_rows_updated.emit(process_rows)
                self.alerts_updated.emit(alerts)
                self._emit_status()

                self._sleep_with_checks(self.settings.sample_interval_sec)

        except Exception as exc:
            LOGGER.exception("모니터링 워커 실행 중 오류가 발생했습니다.")
            error_message = str(exc)
            self.error_signal.emit(f"모니터링 워커 오류: {exc}")
        finally:
            self._finalize_session(error_message=error_message)

    def _finalize_session(self, error_message: str = "") -> None:
        ended_at = now_iso()
        try:
            self._overload_events.extend(self.live_tracker.finalize(ended_at))
            self._overload_events = self.analysis_service.merge_adjacent_events(self._overload_events)

            if self._session_id is not None:
                if not self.settings.auto_save:
                    self.db_manager.insert_metric_samples(self._session_id, self._metric_samples)
                    self.db_manager.insert_process_samples(self._session_id, self._process_samples)
                    if self._metric_samples or self._process_samples:
                        self._last_saved_at = now_iso()

                process_summaries = self.process_service.build_summaries(self._session_id)
                self.db_manager.replace_process_summaries(self._session_id, process_summaries)
                self.db_manager.replace_overload_events(self._session_id, self._overload_events)
                self.db_manager.update_session(
                    self._session_id,
                    ended_at=ended_at,
                    status=SESSION_STATUS_STOPPED,
                    notes=error_message,
                )

                session = SessionRecord(
                    id=self._session_id,
                    session_name=self.session_name,
                    started_at=self._started_at or ended_at,
                    ended_at=ended_at,
                    status=SESSION_STATUS_STOPPED,
                    sample_interval_sec=self.settings.sample_interval_sec,
                    notes=error_message,
                )
                analysis = self.analysis_service.analyze_session(
                    session_id=self._session_id,
                    metric_samples=self._metric_samples,
                    process_summaries=process_summaries,
                    overload_events=self._overload_events,
                    started_at=session.started_at,
                    ended_at=ended_at,
                )
                bundle = SessionBundle(
                    session=session,
                    system_info=self._system_info,
                    metric_samples=self._metric_samples,
                    process_samples=self._process_samples,
                    process_summaries=process_summaries,
                    overload_events=self._overload_events,
                    analysis=analysis,
                )
                self.session_finished.emit(bundle)

        except Exception as exc:
            LOGGER.exception("세션 종료 정리 중 오류가 발생했습니다.")
            self.error_signal.emit(f"세션 종료 처리 오류: {exc}")
        finally:
            self.sensor_service.cleanup()
            self._state = SESSION_STATUS_STOPPED if self._session_id is not None else SESSION_STATUS_IDLE
            self._emit_status("세션이 종료되었습니다.")


class MonitorService(QObject):
    metric_sample_collected = Signal(object)
    process_rows_updated = Signal(object)
    system_info_collected = Signal(object)
    alerts_updated = Signal(object)
    status_updated = Signal(object)
    session_finished = Signal(object)
    error_signal = Signal(str)

    def __init__(self, db_manager: DatabaseManager) -> None:
        super().__init__()
        self.db_manager = db_manager
        self._worker: MonitorWorker | None = None

    def is_active(self) -> bool:
        return self._worker is not None and self._worker.isRunning()

    def start_monitoring(self, settings: AppSettings, session_name: str) -> bool:
        if self.is_active():
            self.error_signal.emit("이미 실행 중인 모니터링 세션이 있습니다.")
            return False

        self._worker = MonitorWorker(self.db_manager, settings, session_name)
        self._worker.metric_sample_collected.connect(self.metric_sample_collected.emit)
        self._worker.process_rows_updated.connect(self.process_rows_updated.emit)
        self._worker.system_info_collected.connect(self.system_info_collected.emit)
        self._worker.alerts_updated.connect(self.alerts_updated.emit)
        self._worker.status_updated.connect(self.status_updated.emit)
        self._worker.session_finished.connect(self.session_finished.emit)
        self._worker.error_signal.connect(self.error_signal.emit)
        self._worker.finished.connect(self._on_worker_finished)
        self._worker.start()
        return True

    def pause_monitoring(self) -> None:
        if self._worker is not None:
            self._worker.pause_monitoring()

    def resume_monitoring(self) -> None:
        if self._worker is not None:
            self._worker.resume_monitoring()

    def stop_monitoring(self) -> None:
        if self._worker is not None:
            self._worker.stop_monitoring()

    def shutdown(self, wait_ms: int = 15000) -> None:
        if self._worker is None:
            return
        self._worker.stop_monitoring()
        self._worker.wait(wait_ms)

    def _on_worker_finished(self) -> None:
        self._worker = None
