from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import psutil

from app.constants import VALUE_UNAVAILABLE
from app.logger import get_logger
from app.models import ProcessDisplayRow, ProcessSample, ProcessSummary
from app.utils import seconds_between

LOGGER = get_logger(__name__)


@dataclass
class _TrackedProcess:
    pid: int
    process_name: str
    start_time: str | None
    first_seen_at: str
    last_seen_at: str
    current_cpu_percent: float | None = None
    current_memory_mb: float | None = None
    current_gpu_percent: float | None = None
    cpu_sum: float = 0.0
    cpu_count: int = 0
    cpu_max: float | None = None
    memory_sum: float = 0.0
    memory_count: int = 0
    memory_max: float | None = None
    gpu_sum: float = 0.0
    gpu_count: int = 0
    gpu_max: float | None = None
    disk_read_total_bytes: int = 0
    disk_write_total_bytes: int = 0
    last_disk_read_bytes: int | None = None
    last_disk_write_bytes: int | None = None
    status: str = "실행 중"
    seen_in_cycle: bool = False

    def update_numeric(self, cpu: float | None, memory_mb: float | None, gpu_percent: float | None) -> None:
        self.current_cpu_percent = cpu
        self.current_memory_mb = memory_mb
        self.current_gpu_percent = gpu_percent

        if cpu is not None:
            self.cpu_sum += cpu
            self.cpu_count += 1
            self.cpu_max = cpu if self.cpu_max is None else max(self.cpu_max, cpu)

        if memory_mb is not None:
            self.memory_sum += memory_mb
            self.memory_count += 1
            self.memory_max = memory_mb if self.memory_max is None else max(self.memory_max, memory_mb)

        if gpu_percent is not None:
            self.gpu_sum += gpu_percent
            self.gpu_count += 1
            self.gpu_max = gpu_percent if self.gpu_max is None else max(self.gpu_max, gpu_percent)

    def cpu_avg(self) -> float | None:
        return self.cpu_sum / self.cpu_count if self.cpu_count else None

    def memory_avg(self) -> float | None:
        return self.memory_sum / self.memory_count if self.memory_count else None

    def gpu_avg(self) -> float | None:
        return self.gpu_sum / self.gpu_count if self.gpu_count else None


class ProcessService:
    """프로세스별 실시간 수집 및 세션 요약 계산 서비스."""

    def __init__(self) -> None:
        self._tracked: dict[int, _TrackedProcess] = {}

    def reset(self) -> None:
        self._tracked.clear()

    def warmup_existing_processes(self) -> None:
        for proc in psutil.process_iter(attrs=["pid", "name"]):
            try:
                proc.cpu_percent(interval=None)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
            except Exception:
                continue

    def _mark_unseen(self) -> None:
        for tracked in self._tracked.values():
            tracked.seen_in_cycle = False

    def collect_process_samples(self, collected_at: str) -> list[ProcessSample]:
        self._mark_unseen()
        samples: list[ProcessSample] = []

        for proc in psutil.process_iter(attrs=["pid", "name", "create_time", "status"]):
            try:
                pid = int(proc.info.get("pid"))
                process_name = str(proc.info.get("name") or f"PID {pid}")
                create_time = proc.info.get("create_time")
                start_time = None
                if create_time:
                    try:
                        start_time = datetime.fromtimestamp(float(create_time)).astimezone().isoformat(timespec="seconds")
                    except Exception:
                        start_time = None

                memory_info = proc.memory_info()
                memory_mb = round(float(memory_info.rss) / (1024 * 1024), 1)
                cpu_percent = float(proc.cpu_percent(interval=None))
                status_raw = proc.info.get("status")
                status = "실행 중" if status_raw not in ("stopped", "zombie", "dead") else "종료됨"

                disk_read_bytes = 0
                disk_write_bytes = 0
                try:
                    io = proc.io_counters()
                    read_total = int(getattr(io, "read_bytes", 0) or 0)
                    write_total = int(getattr(io, "write_bytes", 0) or 0)
                except (psutil.AccessDenied, AttributeError):
                    read_total = 0
                    write_total = 0

                tracked = self._tracked.get(pid)
                if tracked is None:
                    tracked = _TrackedProcess(
                        pid=pid,
                        process_name=process_name,
                        start_time=start_time,
                        first_seen_at=collected_at,
                        last_seen_at=collected_at,
                        status=status,
                    )
                    self._tracked[pid] = tracked

                if tracked.last_disk_read_bytes is not None:
                    disk_read_bytes = max(read_total - tracked.last_disk_read_bytes, 0)
                if tracked.last_disk_write_bytes is not None:
                    disk_write_bytes = max(write_total - tracked.last_disk_write_bytes, 0)

                tracked.last_disk_read_bytes = read_total
                tracked.last_disk_write_bytes = write_total
                tracked.disk_read_total_bytes += disk_read_bytes
                tracked.disk_write_total_bytes += disk_write_bytes
                tracked.process_name = process_name
                tracked.last_seen_at = collected_at
                tracked.status = status
                tracked.seen_in_cycle = True
                tracked.update_numeric(cpu_percent, memory_mb, None)

                samples.append(
                    ProcessSample(
                        collected_at=collected_at,
                        pid=pid,
                        process_name=process_name,
                        cpu_percent=cpu_percent,
                        memory_mb=memory_mb,
                        disk_read_bytes=disk_read_bytes,
                        disk_write_bytes=disk_write_bytes,
                        gpu_percent=None,
                        status=status,
                    )
                )

            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
            except Exception as exc:
                LOGGER.info("프로세스 수집 중 일부 항목을 건너뛰었습니다: %s", exc)
                continue

        for pid, tracked in list(self._tracked.items()):
            if not tracked.seen_in_cycle and tracked.status != "종료됨":
                tracked.status = "종료됨"
                tracked.current_cpu_percent = 0.0
                tracked.last_seen_at = collected_at

        return samples

    def get_display_rows(self) -> list[ProcessDisplayRow]:
        rows: list[ProcessDisplayRow] = []
        for tracked in self._tracked.values():
            runtime_sec = seconds_between(tracked.start_time or tracked.first_seen_at, tracked.last_seen_at)
            rows.append(
                ProcessDisplayRow(
                    pid=tracked.pid,
                    process_name=tracked.process_name,
                    start_time=tracked.start_time or tracked.first_seen_at,
                    runtime_sec=runtime_sec,
                    current_cpu_percent=tracked.current_cpu_percent,
                    avg_cpu_percent=tracked.cpu_avg(),
                    max_cpu_percent=tracked.cpu_max,
                    current_memory_mb=tracked.current_memory_mb,
                    avg_memory_mb=tracked.memory_avg(),
                    max_memory_mb=tracked.memory_max,
                    disk_read_total_bytes=tracked.disk_read_total_bytes,
                    disk_write_total_bytes=tracked.disk_write_total_bytes,
                    gpu_current_percent=tracked.current_gpu_percent,
                    status=tracked.status,
                )
            )
        rows.sort(
            key=lambda row: (
                -(row.current_cpu_percent or 0.0),
                -(row.current_memory_mb or 0.0),
                -(row.disk_read_total_bytes + row.disk_write_total_bytes),
                row.process_name.lower(),
            )
        )
        return rows

    def build_summaries(self, session_id: int) -> list[ProcessSummary]:
        summaries: list[ProcessSummary] = []
        for tracked in self._tracked.values():
            runtime_sec = seconds_between(tracked.start_time or tracked.first_seen_at, tracked.last_seen_at)
            summaries.append(
                ProcessSummary(
                    session_id=session_id,
                    pid=tracked.pid,
                    process_name=tracked.process_name,
                    first_seen_at=tracked.first_seen_at,
                    last_seen_at=tracked.last_seen_at,
                    runtime_sec=runtime_sec,
                    cpu_avg=tracked.cpu_avg(),
                    cpu_max=tracked.cpu_max,
                    memory_avg_mb=tracked.memory_avg(),
                    memory_max_mb=tracked.memory_max,
                    disk_read_total_bytes=tracked.disk_read_total_bytes,
                    disk_write_total_bytes=tracked.disk_write_total_bytes,
                    gpu_avg=tracked.gpu_avg(),
                    gpu_max=tracked.gpu_max,
                    last_status=tracked.status,
                )
            )
        summaries.sort(
            key=lambda summary: (
                -(summary.cpu_avg or 0.0),
                -(summary.memory_avg_mb or 0.0),
                -(summary.disk_read_total_bytes + summary.disk_write_total_bytes),
                summary.process_name.lower(),
            )
        )
        return summaries
