from __future__ import annotations

import json
import shutil
import threading
from pathlib import Path
from typing import Any

from app.constants import (
    DEFAULT_SETTINGS,
    EXPORT_FORMATS,
    MAX_SAMPLE_INTERVAL_SEC,
    MIN_SAMPLE_INTERVAL_SEC,
)
from app.models import AppSettings, SensorOptions
from app.utils import clamp_float, clamp_int, ensure_directory


class ConfigManager:
    """JSON 기반 설정 관리자."""

    def __init__(self, settings_file: str | Path, default_export_dir: str | Path) -> None:
        self._settings_file = Path(settings_file)
        self._default_export_dir = str(default_export_dir)
        self._lock = threading.RLock()
        ensure_directory(self._settings_file.parent)
        self._settings = self._load_or_create()

    @property
    def settings_file(self) -> Path:
        return self._settings_file

    def _default_settings(self) -> AppSettings:
        data = dict(DEFAULT_SETTINGS)
        data["export_base_dir"] = self._default_export_dir
        return AppSettings.from_dict(data)

    def _validate(self, settings: AppSettings) -> AppSettings:
        settings.sample_interval_sec = clamp_int(
            settings.sample_interval_sec,
            MIN_SAMPLE_INTERVAL_SEC,
            MAX_SAMPLE_INTERVAL_SEC,
        )
        settings.log_retention_days = clamp_int(settings.log_retention_days, 1, 3650)
        settings.top_process_count = clamp_int(settings.top_process_count, 1, 100)
        settings.history_limit = clamp_int(settings.history_limit, 50, 5000)

        if settings.default_export_format not in EXPORT_FORMATS:
            settings.default_export_format = DEFAULT_SETTINGS["default_export_format"]

        if not settings.export_base_dir:
            settings.export_base_dir = self._default_export_dir
        ensure_directory(settings.export_base_dir)

        thresholds = settings.overload_thresholds
        thresholds.cpu_usage_percent = clamp_float(thresholds.cpu_usage_percent, 1.0, 100.0)
        thresholds.gpu_usage_percent = clamp_float(thresholds.gpu_usage_percent, 1.0, 100.0)
        thresholds.ram_percent = clamp_float(thresholds.ram_percent, 1.0, 100.0)
        thresholds.cpu_temp_c = clamp_float(thresholds.cpu_temp_c, 1.0, 120.0)
        thresholds.gpu_temp_c = clamp_float(thresholds.gpu_temp_c, 1.0, 120.0)
        thresholds.duration_sec = clamp_int(thresholds.duration_sec, 5, 3600)
        thresholds.merge_gap_sec = clamp_int(thresholds.merge_gap_sec, 0, 300)

        sensor = settings.sensor_options
        settings.sensor_options = SensorOptions(
            enable_cpu_temperature=bool(sensor.enable_cpu_temperature),
            enable_gpu_metrics=bool(sensor.enable_gpu_metrics),
            enable_gpu_temperature=bool(sensor.enable_gpu_temperature),
            enable_hardware_probe=bool(sensor.enable_hardware_probe),
            enable_battery_probe=bool(sensor.enable_battery_probe),
        )
        return settings

    def _read_json(self) -> dict[str, Any] | None:
        if not self._settings_file.exists():
            return None
        try:
            with self._settings_file.open("r", encoding="utf-8") as file:
                return json.load(file)
        except (OSError, json.JSONDecodeError):
            return None

    def _load_or_create(self) -> AppSettings:
        raw = self._read_json()
        if raw is None:
            settings = self._default_settings()
            self.save_settings(settings)
            return settings

        settings = self._validate(AppSettings.from_dict(raw))
        self.save_settings(settings)
        return settings

    def get_settings(self) -> AppSettings:
        with self._lock:
            return AppSettings.from_dict(self._settings.to_dict())

    def save_settings(self, settings: AppSettings) -> None:
        with self._lock:
            validated = self._validate(settings)
            temp_file = self._settings_file.with_suffix(".tmp")
            with temp_file.open("w", encoding="utf-8") as file:
                json.dump(validated.to_dict(), file, ensure_ascii=False, indent=4)
            temp_file.replace(self._settings_file)
            self._settings = validated

    def update_from_dict(self, data: dict[str, Any]) -> AppSettings:
        with self._lock:
            current = self._settings.to_dict()
            merged = self._deep_merge(current, data)
            settings = self._validate(AppSettings.from_dict(merged))
            self.save_settings(settings)
            return self.get_settings()

    def reset_to_defaults(self) -> AppSettings:
        with self._lock:
            settings = self._default_settings()
            self.save_settings(settings)
            return self.get_settings()

    def backup_current_settings(self) -> Path:
        backup_path = self._settings_file.with_suffix(".backup.json")
        with self._lock:
            shutil.copy2(self._settings_file, backup_path)
        return backup_path

    def _deep_merge(self, base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
        result = dict(base)
        for key, value in update.items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        return result
