from __future__ import annotations

import ctypes
import math
import os
import platform
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean
from typing import Iterable, Optional, Sequence, TypeVar

from app.constants import VALUE_COLLECTION_FAILED, VALUE_UNAVAILABLE
from app.models import AppSettings, SystemInfoItem

T = TypeVar("T")


def set_windows_app_user_model_id(app_id: str) -> None:
    if platform.system().lower() != "windows":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        return


def now_local() -> datetime:
    return datetime.now().astimezone()


def now_iso() -> str:
    return now_local().isoformat(timespec="seconds")


def parse_iso(value: str | None) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def to_display_datetime(value: str | None, empty_text: str = VALUE_UNAVAILABLE) -> str:
    parsed = parse_iso(value)
    if not parsed:
        return empty_text
    return parsed.strftime("%Y-%m-%d %H:%M:%S")


def seconds_between(start: str | None, end: str | None) -> float:
    start_dt = parse_iso(start)
    end_dt = parse_iso(end)
    if not start_dt or not end_dt:
        return 0.0
    return max((end_dt - start_dt).total_seconds(), 0.0)


def clamp_int(value: int, minimum: int, maximum: int) -> int:
    return max(minimum, min(value, maximum))


def clamp_float(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(value, maximum))


def safe_float(value: object, default: float | None = None) -> float | None:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_int(value: object, default: int | None = None) -> int | None:
    try:
        if value is None:
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_mean(values: Iterable[float | int | None]) -> float | None:
    cleaned = [float(item) for item in values if item is not None]
    if not cleaned:
        return None
    return mean(cleaned)


def calculate_percentile(values: Sequence[float | int | None], percentile: float) -> float | None:
    cleaned = sorted(float(item) for item in values if item is not None)
    if not cleaned:
        return None
    if percentile <= 0:
        return cleaned[0]
    if percentile >= 100:
        return cleaned[-1]
    rank = (len(cleaned) - 1) * (percentile / 100.0)
    low = math.floor(rank)
    high = math.ceil(rank)
    if low == high:
        return cleaned[low]
    weight = rank - low
    return cleaned[low] * (1 - weight) + cleaned[high] * weight


def sanitize_filename(name: str) -> str:
    cleaned = re.sub(r"[\\/:*?\"<>|]", "_", name.strip())
    cleaned = re.sub(r"\s+", "_", cleaned)
    return cleaned or "session"


def format_bytes(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    size = float(value)
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    index = 0
    while abs(size) >= 1024.0 and index < len(units) - 1:
        size /= 1024.0
        index += 1
    if units[index] == "B":
        return f"{size:.0f} {units[index]}"
    return f"{size:.2f} {units[index]}"


def format_bytes_per_sec(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    return f"{format_bytes(value, none_text=none_text)}/s"


def format_mb(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    return f"{float(value):,.1f} MB"


def format_gb_from_mb(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    return f"{float(value) / 1024.0:,.2f} GB"


def format_percent(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    return f"{float(value):.1f}%"


def format_temperature(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    return f"{float(value):.1f}°C"


def format_clock_mhz(value: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    return f"{float(value):,.0f} MHz"


def format_duration(seconds: float | int | None, none_text: str = VALUE_UNAVAILABLE) -> str:
    if seconds is None:
        return none_text
    total = int(max(float(seconds), 0))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        return f"{hours}시간 {minutes}분 {secs}초"
    if minutes > 0:
        return f"{minutes}분 {secs}초"
    return f"{secs}초"


def format_optional(value: object, none_text: str = VALUE_UNAVAILABLE) -> str:
    if value is None:
        return none_text
    text = str(value).strip()
    return text if text else none_text


def coalesce_value(*values: T | None, default: T | None = None) -> T | None:
    for value in values:
        if value is not None:
            return value
    return default


def exception_to_message(exc: Exception) -> str:
    text = str(exc).strip()
    return text or VALUE_COLLECTION_FAILED


def build_app_stylesheet(settings: AppSettings) -> str:
    if settings.dark_mode:
        return """
        QWidget { background-color: #1e1f24; color: #f0f2f5; font-size: 10pt; }
        QMainWindow, QTableView, QTextEdit, QPlainTextEdit, QListView, QTreeView {
            background-color: #262831;
            color: #f0f2f5;
            border: 1px solid #3a3f4b;
        }
        QTabWidget::pane {
            background-color: #262831;
            border: 1px solid #3a3f4b;
            top: -1px;
        }
        QTabBar::tab {
            background-color: #2a2f3a;
            color: #d8dee9;
            border: 1px solid #3a3f4b;
            border-bottom: none;
            padding: 8px 14px;
            margin-right: 4px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            min-width: 96px;
            font-weight: 600;
        }
        QTabBar::tab:selected {
            background-color: #334155;
            color: #ffffff;
        }
        QTabBar::tab:hover:!selected {
            background-color: #374151;
            color: #ffffff;
        }
        QHeaderView::section { background-color: #323744; color: #f0f2f5; padding: 6px; border: 0px; }
        QPushButton {
            background-color: #334e68; color: white; border: none; border-radius: 6px; padding: 8px 14px;
        }
        QPushButton:hover { background-color: #486581; }
        QPushButton:disabled { background-color: #555b66; color: #b6bcc4; }
        QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit {
            background-color: #2f3440; color: #f0f2f5; border: 1px solid #3a3f4b; border-radius: 6px; padding: 6px;
        }
        QCheckBox, QLabel { color: #f0f2f5; }
        QStatusBar { background-color: #181a1f; color: #d8dee9; }
        QFrame#metricCard, QFrame#summaryCard {
            background-color: #2a2f3a; border: 1px solid #374151; border-radius: 12px; padding: 10px;
        }
        QFrame#warningBox {
            background-color: #40222a; border: 1px solid #8b2f3d; border-radius: 12px; padding: 10px;
        }
        QGroupBox {
            border: 1px solid #3a3f4b; border-radius: 10px; margin-top: 10px; padding-top: 10px;
            background-color: #262831;
        }
        QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
        QScrollBar:vertical { background: #22252c; width: 14px; margin: 16px 0; }
        QScrollBar::handle:vertical { background: #59667a; min-height: 20px; border-radius: 6px; }
        """
    return """
    QWidget { background-color: #f5f7fb; color: #1f2933; font-size: 10pt; }
    QMainWindow, QTableView, QTextEdit, QPlainTextEdit, QListView, QTreeView {
        background-color: #ffffff;
        color: #1f2933;
        border: 1px solid #d7dde5;
    }
    QTabWidget::pane {
        background-color: #ffffff;
        border: 1px solid #d7dde5;
        top: -1px;
    }
    QTabBar::tab {
        background-color: #e7edf5;
        color: #334155;
        border: 1px solid #cbd5e1;
        border-bottom: none;
        padding: 8px 14px;
        margin-right: 4px;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        min-width: 96px;
        font-weight: 600;
    }
    QTabBar::tab:selected {
        background-color: #ffffff;
        color: #0f172a;
    }
    QTabBar::tab:hover:!selected {
        background-color: #dbe7f4;
        color: #0f172a;
    }
    QHeaderView::section { background-color: #eef2f7; color: #1f2933; padding: 6px; border: 0px; }
    QPushButton {
        background-color: #2563eb; color: white; border: none; border-radius: 6px; padding: 8px 14px;
    }
    QPushButton:hover { background-color: #1d4ed8; }
    QPushButton:disabled { background-color: #a8b3c7; color: #eef2f7; }
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit {
        background-color: #ffffff; color: #1f2933; border: 1px solid #c9d2df; border-radius: 6px; padding: 6px;
    }
    QCheckBox, QLabel { color: #1f2933; }
    QStatusBar { background-color: #f0f4f8; color: #334e68; }
    QFrame#metricCard, QFrame#summaryCard {
        background-color: #ffffff; border: 1px solid #d7dde5; border-radius: 12px; padding: 10px;
    }
    QFrame#warningBox {
        background-color: #fff1f2; border: 1px solid #fecdd3; border-radius: 12px; padding: 10px;
    }
    QGroupBox {
        border: 1px solid #d7dde5; border-radius: 10px; margin-top: 10px; padding-top: 10px;
        background-color: #ffffff;
    }
    QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
    QScrollBar:vertical { background: #f0f4f8; width: 14px; margin: 16px 0; }
    QScrollBar::handle:vertical { background: #bcccdc; min-height: 20px; border-radius: 6px; }
    """


def grouped_system_info(items: Sequence[SystemInfoItem]) -> dict[str, list[SystemInfoItem]]:
    grouped: dict[str, list[SystemInfoItem]] = {}
    for item in items:
        grouped.setdefault(item.category, []).append(item)
    return grouped


def ensure_directory(path: str | Path) -> Path:
    directory = Path(path)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def remove_file_safely(path: str | Path) -> None:
    file_path = Path(path)
    try:
        if file_path.exists():
            file_path.unlink()
    except OSError:
        return


def remove_old_files(directory: str | Path, older_than_days: int, glob_pattern: str = "*") -> None:
    target_dir = Path(directory)
    if not target_dir.exists() or older_than_days <= 0:
        return
    cutoff = now_local() - timedelta(days=older_than_days)
    for item in target_dir.glob(glob_pattern):
        try:
            modified = datetime.fromtimestamp(item.stat().st_mtime).astimezone()
        except OSError:
            continue
        if modified < cutoff:
            try:
                if item.is_file():
                    item.unlink()
            except OSError:
                continue


def open_file_location(path: str | Path) -> None:
    target = Path(path)
    if not target.exists():
        return
    if sys.platform.startswith("win"):
        os.startfile(str(target.parent if target.is_file() else target))


def make_session_name(prefix: str = "세션") -> str:
    return f"{prefix} {now_local().strftime('%Y-%m-%d %H:%M:%S')}"
