from __future__ import annotations

import sys
import traceback

from PySide6.QtWidgets import QApplication, QMessageBox

from app.constants import APP_NAME, APP_VERSION, ORGANIZATION_DOMAIN, ORGANIZATION_NAME
from app.config import ConfigManager
from app.database.db_manager import DatabaseManager
from app.logger import get_logger, setup_logging
from app.paths import build_app_paths, clear_temp_charts, ensure_app_directories
from app.ui.main_window import MainWindow
from app.utils import build_app_stylesheet, set_windows_app_user_model_id


def main() -> int:
    set_windows_app_user_model_id(f"{ORGANIZATION_DOMAIN}.{APP_NAME.replace(' ', '')}")
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName(ORGANIZATION_NAME)
    app.setOrganizationDomain(ORGANIZATION_DOMAIN)

    try:
        paths = build_app_paths()
        ensure_app_directories(paths)

        config_manager = ConfigManager(paths.settings_file, paths.exports_dir)
        settings = config_manager.get_settings()

        setup_logging(paths.log_file, retention_days=settings.log_retention_days)
        logger = get_logger(__name__)
        logger.info("애플리케이션 초기화를 시작합니다.")

        clear_temp_charts(paths)

        db_manager = DatabaseManager(paths.db_file)
        db_manager.initialize_database()

        app.setStyleSheet(build_app_stylesheet(settings))

        window = MainWindow(paths=paths, config_manager=config_manager, db_manager=db_manager)
        window.show()

        logger.info("메인 창을 표시했습니다.")
        return app.exec()
    except Exception as exc:
        error_text = "프로그램 초기화 중 오류가 발생했습니다.\n\n"
        error_text += f"오류: {exc}\n\n"
        error_text += traceback.format_exc(limit=10)
        QMessageBox.critical(None, f"{APP_NAME} 시작 실패", error_text)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
