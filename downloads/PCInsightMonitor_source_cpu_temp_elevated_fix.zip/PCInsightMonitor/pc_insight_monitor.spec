# -*- mode: python ; coding: utf-8 -*-

from pathlib import Path
import importlib.util
import os

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

if 'SPECPATH' in globals():
    project_dir = Path(SPECPATH).resolve()
elif 'SPEC' in globals():
    project_dir = Path(SPEC).resolve().parent
else:
    project_dir = Path(os.getcwd()).resolve()


def _optional_package_assets(package_name: str):
    if importlib.util.find_spec(package_name) is None:
        return [], []
    return collect_data_files(package_name), collect_submodules(package_name)


def _add_tree_if_exists(base_path: Path, target_prefix: str, datas_list: list[tuple[str, str]]) -> None:
    if not base_path.exists():
        return
    for item in base_path.rglob('*'):
        if item.is_file():
            relative_parent = item.parent.relative_to(base_path)
            target_dir = str(Path(target_prefix) / relative_parent)
            datas_list.append((str(item), target_dir))


datas = []
datas += collect_data_files('matplotlib')
datas += collect_data_files('pyqtgraph')
optional_wintmp_datas, optional_wintmp_hiddenimports = _optional_package_assets('WinTmp')
datas += optional_wintmp_datas
_add_tree_if_exists(project_dir / 'vendor' / 'LibreHardwareMonitor', 'vendor/LibreHardwareMonitor', datas)

hiddenimports = []
hiddenimports += collect_submodules('pyqtgraph')
hiddenimports += optional_wintmp_hiddenimports
hiddenimports += [
    'wmi',
    'pynvml',
    'openpyxl',
    'reportlab',
    'reportlab.pdfbase',
    'reportlab.pdfbase.ttfonts',
]

block_cipher = None

a = Analysis(
    [str(project_dir / 'main.py')],
    pathex=[str(project_dir)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='PCInsightMonitor',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    console=False,
    disable_windowed_traceback=False,
)
